/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#ifndef QUACKLE_COMPUTERPLAYER_H
#define QUACKLE_COMPUTERPLAYER_H

#include "sim.h"

#define QUACKLE_NULL_COMPUTER_PLAYER_ID 0
#define QUACKLE_STATIC_COMPUTER_PLAYER_ID 1

namespace Quackle
{

class ComputerPlayer
{
public:
	// constructs a new computer player
	ComputerPlayer();
	virtual ~ComputerPlayer();

	// prepare to generate move for current player
	// on this position
	virtual void setPosition(const GamePosition &position);

	// get access to the position that we're playing from
	GamePosition &currentPosition();
	const GamePosition &currentPosition() const;

	const UVString &name() const;
	int id() const;

	// the best move
	virtual Move move() = 0;

	// top n moves; default implementation returns
	// a one-item list with move()
	virtual MoveList moves(int nmoves);

	// Whether or not this player takes more than a few seconds to make a play.
	// False by default.
	virtual bool isSlow() const;

	// Whether this player should be an option to play against.
	// False by default.
	virtual bool isUserVisible() const;

protected:
	Simulator m_simulator;
	UVString m_name;
	int m_id;
};

inline GamePosition &ComputerPlayer::currentPosition()
{
	return m_simulator.currentPosition();
}

inline const GamePosition &ComputerPlayer::currentPosition() const
{
	return m_simulator.currentPosition();
}

inline const UVString &ComputerPlayer::name() const
{
	return m_name;
}

inline int ComputerPlayer::id() const
{
	return m_id;
}

inline bool ComputerPlayer::isSlow() const
{
	return false;
}

inline bool ComputerPlayer::isUserVisible() const
{
	return false;
}

// Static player has ID 1!
class StaticPlayer : public ComputerPlayer
{
public:
	StaticPlayer();
	virtual ~StaticPlayer();

	virtual Move move();
	virtual MoveList moves(int nmoves);
};

}

#endif

/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#include <iostream>

#include "bogowinplayer.h"

//#define DEBUG_COMPUTERPLAYER

using namespace Quackle;

BogowinPlayer::BogowinPlayer()
{
	m_name = MARK_UV("Bogowin");
	m_id = 107;
}

BogowinPlayer::~BogowinPlayer()
{
}

Move BogowinPlayer::move()
{
	return moves(1).back();
}

MoveList BogowinPlayer::moves(int nmoves)
{
	if (m_simulator.currentPosition().bag().empty())
    {
		m_endgame.setPosition(m_simulator.currentPosition());
		const int initialPlayNumber = 240;
		m_endgame.currentPosition().kibitz(initialPlayNumber);
		m_endgame.setIncludedMoves(m_endgame.currentPosition().moves());
		Move move = m_endgame.solve();
		MoveList ret;
		ret.push_back(move);
		return ret;
	}
	
	UVcout << "BogowinPlayer generating move from position:" << endl;
	UVcout << m_simulator.currentPosition() << endl;

	const int initialPlayNumber = 14;
	const int zerothPrune = 18;
	const int zerothPruneMax = 14;
	const int firstIterations = 250;
	//const int firstIterations = 2500;
	int plies = 2;
	
	if (m_simulator.currentPosition().bag().size() <= 14)
		plies = -1;
	
	m_simulator.currentPosition().kibitz(initialPlayNumber);
	m_simulator.setIncludedMoves(m_simulator.currentPosition().moves());

	UVcout << "Statically evaluated plays:" << endl;
	UVcout << m_simulator.currentPosition().moves() << endl;

	m_simulator.pruneTo(zerothPrune, zerothPruneMax);

	MoveList moves = m_simulator.moves(true, false);
	
	UVcout << "Pruned to plays within " << zerothPrune << ":" << endl;
	UVcout << moves << endl;

	if (moves.size() <= 1)
		return moves;
		
	m_simulator.setIgnoreOppos(false);
	m_simulator.simulate(plies, firstIterations);

	moves = m_simulator.moves(/* prune */ true, /* sort by win */ true);
	
	UVcout << "after " << firstIterations << " iterations:" << endl;
	UVcout << moves << endl;

	if (moves.size() > nmoves)
		moves.resize(nmoves);

	return moves;
}


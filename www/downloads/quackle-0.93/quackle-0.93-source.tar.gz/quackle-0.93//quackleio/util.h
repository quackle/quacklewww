/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#ifndef QUACKER_UTIL_H
#define QUACKER_UTIL_H

#include <QString>

#include <alphabetparameters.h>
#include <datamanager.h>
#include <uv.h>

namespace Quackle
{
	class Move;
	class Rack;
}

namespace QuackleIO
{

class Util
{
public:
	static UVString qstringToString(const QString &qstring);
	static Quackle::LetterString encode(const QString &qstring);

	// encode as above but clear blankess of all letters
	static Quackle::LetterString nonBlankEncode(const QString &qstring);

	static QString uvStringToQString(const UVString &stdWString);
	static QString letterStringToQString(const Quackle::LetterString &letterString);
	static QString letterStringToQString(Quackle::Letter &letter);

	// non-ui strings
	static string qstringToStdString(const QString &qstring);
	static QString stdStringToQString(const string &stdString);

	static QString moveToDetailedString(const Quackle::Move &move, QString prettyTiles = QString::null);
	static QString moveToSensitiveString(const Quackle::Move &move);

	// arrange letters in word into sortOrder
	static QString arrangeLetters(const QString &word, const QString &sortOrder);

	// make alphagram
    static QString alphagram(const QString &word);

	// make pattern of letters user wants based on settings
	static QString arrangeLettersForUser(const QString &word, bool vowelFirst);
	static QString arrangeLettersForUser(const Quackle::Rack &rack, bool vowelFirst);
};

inline UVString Util::qstringToString(const QString &qstring)
{
#if QUACKLE_USE_WCHAR_FOR_USER_VISIBLE
	return qstring.toStdWString();
#else
	return qstringToStdString(qstring);
#endif
}

inline Quackle::LetterString Util::encode(const QString &qstring)
{
	return QUACKLE_ALPHABET_PARAMETERS->encode(qstringToString(qstring));
}

inline Quackle::LetterString Util::nonBlankEncode(const QString &qstring)
{
	return QUACKLE_ALPHABET_PARAMETERS->clearBlankness(encode(qstring));
}

inline QString Util::uvStringToQString(const UVString &uvString)
{
#if QUACKLE_USE_WCHAR_FOR_USER_VISIBLE
	return QString::fromStdWString(uvString);
#else
	return stdStringToQString(uvString);
#endif
}

inline QString Util::letterStringToQString(const Quackle::LetterString &letterString)
{
	return uvStringToQString(QUACKLE_ALPHABET_PARAMETERS->userVisible(letterString));
}

inline QString Util::letterStringToQString(Quackle::Letter &letter)
{
	return uvStringToQString(QUACKLE_ALPHABET_PARAMETERS->userVisible(letter));
}

inline string Util::qstringToStdString(const QString &qstring)
{
	return qstring.toStdString();
}

inline QString Util::stdStringToQString(const string &stdString)
{
	return QString::fromStdString(stdString);
}

}

#endif

/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#include <stdio.h>
#include <string>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <vector>
#include <map>

using namespace std;

class Node {
public:
    char c;
    bool t;
    vector<Node> children;
    int pointer;
    bool lastchild;
    void pushword(string word);
    void print(string prefix);
};


vector< Node* > nodelist;


void Node::print(string prefix) {
    if (t) {
        // cout << prefix << endl;
    }

    // cout << "prefix: " << prefix << ", children: " << children.size() << endl;

    if (children.size() > 0) {    
        pointer = nodelist.size();
        children[children.size() - 1].lastchild = true;
    }

    for (int i = 0; i < children.size(); i++) {
        nodelist.push_back(&children[i]);
    }

    for (int i = 0; i < children.size(); i++) {
        children[i].print(prefix + children[i].c);
    }
}


void Node::pushword(string word) {
    if (word.length() == 0) {
        t = true;
    }
    else {
        char first = word[0];
        string rest = word.substr(1, word.length() - 1);
        int index = -1;
 
        // cout << "first: " << first << ", rest: " << rest << endl;

        for (int i = 0; i < children.size(); i++) {
            if (children[i].c == first) {
                index = i;
                i = children.size();
            }
        }
        
        if (index == -1) {
            Node n;
            n.c = first;
            n.t = false;
            n.pointer = 0;
            n.lastchild = false;
            children.push_back(n);
            index = children.size() - 1;
        }

        children[index].pushword(rest);
    }
}


int main() {
    ifstream file("gaddag.raw");
    //ifstream file("testdic");

    Node root;
    root.t = false;
    root.c = '_';
    root.pointer = 0;
    root.lastchild = true;

    int cnt = 0;
    while(!file.eof()) {
        string word;
        file >> word;
        if (!file.eof() && word.length()) {
            root.pushword(word);
        }
	if (++cnt % 10000 == 0) {
	    cout << ".";
	    cout.flush();
	}
    }

    nodelist.push_back(&root);

    root.print("");    

    ofstream out("twl.gaddag", ios::out | ios::binary);

    for (int i = 0; i < nodelist.size(); i++) {
        // cout << nodelist[i]->c << " " << nodelist[i]->pointer << " " << nodelist[i]->t << " " << nodelist[i]->lastchild << endl;

        unsigned int p = (unsigned int)(nodelist[i]->pointer);
	if (p != 0) {
	    p -= i; // offset indexing
	}
	        
        char bytes[4];
        unsigned char n1 = (p & 0x00FF0000) >> 16;
/*
        cout << "byte 1: " << ((p & 0xFF000000) >> 24); 
        cout << ", byte 2: " << ((p & 0x00FF0000) >> 8);
        cout << ", byte 3: " << ((p & 0x0000FF00) >> 8);
        cout << ", byte 4: " << ((p & 0x000000FF) >> 0) << endl;
*/

        unsigned char n2 = (p & 0x0000FF00) >> 8;
        unsigned char n3 = (p & 0x000000FF) >> 0;
        unsigned char n4; 

/*
        cout << "p: " << p << ", crap: " << (((unsigned int)(n1) << 24) | 
                                           ((unsigned int)(n2) << 16) | 
                                           ((unsigned int)(n3) << 8)) << endl;
*/
        if (nodelist[i]->c == '^') {
            n4 = 27; // 26 is reserved for blank
        }
        else {
            n4 = nodelist[i]->c - 'A';
        }
        
        
        if (nodelist[i]->t) {
            n4 |= 32;
        }
        if (nodelist[i]->lastchild) {
            n4 |= 64;
        }

/*
        cout << "p: " << p << endl;;
        cout << "n4:" << (int)(n4) << 
                ", n1: " << (int)(n1) << 
                ", n2: " << (int)(n2) <<
                ", n3: " << (int)(n3) << endl;
*/

        //bytes[0] = n4; bytes[1] = n1; bytes[2] = n2; bytes[3] = n3;
        bytes[0] = n1; bytes[1] = n2; bytes[2] = n3; bytes[3] = n4;
        //out.write((const char*) &p, 4);
        out.write(bytes, 4);
    }
}

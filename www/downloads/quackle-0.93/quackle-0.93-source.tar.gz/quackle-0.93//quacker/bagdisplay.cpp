/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#include <math.h>

#include <QtGui>

#include <bag.h>
#include <game.h>
#include <quackleio/util.h>

#include "quacker.h"
#include "bagdisplay.h"

BagDisplay::BagDisplay(QWidget *parent)
	: View(parent)
{
	QVBoxLayout *layout = new QVBoxLayout(this);
	layout->setMargin(0);

	m_textEdit = new QTextEdit;
	m_textEdit->setReadOnly(true);
	m_textEdit->setFontFamily("Courier");
	m_textEdit->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);

	m_label = new QLabel;
	m_label->setWordWrap(true);
	m_label->setBuddy(m_textEdit);
	layout->addWidget(m_label);
	layout->addWidget(m_textEdit);

	layout->setStretchFactor(m_textEdit, 10);

	showTiles(QString::null);
}

BagDisplay::~BagDisplay()
{
}

void BagDisplay::positionChanged(const Quackle::GamePosition &position)
{
	showTiles(QuackleIO::Util::uvStringToQString(position.unseenTiles()));
}

void BagDisplay::showTiles(const QString &tiles)
{
	if (tiles.isNull())
	{
		m_label->setText(tr("&Bag is collapsed in a wrinkled heap on the table"));
		return;
	}

	QMap<QChar, int> counts;
	QString text;

	for (int i = 0; i < tiles.length(); ++i)
	{
		const QChar &c = tiles.at(i);
		if (counts.contains(c))
			counts[c] += 1;
		else
			counts.insert(c, 1);
	}

	QFontMetrics metrics(m_textEdit->currentFont());
	int maxLineWidth = 0;

	for (QMap<QChar, int>::iterator it = counts.begin(); it != counts.end(); ++it)
	{
		const int count = it.value();

		QString line;

		for (int i = 0; i < count; ++i)
			line += it.key();

		const int lineWidth = metrics.width(line);
		if (lineWidth > maxLineWidth)
			maxLineWidth = lineWidth;

		text += line;
		text += "\n";
	}

	m_label->setText(tr("%1 &unseen tiles").arg(tiles.length()));
	m_textEdit->setPlainText(text);

	const int minimumMaxLineWidth = 16;
	if (maxLineWidth < minimumMaxLineWidth)
		maxLineWidth = minimumMaxLineWidth;

	const int maximumWidth = maxLineWidth + m_textEdit->frameWidth() * 2 + (m_textEdit->verticalScrollBar()->isVisible()? m_textEdit->verticalScrollBar()->width() : 0) + 10;
	m_textEdit->setMaximumSize(maximumWidth, 26 * 100);

	m_textEdit->resize(m_textEdit->maximumSize());
}


/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#ifndef QUACKER_SETTINGS_H
#define QUACKER_SETTINGS_H

#include <string>

#include <QWidget>
#include <QSettings>

class QComboBox;
class QCheckBox;
class QPushButton;

using namespace std;

class CustomQSettings : public QSettings
{
Q_OBJECT

public:
	CustomQSettings() :
#if defined(Q_WS_WIN)
		QSettings((QSysInfo::WindowsVersion & QSysInfo::WV_DOS_based) ? IniFormat : NativeFormat,
			UserScope, tr("Quackle"))
#else
		QSettings()
#endif
	{}
};

class Settings : public QWidget
{
Q_OBJECT

public:
	Settings(QWidget *parent = 0);

	static Settings *self();

	bool vowelFirst() const;
	bool verboseLabels() const;
	bool scoreLabels() const;

signals:
	void refreshViews();

public slots:
	// called to set up libquackle data structures and our internal
	// data structures based on stored user settings
	void initialize();

	// called to set widgets to display current settings based
	// on libquackle data structures and our internal data structures
	void load();

	// must be called after initialize
	void createGUI();

protected slots:
	void lexiconChanged(const QString &lexiconName);
	void boardChanged(const QString &boardName);
	void vowelFirstChanged(bool vowelFirst);
	void verboseLabelsChanged(bool verboseLabels);
	void scoreLabelsChanged(bool scoreLabels);

	void addBoard();
	void editBoard();
	void deleteBoard();
	
	void setQuackleToUseLexiconName(const string &lexiconName);
	void setQuackleToUseBoardName(const QString &lexiconName);

protected:
	QComboBox *m_lexiconNameCombo;
	QComboBox *m_boardNameCombo;
	QCheckBox *m_vowelFirstCheck;
	QCheckBox *m_verboseLabelsCheck;
	QCheckBox *m_scoreLabelsCheck;
	QPushButton *m_addBoard;
	QPushButton *m_editBoard;
	QPushButton *m_deleteBoard;

	bool m_vowelFirst;
	bool m_verboseLabels;
	bool m_scoreLabels;

private:
	// populate the popup based on what's in QSettings
	void loadBoardNameCombo();
	
	static Settings *m_self;
};

inline bool Settings::vowelFirst() const
{
	return m_vowelFirst;
}

inline bool Settings::verboseLabels() const
{
	return m_verboseLabels;
}

inline bool Settings::scoreLabels() const
{
	return m_scoreLabels;
}

#endif

/****************************************************************************
** Meta object code from reading C++ file 'quacker.h'
**
** Created: Tue Jul 22 04:38:37 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../quacker.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'quacker.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_TopLevel[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
      79,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      19,   10,    9,    9, 0x05,
      64,   58,    9,    9, 0x05,
     104,   96,    9,    9, 0x05,

 // slots: signature, parameters, type, tag, flags
     137,    9,    9,    9, 0x0a,
     144,    9,    9,    9, 0x0a,
     163,  154,    9,    9, 0x0a,
     181,  154,    9,    9, 0x0a,
     199,    9,    9,    9, 0x0a,
     206,    9,    9,    9, 0x0a,
     215,  154,    9,    9, 0x0a,
     234,    9,    9,    9, 0x0a,
     249,    9,    9,    9, 0x0a,
     261,    9,    9,    9, 0x0a,
     299,  270,    9,    9, 0x0a,
     350,  336,    9,    9, 0x2a,
     362,    9,    9,    9, 0x0a,
     376,    9,    9,    9, 0x0a,
     403,  388,    9,    9, 0x0a,
     438,    9,    9,    9, 0x0a,
     454,    9,    9,    9, 0x0a,
     469,    9,    9,    9, 0x0a,
     488,  388,    9,    9, 0x0a,
     523,    9,    9,    9, 0x0a,
     536,    9,    9,    9, 0x0a,
     554,    9,    9,    9, 0x0a,
     588,  572,    9,    9, 0x0a,
     603,  572,    9,    9, 0x0a,
     625,    9,    9,    9, 0x0a,
     650,    9,    9,    9, 0x0a,
     676,  662,    9,    9, 0x0a,
     715,  710,    9,    9, 0x0a,
     740,    9,    9,    9, 0x0a,
     748,    9,    9,    9, 0x0a,
     763,    9,    9,    9, 0x0a,
     771,    9,    9,    9, 0x0a,
     779,    9,    9,    9, 0x0a,
     806,  798,    9,    9, 0x0a,
     849,  842,    9,    9, 0x0a,
     861,    9,    9,    9, 0x09,
     884,    9,    9,    9, 0x09,
     902,    9,    9,    9, 0x09,
     916,    9,    9,    9, 0x09,
     934,    9,    9,    9, 0x09,
     955,    9,    9,    9, 0x09,
     994,  978,    9,    9, 0x09,
    1033,    9,    9,    9, 0x09,
    1047,  842,    9,    9, 0x09,
    1066,    9,    9,    9, 0x09,
    1075,    9,    9,    9, 0x09,
    1082,    9,    9,    9, 0x09,
    1100, 1093,    9,    9, 0x09,
    1128, 1123,    9,    9, 0x09,
    1160,   58,    9,    9, 0x09,
    1205, 1200,    9,    9, 0x09,
    1233, 1228,    9,    9, 0x09,
    1260, 1251,    9,    9, 0x09,
    1306,    9,    9,    9, 0x09,
    1323,    9,    9,    9, 0x09,
    1340,    9,    9,    9, 0x09,
    1362,    9,    9,    9, 0x09,
    1380,    9,    9,    9, 0x09,
    1401,  710,    9,    9, 0x09,
    1421,    9,    9,    9, 0x29,
    1443, 1434,    9,    9, 0x09,
    1461,    9,    9,    9, 0x09,
    1471,    9,    9,    9, 0x09,
    1493,    9,    9,    9, 0x09,
    1520, 1510,    9,    9, 0x09,
    1538,    9,    9,    9, 0x09,
    1559,    9,    9,    9, 0x09,
    1581, 1578,    9,    9, 0x09,
    1602,    9,    9,    9, 0x09,
    1619,    9,    9,    9, 0x09,
    1635, 1578,    9,    9, 0x09,
    1664,    9,    9,    9, 0x09,
    1689,    9,    9,    9, 0x09,
    1713,    9,    9,    9, 0x09,
    1729,    9,    9,    9, 0x09,
    1753, 1744,    9,    9, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_TopLevel[] = {
    "TopLevel\0\0position\0positionChanged(Quackle::GamePosition)\0moves\0"
    "movesChanged(Quackle::MoveList)\0history\0"
    "historyChanged(Quackle::History)\0open()\0newGame()\0filename\0"
    "openFile(QString)\0loadFile(QString)\0save()\0saveAs()\0"
    "writeFile(QString)\0generateList()\0letterbox()\0kibitz()\0"
    "numberOfPlays,computerPlayer\0kibitz(int,Quackle::ComputerPlayer*)\0"
    "numberOfPlays\0kibitz(int)\0kibitzFifty()\0kibitzAll()\0computerPlayer\0"
    "kibitzAs(Quackle::ComputerPlayer*)\0firstPosition()\0nextPosition()\0"
    "previousPosition()\0reportAs(Quackle::ComputerPlayer*)\0htmlReport()\0"
    "graphicalReport()\0commitTopChoice()\0startSimulation\0simulate(bool)\0"
    "simulateToggled(bool)\0clearSimulationResults()\0showAscii()\0"
    "text,filename\0writeAsciiToFile(QString,QString)\0text\0"
    "copyToClipboard(QString)\0print()\0firstTimeRun()\0about()\0hints()\0"
    "showConfigDialog()\0players\0initializeGame(Quackle::PlayerList)\0"
    "paused\0pause(bool)\0finishInitialization()\0introduceToUser()\0"
    "advanceGame()\0startOppoThread()\0computerPlayerDone()\0"
    "kibitzThreadFinished()\0fraction,thread\0"
    "playerFractionDone(double,OppoThread*)\0showToHuman()\0"
    "timerControl(bool)\0commit()\0pass()\0overdraw()\0mesage\0"
    "statusMessage(QString)\0move\0setCandidateMove(Quackle::Move)\0"
    "removeCandidateMoves(Quackle::MoveList)\0rack\0setRack(Quackle::Rack)\0"
    "note\0setNote(UVString)\0location\0"
    "goToHistoryLocation(Quackle::HistoryLocation)\0stopEverything()\0"
    "updateAllViews()\0updatePositionViews()\0updateMoveViews()\0"
    "updateHistoryViews()\0setCaption(QString)\0setCaption()\0modified\0"
    "setModified(bool)\0timeout()\0incrementSimulation()\0updateSimViews()\0"
    "plyString\0pliesSet(QString)\0ignoreOpposChanged()\0updatePliesCombo()\0"
    "on\0logfileEnabled(bool)\0logfileChanged()\0chooseLogfile()\0"
    "partialOppoRackEnabled(bool)\0partialOppoRackChanged()\0"
    "showSimulationDetails()\0startBirthday()\0birthdayBash()\0index,on\0"
    "birthdayGram(int,bool)\0"
};

const QMetaObject TopLevel::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_TopLevel,
      qt_meta_data_TopLevel, 0 }
};

const QMetaObject *TopLevel::metaObject() const
{
    return &staticMetaObject;
}

void *TopLevel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TopLevel))
	return static_cast<void*>(const_cast<TopLevel*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int TopLevel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: positionChanged((*reinterpret_cast< const Quackle::GamePosition(*)>(_a[1]))); break;
        case 1: movesChanged((*reinterpret_cast< const Quackle::MoveList(*)>(_a[1]))); break;
        case 2: historyChanged((*reinterpret_cast< const Quackle::History(*)>(_a[1]))); break;
        case 3: open(); break;
        case 4: newGame(); break;
        case 5: openFile((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: loadFile((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: save(); break;
        case 8: saveAs(); break;
        case 9: writeFile((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: generateList(); break;
        case 11: letterbox(); break;
        case 12: kibitz(); break;
        case 13: kibitz((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< Quackle::ComputerPlayer*(*)>(_a[2]))); break;
        case 14: kibitz((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: kibitzFifty(); break;
        case 16: kibitzAll(); break;
        case 17: kibitzAs((*reinterpret_cast< Quackle::ComputerPlayer*(*)>(_a[1]))); break;
        case 18: firstPosition(); break;
        case 19: nextPosition(); break;
        case 20: previousPosition(); break;
        case 21: reportAs((*reinterpret_cast< Quackle::ComputerPlayer*(*)>(_a[1]))); break;
        case 22: htmlReport(); break;
        case 23: graphicalReport(); break;
        case 24: commitTopChoice(); break;
        case 25: simulate((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: simulateToggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: clearSimulationResults(); break;
        case 28: showAscii(); break;
        case 29: writeAsciiToFile((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 30: copyToClipboard((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 31: print(); break;
        case 32: firstTimeRun(); break;
        case 33: about(); break;
        case 34: hints(); break;
        case 35: showConfigDialog(); break;
        case 36: initializeGame((*reinterpret_cast< const Quackle::PlayerList(*)>(_a[1]))); break;
        case 37: pause((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 38: finishInitialization(); break;
        case 39: introduceToUser(); break;
        case 40: advanceGame(); break;
        case 41: startOppoThread(); break;
        case 42: computerPlayerDone(); break;
        case 43: kibitzThreadFinished(); break;
        case 44: playerFractionDone((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< OppoThread*(*)>(_a[2]))); break;
        case 45: showToHuman(); break;
        case 46: timerControl((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 47: commit(); break;
        case 48: pass(); break;
        case 49: overdraw(); break;
        case 50: statusMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 51: setCandidateMove((*reinterpret_cast< const Quackle::Move(*)>(_a[1]))); break;
        case 52: removeCandidateMoves((*reinterpret_cast< const Quackle::MoveList(*)>(_a[1]))); break;
        case 53: setRack((*reinterpret_cast< const Quackle::Rack(*)>(_a[1]))); break;
        case 54: setNote((*reinterpret_cast< const UVString(*)>(_a[1]))); break;
        case 55: goToHistoryLocation((*reinterpret_cast< const Quackle::HistoryLocation(*)>(_a[1]))); break;
        case 56: stopEverything(); break;
        case 57: updateAllViews(); break;
        case 58: updatePositionViews(); break;
        case 59: updateMoveViews(); break;
        case 60: updateHistoryViews(); break;
        case 61: setCaption((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 62: setCaption(); break;
        case 63: setModified((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 64: timeout(); break;
        case 65: incrementSimulation(); break;
        case 66: updateSimViews(); break;
        case 67: pliesSet((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 68: ignoreOpposChanged(); break;
        case 69: updatePliesCombo(); break;
        case 70: logfileEnabled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 71: logfileChanged(); break;
        case 72: chooseLogfile(); break;
        case 73: partialOppoRackEnabled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 74: partialOppoRackChanged(); break;
        case 75: showSimulationDetails(); break;
        case 76: startBirthday(); break;
        case 77: birthdayBash(); break;
        case 78: birthdayGram((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        }
        _id -= 79;
    }
    return _id;
}

// SIGNAL 0
void TopLevel::positionChanged(const Quackle::GamePosition & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void TopLevel::movesChanged(const Quackle::MoveList & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void TopLevel::historyChanged(const Quackle::History & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
static const uint qt_meta_data_KibitzerListener[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      33,   18,   17,   17, 0x05,
      68,   18,   17,   17, 0x05,

 // slots: signature, parameters, type, tag, flags
     103,   17,   17,   17, 0x0a,
     121,   17,   17,   17, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_KibitzerListener[] = {
    "KibitzerListener\0\0computerPlayer\0kibitzAs(Quackle::ComputerPlayer*)\0"
    "reportAs(Quackle::ComputerPlayer*)\0kibitzTriggered()\0"
    "reportTriggered()\0"
};

const QMetaObject KibitzerListener::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_KibitzerListener,
      qt_meta_data_KibitzerListener, 0 }
};

const QMetaObject *KibitzerListener::metaObject() const
{
    return &staticMetaObject;
}

void *KibitzerListener::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_KibitzerListener))
	return static_cast<void*>(const_cast<KibitzerListener*>(this));
    return QObject::qt_metacast(_clname);
}

int KibitzerListener::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: kibitzAs((*reinterpret_cast< Quackle::ComputerPlayer*(*)>(_a[1]))); break;
        case 1: reportAs((*reinterpret_cast< Quackle::ComputerPlayer*(*)>(_a[1]))); break;
        case 2: kibitzTriggered(); break;
        case 3: reportTriggered(); break;
        }
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void KibitzerListener::kibitzAs(Quackle::ComputerPlayer * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void KibitzerListener::reportAs(Quackle::ComputerPlayer * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

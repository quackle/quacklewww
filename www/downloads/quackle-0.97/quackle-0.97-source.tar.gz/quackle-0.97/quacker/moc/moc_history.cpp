/****************************************************************************
** Meta object code from reading C++ file 'history.h'
**
** Created: Mon Jul 21 15:26:27 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../history.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'history.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_History[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
      17,    9,    8,    8, 0x0a,
      55,   50,    8,    8, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_History[] = {
    "History\0\0history\0historyChanged(Quackle::History)\0item\0"
    "itemActivated(QTableWidgetItem*)\0"
};

const QMetaObject History::staticMetaObject = {
    { &HistoryView::staticMetaObject, qt_meta_stringdata_History,
      qt_meta_data_History, 0 }
};

const QMetaObject *History::metaObject() const
{
    return &staticMetaObject;
}

void *History::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_History))
	return static_cast<void*>(const_cast<History*>(this));
    return HistoryView::qt_metacast(_clname);
}

int History::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = HistoryView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: historyChanged((*reinterpret_cast< const Quackle::History(*)>(_a[1]))); break;
        case 1: itemActivated((*reinterpret_cast< QTableWidgetItem*(*)>(_a[1]))); break;
        }
        _id -= 2;
    }
    return _id;
}

/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef QUACKER_UTIL_H
#define QUACKER_UTIL_H

#include <QString>

#include <alphabetparameters.h>
#include <datamanager.h>
#include <uv.h>

namespace Quackle
{
	class Move;
}

class Util
{
public:
	static UVString qstringToString(const QString &qstring);
	static Quackle::LetterString encode(const QString &qstring);

	// encode as above but clear blankess of all letters
	static Quackle::LetterString nonBlankEncode(const QString &qstring);

	static QString uvStringToQString(const UVString &stdWString);
	static QString letterStringToQString(const Quackle::LetterString &letterString);
	static QString letterStringToQString(Quackle::Letter &letter);

	// non-ui strings
	static string qstringToStdString(const QString &qstring);
	static QString stdStringToQString(const string &stdString);

	static QString moveToDetailedString(const Quackle::Move &move, QString prettyTiles = QString::null);
	static QString moveToSensitiveString(const Quackle::Move &move);

	// arrange letters in word into sortOrder
	static QString arrangeLetters(const QString &word, const QString &sortOrder);

	// make alphagram
    static QString alphagram(const QString &word);

	// make pattern of letters user wants based on settings
	static QString arrangeLettersForUser(const QString &word);
	static QString arrangeLettersForUser(const Quackle::Rack &rack);
};

inline UVString Util::qstringToString(const QString &qstring)
{
#if QUACKLE_USE_WCHAR_FOR_USER_VISIBLE
	return qstring.toStdWString();
#else
	return qstringToStdString(qstring);
#endif
}

inline Quackle::LetterString Util::encode(const QString &qstring)
{
	return QUACKLE_ALPHABET_PARAMETERS->encode(qstringToString(qstring));
}

inline Quackle::LetterString Util::nonBlankEncode(const QString &qstring)
{
	return QUACKLE_ALPHABET_PARAMETERS->clearBlankness(encode(qstring));
}

inline QString Util::uvStringToQString(const UVString &uvString)
{
#if QUACKLE_USE_WCHAR_FOR_USER_VISIBLE
	return QString::fromStdWString(uvString);
#else
	return stdStringToQString(uvString);
#endif
}

inline QString Util::letterStringToQString(const Quackle::LetterString &letterString)
{
	return uvStringToQString(QUACKLE_ALPHABET_PARAMETERS->userVisible(letterString));
}

inline QString Util::letterStringToQString(Quackle::Letter &letter)
{
	return uvStringToQString(QUACKLE_ALPHABET_PARAMETERS->userVisible(letter));
}

inline string Util::qstringToStdString(const QString &qstring)
{
	return qstring.toStdString();
}

inline QString Util::stdStringToQString(const string &stdString)
{
	return QString::fromStdString(stdString);
}

#endif

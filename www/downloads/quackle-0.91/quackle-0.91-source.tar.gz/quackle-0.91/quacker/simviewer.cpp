/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>

#include <QtGui>

#include "simviewer.h"
#include "util.h"

SimViewer::SimViewer(QWidget *parent)
	: QDialog(parent)
{
	m_tabs = new QTabWidget;

	m_averagesTab = new AveragesTab;
	m_tabs->addTab(m_averagesTab, tr("&Averages"));

	QPushButton *closeButton = new QPushButton(tr("&Close"));
	closeButton->setDefault(true);

	connect(closeButton, SIGNAL(clicked()), this, SLOT(done()));

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch(1);
	buttonLayout->addWidget(closeButton);

	QVBoxLayout *topLayout = new QVBoxLayout;
	topLayout->addWidget(m_tabs);
	topLayout->addLayout(buttonLayout);
	setLayout(topLayout);

	setWindowTitle(tr("Simulation Results - Quackle"));
}

void SimViewer::setSimulator(const Quackle::Simulator &simulator)
{
	m_averagesTab->setSimulator(simulator);
	setWindowTitle(tr("%1 iterations of %2 - Quackle").arg(simulator.iterations()).arg(Util::letterStringToQString(simulator.currentPosition().currentPlayer().rack().tiles())));
}

void SimViewer::done()
{
	accept();
}

/////////////

AveragesTab::AveragesTab(QWidget *parent)
	: QWidget(parent)
{
	QVBoxLayout *topLayout = new QVBoxLayout(this);

	m_textEdit = new QTextEdit;
	m_textEdit->setReadOnly(true);

	QPushButton *explainButton = new QPushButton(tr("&Explain me!"));
	connect(explainButton, SIGNAL(clicked()), this, SLOT(explain()));

	topLayout->addWidget(m_textEdit);
	topLayout->addWidget(explainButton);
}

void AveragesTab::setSimulator(const Quackle::Simulator &simulator)
{
	QString html;

	const Quackle::SimmedMoveList::const_iterator end(simulator.simmedMoves().end());
	for (Quackle::SimmedMoveList::const_iterator it = simulator.simmedMoves().begin(); it != end; ++it)
	{
		if (!(*it).includeInSimulation())
			continue;

		QString levels;
		for (Quackle::LevelList::const_iterator levelIt = (*it).levels.begin(); levelIt != (*it).levels.end(); ++levelIt)
		{
			QString plays;
			for (Quackle::AveragedValueList::const_iterator valueIt = (*levelIt).scores.begin(); valueIt != (*levelIt).scores.end(); ++valueIt)
				plays += QString("(%1 [sd %2]) ").arg((*valueIt).averagedValue()).arg((*valueIt).standardDeviation());

			if (!plays.isEmpty())
				levels += QString("<li>%1</li>").arg(plays);
		}

		html += QString("<h3>%1</h3><ol>%2</ol>").arg(Util::moveToDetailedString((*it).move)).arg(levels);

		html += QString("<ul><li>Residual: %1 (sd %2)</li><li>Spread: %3 (sd %4)</li><li>Fake win %: %5%</li></ul>").arg((*it).residual.averagedValue()).arg((*it).residual.standardDeviation()).arg((*it).gameSpread.averagedValue()).arg((*it).gameSpread.standardDeviation()).arg((*it).winPercentage());
	}

	// TODO don't scroll to top when resetting
	m_textEdit->setHtml(html);
}

void AveragesTab::explain()
{
	QMessageBox::information(this, tr("Simulation Details Explanation - Quackle"), tr("<p>A Quackle 2-ply simulation first puts our candidate play on the board, then has opponents make their best plays based on static evaluation, and has us make our best response based on static evaluation. So</p><ol><li>(28 [sd 0]) (39.1503 [sd 17.8229])</li><li>(45.1284 [sd 21.0234])</li></ol><p>means we're looking at a candidate play scoring 28. The average oppo response scored 39.2 with standard deviation 17.8. Our average riposte scored 45.1 with standard deviation 21.0.</p><ul><li>The residual value is the average leave value of our rack at the end of simulation minus the summed average leave value of oppo's racks.</li><li>The spread is the average differential between our score and the leading player's score at the end of an iteration.</li><li>The fake win percentage is how often we had a positive spread at the end of the iteration.</li></ul><p>Note that odd-plied simulations are great things to do. For example, a 3-ply simulation has two of our plays (including the candidate) and two of each oppo's plays. Also try the <i>Oppos pass</i> option, which has oppos pass for all of their turns in the simulation.</p>"));
}


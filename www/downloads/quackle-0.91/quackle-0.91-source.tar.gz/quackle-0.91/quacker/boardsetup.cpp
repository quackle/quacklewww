/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>
#include <math.h>

#include <QtGui>

#include <game.h>
#include <move.h>
#include <boardparameters.h>

#include "boardsetup.h"
#include "util.h"

BoardSetup::BoardSetup(QWidget *parent)
	: View(parent)
{
	m_vlayout = new QVBoxLayout(this);

	m_boardFrame = new BoardSetupFrame;
	m_boardWrapper = new QWidget;

	QLabel *helperLabel = new QLabel(tr("Click or right-click on a board square to cycle through bonuses. Shift-click on a square to designate it as the square that starts the game."));
	helperLabel->setWordWrap(true);

	QVBoxLayout *helperLayout = new QVBoxLayout(m_boardWrapper);
	helperLayout->setMargin(0);

	m_vlayout->addWidget(helperLabel);
	m_vlayout->addWidget(m_boardWrapper);
	helperLayout->addWidget(m_boardFrame);
	m_vlayout->setStretchFactor(m_boardWrapper, 10);

	m_subviews.push_back(m_boardFrame);
	connectSubviewSignals();
}

void BoardSetup::expandToFullWidth()
{
	m_boardFrame->expandToSize(m_boardWrapper->size());
}

void BoardSetup::resizeEvent(QResizeEvent * /* event */)
{
	QTimer::singleShot(0, this, SLOT(expandToFullWidth()));
}

///////////////////

BoardSetupFrame::BoardSetupFrame(QWidget *parent)
	: GraphicalBoardFrame(parent)
{
}

BoardSetupFrame::~BoardSetupFrame()
{
}


void BoardSetupFrame::setBoard(const Quackle::Board &board)
{
	m_board = board;
}

void BoardSetupFrame::setSymmetry(bool horizontal, bool vertical)
{
	horizontalSymmetry = horizontal;
	verticalSymmetry = vertical;
}

void BoardSetupFrame::parametersChanged()
{
	flushPixmapsAndRedraw();
}

void BoardSetupFrame::tileClicked(const QSize &tileLocation, const QMouseEvent *event)
{
	const int row = tileLocation.height();
	const int col = tileLocation.width();
	
	// set starting point...
	if (event->button() == Qt::LeftButton && (event->modifiers() & Qt::SHIFT) != 0)
	{
		QUACKLE_BOARD_PARAMETERS->setStartRow(row);
		QUACKLE_BOARD_PARAMETERS->setStartColumn(col);
		prepare();
		return;
	}
	
	// or change the value of a square
	const int maxLetterMultiplier = (int) Quackle::BoardParameters::lsCount;
	const int maxWordMultiplier = (int) Quackle::BoardParameters::wsCount;
	const int maxMultiplier = maxLetterMultiplier + maxWordMultiplier - 1;
	int wordMultiplier = QUACKLE_BOARD_PARAMETERS->wordMultiplier(row, col);
	int letterMultiplier = QUACKLE_BOARD_PARAMETERS->letterMultiplier(row, col);
	int combinedMultipliers = (wordMultiplier == 1) ? letterMultiplier : (maxLetterMultiplier + wordMultiplier - 1);

	if (event->button() == Qt::LeftButton)
		combinedMultipliers++;
	else
		combinedMultipliers--;

	if (combinedMultipliers < 1)
		combinedMultipliers = maxMultiplier;
	else if (combinedMultipliers > maxMultiplier)
		combinedMultipliers = 1;

	if (combinedMultipliers <= maxLetterMultiplier)
	{
		wordMultiplier = 1;
		letterMultiplier = combinedMultipliers;
	}
	else
	{
		wordMultiplier = combinedMultipliers - maxLetterMultiplier + 1;
		letterMultiplier = 1;
	}

	setMultipliers(row, col, wordMultiplier, letterMultiplier);

	const int height = QUACKLE_BOARD_PARAMETERS->height();
	const int width = QUACKLE_BOARD_PARAMETERS->width();

	if (horizontalSymmetry)
		setMultipliers(row, width - 1 - col, wordMultiplier, letterMultiplier);
	if (verticalSymmetry)
		setMultipliers(height - 1 - row, col, wordMultiplier, letterMultiplier);
	if (horizontalSymmetry && verticalSymmetry)
		setMultipliers(height - 1 - row, width - 1 - col, wordMultiplier, letterMultiplier);
		
	prepare();
}

bool BoardSetupFrame::wantMousePressEvent(const QMouseEvent *event) const
{
	return (event->button() == Qt::LeftButton || event->button() == Qt::RightButton);
}

void BoardSetupFrame::setMultipliers(int row, int col, int word, int letter)
{
	QUACKLE_BOARD_PARAMETERS->setWordMultiplier(row, col, (Quackle::BoardParameters::WordMultiplier) word);
	QUACKLE_BOARD_PARAMETERS->setLetterMultiplier(row, col, (Quackle::BoardParameters::LetterMultiplier) letter);
}

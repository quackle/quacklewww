/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <QtGui>

#include <game.h>

#include "bagdisplay.h"
#include "brb.h"
#include "boarddisplay.h"
#include "rackdisplay.h"
#include "widgetfactory.h"

BRB::BRB(WidgetFactory *widgetFactory, QWidget *parent)
	: View(parent)
{
	QHBoxLayout *topHorizontalLayout = new QHBoxLayout;
	setLayout(topHorizontalLayout);

	QVBoxLayout *leftVerticalLayout = new QVBoxLayout;
	topHorizontalLayout->addLayout(leftVerticalLayout);
	QVBoxLayout *rightVerticalLayout = new QVBoxLayout;
	topHorizontalLayout->addLayout(rightVerticalLayout);

	m_boardDisplay = widgetFactory->createBoardDisplay();
	leftVerticalLayout->addWidget(m_boardDisplay);

	m_rackDisplay = widgetFactory->createRackDisplay();
	leftVerticalLayout->addWidget(m_rackDisplay);

	topHorizontalLayout->setStretchFactor(leftVerticalLayout, 10);

	m_bagDisplay = widgetFactory->createBagDisplay();
	rightVerticalLayout->addWidget(m_bagDisplay);

	m_subviews.push_back(m_boardDisplay);
	m_subviews.push_back(m_rackDisplay);
	m_subviews.push_back(m_bagDisplay);
	connectSubviewSignals();

	widgetFactory->finishUp(m_boardDisplay, m_rackDisplay, m_bagDisplay);
}

BRB::~BRB()
{
}

View * BRB::getBoardView() const
{
	return m_boardDisplay;
}

void BRB::grabFocus()
{
	m_rackDisplay->grabFocus();
}

void BRB::positionChanged(const Quackle::GamePosition &position)
{
	View::positionChanged(position);
}


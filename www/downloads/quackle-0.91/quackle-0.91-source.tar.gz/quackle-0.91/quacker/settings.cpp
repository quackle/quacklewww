/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>
#include <sstream>
#include <sys/stat.h>

#include <QtGui>
#include <QMessageBox>

#include <board.h>
#include <boardparameters.h>
#include <datamanager.h>
#include <game.h>
#include <lexiconparameters.h>
#include <rack.h>
#include <strategyparameters.h>

#include "settings.h"
#include "util.h"
#include "boardsetupdialog.h"
#include "graphicalboard.h"

Settings *Settings::m_self = 0;
Settings *Settings::self()
{
	return m_self;
}

Settings::Settings(QWidget *parent)
	: QWidget(parent), m_lexiconNameCombo(0), m_vowelFirst(false)
{
	m_self = this;
}

void Settings::createGUI()
{
	if (m_lexiconNameCombo != 0)
		return;

	QVBoxLayout *vlayout = new QVBoxLayout(this);

	m_lexiconNameCombo = new QComboBox();
	connect(m_lexiconNameCombo, SIGNAL(activated(const QString &)), this, SLOT(lexiconChanged(const QString &)));

	QStringList items;
	items << "twl06" << "twl98" << "sowpods";
	m_lexiconNameCombo->addItems(items);

	QHBoxLayout *lexiconLayout = new QHBoxLayout;
	QLabel *lexiconNameLabel = new QLabel(tr("&Lexicon:"));
	lexiconNameLabel->setBuddy(m_lexiconNameCombo);

	lexiconLayout->addWidget(lexiconNameLabel);
	lexiconLayout->addWidget(m_lexiconNameCombo);

	m_boardNameCombo = new QComboBox();
	connect(m_boardNameCombo, SIGNAL(activated(const QString &)), this, SLOT(boardChanged(const QString &)));

	m_addBoard = new QPushButton(tr("&Add Board"));
	connect(m_addBoard, SIGNAL(clicked()), this, SLOT(addBoard()));
	
	m_editBoard = new QPushButton(tr("&Edit Board"));
	connect(m_editBoard, SIGNAL(clicked()), this, SLOT(editBoard()));
	
	m_deleteBoard = new QPushButton(tr("&Delete Board"));
	connect(m_deleteBoard, SIGNAL(clicked()), this, SLOT(deleteBoard()));

	loadBoardNameCombo();
		
	QGroupBox *boardGroup = new QGroupBox("Game Board Definitions");
	QGridLayout *boardLayout = new QGridLayout(boardGroup);
	QLabel *boardNameLabel = new QLabel(tr("&Board:"));
	boardNameLabel->setBuddy(m_boardNameCombo);

	boardLayout->addWidget(boardNameLabel, 0, 0);
	boardLayout->addWidget(m_boardNameCombo, 0, 1, 1, -1);
	boardLayout->addWidget(m_addBoard, 1, 0);
	boardLayout->addWidget(m_editBoard, 1, 1);
	boardLayout->addWidget(m_deleteBoard, 1, 2);

	m_vowelFirstCheck = new QCheckBox(tr("&Vowel-first order"));
	connect(m_vowelFirstCheck, SIGNAL(clicked(bool)), this, SLOT(vowelFirstChanged(bool)));

	vlayout->addLayout(lexiconLayout);
	vlayout->addWidget(boardGroup);
	vlayout->addWidget(m_vowelFirstCheck);
	vlayout->addStretch();

	load();
}

void Settings::load()
{
	m_lexiconNameCombo->setCurrentIndex(m_lexiconNameCombo->findText(Util::stdStringToQString(QUACKLE_LEXICON_PARAMETERS->lexiconName())));
	m_boardNameCombo->setCurrentIndex(m_boardNameCombo->findText(Util::uvStringToQString(QUACKLE_BOARD_PARAMETERS->name())));
	m_vowelFirstCheck->setChecked(m_vowelFirst);
}

void Settings::initialize()
{
	QSettings settings;

	struct stat buf;
	if (!stat("data", &buf) && (buf.st_mode & S_IFDIR))
		QUACKLE_DATAMANAGER->setDataDirectory("data");
	else
		QUACKLE_DATAMANAGER->setDataDirectory("../data");

	setQuackleToUseLexiconName(Util::qstringToStdString(settings.value("quackle/settings/lexicon-name", QString("twl06")).toString()));
	setQuackleToUseBoardName(settings.value("quackle/settings/board-name", QString("")).toString());

	m_vowelFirst = settings.value("quackle/settings/vowel-first", false).toBool();
}

void Settings::setQuackleToUseLexiconName(const string &lexiconName)
{
	if (QUACKLE_LEXICON_PARAMETERS->lexiconName() != lexiconName)
	{
		QUACKLE_LEXICON_PARAMETERS->setLexiconName(lexiconName);
		QUACKLE_LEXICON_PARAMETERS->loadDawg(Quackle::LexiconParameters::findDictionaryFile(lexiconName + ".dawg"));
		QUACKLE_STRATEGY_PARAMETERS->initialize(Quackle::StrategyParameters::findStrategyDirectory(lexiconName));
	}
}

void Settings::setQuackleToUseBoardName(const QString &boardName)
{
	QSettings settings;
	settings.beginGroup("quackle/boardparameters");

	if (boardName.isEmpty() || !settings.contains(boardName))
		QUACKLE_DATAMANAGER->setBoardParameters(new Quackle::BoardParameters());
	else
	{
		QByteArray boardParameterBytes = qUncompress(settings.value(boardName).toByteArray());
		string boardParameterBuf;
		boardParameterBuf.assign((const char *) boardParameterBytes, boardParameterBytes.size());
		istringstream boardParameterStream(boardParameterBuf);
		
		QUACKLE_DATAMANAGER->setBoardParameters(Quackle::BoardParameters::Deserialize(boardParameterStream));
	}
	QUACKLE_BOARD_PARAMETERS->setName(Util::qstringToString(boardName));
	loadBoardNameCombo();
}

void Settings::lexiconChanged(const QString &lexiconName)
{
	string lexiconNameString = Util::qstringToStdString(lexiconName);
	setQuackleToUseLexiconName(lexiconNameString);

	QSettings settings;
	settings.setValue("quackle/settings/lexicon-name", lexiconName);
}

void Settings::boardChanged(const QString &boardName)
{
	QSettings settings;
	settings.setValue("quackle/settings/board-name", boardName);

	setQuackleToUseBoardName(boardName);

	QMessageBox::information(this, tr("Please Be Patient - Quackle"), tr("Start a new game to allow time for the concierge to get through the microearthquake with a fresh board."));
}

void Settings::addBoard()
{
	QUACKLE_DATAMANAGER->setBoardParameters(new Quackle::BoardParameters());
	QUACKLE_BOARD_PARAMETERS->setName(MARK_UV(""));
	
	QSettings settings;
	BoardSetupDialog dialog(this);
	if (dialog.exec())
	{
		QString boardName = Util::uvStringToQString(QUACKLE_BOARD_PARAMETERS->name());
		settings.beginGroup("quackle/boardparameters");
		
		ostringstream boardParameterStream;
		QUACKLE_BOARD_PARAMETERS->Serialize(boardParameterStream);
		
		QByteArray boardParameterBytes = qCompress(QByteArray(
							(const char *)boardParameterStream.str().data(),
							boardParameterStream.str().size()));
		settings.setValue(boardName, QVariant(boardParameterBytes));
		boardChanged(boardName);
	}
	else
		setQuackleToUseBoardName(settings.value("quackle/settings/board-name", QString("")).toString());

	PixmapCacher::self()->invalidate();
}

void Settings::editBoard()
{
	QString oldBoardName = m_boardNameCombo->currentText();
	QUACKLE_BOARD_PARAMETERS->setName(Util::qstringToString(oldBoardName));

	BoardSetupDialog dialog(this);
	if (dialog.exec())
	{
		QString newBoardName = Util::uvStringToQString(QUACKLE_BOARD_PARAMETERS->name());
		QSettings settings;
		settings.beginGroup("quackle/boardparameters");
	
		if (newBoardName != oldBoardName)
			settings.remove(oldBoardName);
		
		ostringstream boardParameterStream;
		QUACKLE_BOARD_PARAMETERS->Serialize(boardParameterStream);
		
		QByteArray boardParameterBytes = qCompress(QByteArray(
							(const char *)boardParameterStream.str().data(),
							boardParameterStream.str().size()));
		settings.setValue(newBoardName, QVariant(boardParameterBytes));
		boardChanged(newBoardName);
	}
	PixmapCacher::self()->invalidate();
}

void Settings::deleteBoard()
{
	int oldIndex = m_boardNameCombo->currentIndex();
	QString boardName = m_boardNameCombo->currentText();
	QString message = "Do you really want to delete the game board \"";
	message += boardName;
	message += "\"?";
	if (QMessageBox::warning(NULL, QString("Confirm Deletion"), message,
			QMessageBox::Yes | QMessageBox::Default,
			QMessageBox::No | QMessageBox::Escape) == QMessageBox::Yes)
	{
		QSettings settings;
		settings.beginGroup("quackle/boardparameters");
		settings.remove(boardName);
		loadBoardNameCombo();
		if (oldIndex != 0)
			oldIndex--;
		m_boardNameCombo->setCurrentIndex(oldIndex);
		boardChanged(m_boardNameCombo->currentText());
	}
}

void Settings::loadBoardNameCombo()
{
	if (m_lexiconNameCombo == 0)
		return;

	while (m_boardNameCombo->count() > 0)
		m_boardNameCombo->removeItem(0);
	
	QSettings settings;
	settings.beginGroup("quackle/boardparameters");
	QStringList boardNames = settings.childKeys();
	boardNames.sort();
	m_boardNameCombo->addItems(boardNames);
	settings.endGroup();
	
	QString currentItem = settings.value("quackle/settings/board-name", QString("")).toString();
	m_boardNameCombo->setCurrentIndex(m_boardNameCombo->findText(currentItem));
	
	m_editBoard->setEnabled(boardNames.count() > 0);
	m_deleteBoard->setEnabled(boardNames.count() > 0);
}

void Settings::vowelFirstChanged(bool vowelFirst)
{
	m_vowelFirst = vowelFirst;

	QSettings settings;
	settings.setValue("quackle/settings/vowel-first", vowelFirst);
}


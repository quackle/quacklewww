/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <string>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <vector>
#include <map>

using namespace std;

class Node {
public:
    char c;
    bool t;
    vector<Node> children;
    int pointer;
    bool lastchild;
    void pushword(string word);
    void print(string prefix);
};


vector< Node* > nodelist;


void Node::print(string prefix) {
    if (t) {
        // cout << prefix << endl;
    }

    // cout << "prefix: " << prefix << ", children: " << children.size() << endl;

    if (children.size() > 0) {    
        pointer = nodelist.size();
        children[children.size() - 1].lastchild = true;
    }

    for (int i = 0; i < children.size(); i++) {
        nodelist.push_back(&children[i]);
    }

    for (int i = 0; i < children.size(); i++) {
        children[i].print(prefix + children[i].c);
    }
}


void Node::pushword(string word) {
    if (word.length() == 0) {
        t = true;
    }
    else {
        char first = word[0];
        string rest = word.substr(1, word.length() - 1);
        int index = -1;
 
        // cout << "first: " << first << ", rest: " << rest << endl;

        for (int i = 0; i < children.size(); i++) {
            if (children[i].c == first) {
                index = i;
                i = children.size();
            }
        }
        
        if (index == -1) {
            Node n;
            n.c = first;
            n.t = false;
            n.pointer = 0;
            n.lastchild = false;
            children.push_back(n);
            index = children.size() - 1;
        }

        children[index].pushword(rest);
    }
}


int main() {
    ifstream file("gaddag.raw");
    //ifstream file("testdic");

    Node root;
    root.t = false;
    root.c = '.';
    root.pointer = 0;
    root.lastchild = true;

    while(!file.eof()) {
        string word;
        file >> word;
        if (!file.eof()) {
            root.pushword(word);
        }
    }

    nodelist.push_back(&root);

    root.print("");    

    ofstream out("twl.gaddag", ios::out | ios::binary);

    for (int i = 0; i < nodelist.size(); i++) {
        // cout << nodelist[i]->c << " " << nodelist[i]->pointer << " " << nodelist[i]->t << " " << nodelist[i]->lastchild << endl;

        unsigned int p = (unsigned int)(nodelist[i]->pointer);
        
        char bytes[4];
        unsigned char n1 = (p & 0x00FF0000) >> 16;
/*
        cout << "byte 1: " << ((p & 0xFF000000) >> 24); 
        cout << ", byte 2: " << ((p & 0x00FF0000) >> 8);
        cout << ", byte 3: " << ((p & 0x0000FF00) >> 8);
        cout << ", byte 4: " << ((p & 0x000000FF) >> 0) << endl;
*/

        unsigned char n2 = (p & 0x0000FF00) >> 8;
        unsigned char n3 = (p & 0x000000FF) >> 0;
        unsigned char n4; 

/*
        cout << "p: " << p << ", crap: " << (((unsigned int)(n1) << 24) | 
                                           ((unsigned int)(n2) << 16) | 
                                           ((unsigned int)(n3) << 8)) << endl;
*/
        if (nodelist[i]->c == '^') {
            n4 = 27; // 26 is reserved for blank
        }
        else {
            n4 = nodelist[i]->c - 'A';
        }
        
        
        if (nodelist[i]->t) {
            n4 |= 32;
        }
        if (nodelist[i]->lastchild) {
            n4 |= 64;
        }

/*
        cout << "p: " << p << endl;;
        cout << "n4:" << (int)(n4) << 
                ", n1: " << (int)(n1) << 
                ", n2: " << (int)(n2) <<
                ", n3: " << (int)(n3) << endl;
*/

        bytes[0] = n4; bytes[1] = n1; bytes[2] = n2; bytes[3] = n3;
        //bytes[0] = n3; bytes[1] = n2; bytes[2] = n1; bytes[3] = n4;
        //out.write((const char*) &p, 4);
        out.write(bytes, 4);
    }
}

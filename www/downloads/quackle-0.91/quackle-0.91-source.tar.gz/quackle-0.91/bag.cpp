/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <algorithm>
#include <iostream>

#include "alphabetparameters.h"
#include "bag.h"
#include "datamanager.h"
#include "gameparameters.h"
#include "rack.h"
#include "move.h"

using namespace std;
using namespace Quackle;

Bag::Bag()
{
	prepareFullBag();
}

void Bag::clear()
{
	m_tiles.clear();
}

void Bag::prepareFullBag()
{
	// put stuff in here to fill the bag
	m_tiles.clear();

	// we start at 0 because we want to include blanks etcetera
	for (Letter letter = 0; letter <= QUACKLE_ALPHABET_PARAMETERS->lastLetter(); ++letter)
		for (int i = 0; i < QUACKLE_ALPHABET_PARAMETERS->count(letter); ++i)
			m_tiles.push_back(letter);
}

void Bag::toss(const LetterString &letters)
{
	const LetterString::const_iterator end(letters.end());
	for (LetterString::const_iterator it = letters.begin(); it != end; ++it)
		m_tiles.push_back(*it);
}

Letter Bag::erase(int pos)
{
	LetterString::iterator it = m_tiles.begin();

	for (int i = 0; i < pos; ++it, ++i) ;

	Letter ret = *it;
	m_tiles.erase(it);

	return ret;
}

void Bag::exch(const Move &move, Rack &rack)
{
	// CHANGEDCODE
	LetterString usedTiles(move.usedTiles());
	rack.unload(usedTiles);

	refill(rack);
	toss(usedTiles);                                                                                                                        
}

Letter Bag::pluck()
{
	return erase(DataManager::self()->randomNumber() % m_tiles.size());
}

bool Bag::removeLetters(const LetterString &letters)
{
	bool ret = true;

	const LetterString::const_iterator end(letters.end());
	for (LetterString::const_iterator it = letters.begin(); it != end; ++it)
		if (!removeLetter(*it))
			ret = false;

	return ret;
}

bool Bag::removeLetter(Letter letter)
{
	LetterString::iterator it;
	const LetterString::iterator end(m_tiles.end());
	for (it = m_tiles.begin(); it != end; ++it)
		if (*it == letter)
			break;

	if (it == m_tiles.end())
		return false;

	m_tiles.erase(it);
	return true;
}

void Bag::refill(Rack &rack)
{
	for (int number = QUACKLE_PARAMETERS->rackSize() - rack.tiles().length(); number > 0 && !m_tiles.empty(); --number)
		rack.setTiles(Rack::alphabetize(rack.tiles() + pluck()));
}

LetterString Bag::refill(Rack &rack, const LetterString &drawingOrder)
{
	LetterString ret(drawingOrder);

	for (int number = QUACKLE_PARAMETERS->rackSize() - rack.tiles().length(); number > 0 && !m_tiles.empty(); --number)
	{
		if (drawingOrder.empty())
			rack.setTiles(Rack::alphabetize(rack.tiles() + pluck()));
		else
		{
			removeLetter(String::back(ret));
			rack.setTiles(Rack::alphabetize(rack.tiles() + String::back(ret)));
			String::pop_back(ret);
		}
	}

	return ret;
}

LetterString Bag::shuffledTiles() const
{
	LetterString ret(tiles());
	random_shuffle(ret.begin(), ret.end());
	return ret;
}

int factorial(int n)
{
	if (n < 0)
		return 0;

	switch (n)
	{
	case 0:
	case 1:
		return 1;
	case 2:
		return 2;
	case 3:
		return 6;
	case 4:
		return 24;
	case 5:
		return 120;
	case 6:
		return 720;
	case 7:
		return 5040;
	case 8:
		return 40320;
	case 9:
		return 362880;
	case 10:
		return 3628800;
	case 11:
		return 39916800;
	case 12:
		return 479001600;
	
	default:
		return factorial(n - 1) * n;
	}
}

int nCr(int n, int r)
{
	// don't worry about blanks yet
	if (r > n)
		return 0;

	return factorial(n) / (factorial(r) * factorial(n - r));
}

double Bag::probabilityOfDrawingFromFullBag(const LetterString &letters)
{
	char counts[QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE];
	String::counts(String::clearBlankness(letters), counts);

	float ret = 1;

	for (Letter letter = 0; letter <= QUACKLE_ALPHABET_PARAMETERS->lastLetter(); ++letter)
		if (counts[letter] > 0)
			ret *= nCr(QUACKLE_ALPHABET_PARAMETERS->count(letter), counts[letter]);

	return ret;
}

double Bag::probabilityOfDrawingFromBag(const LetterString &letters, const Bag &bag)
{
	char bagCounts[QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE];
	String::counts(bag.tiles(), bagCounts);

	char counts[QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE];
	String::counts(String::clearBlankness(letters), counts);

	float ret = 1;

	for (Letter letter = 0; letter < QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE; ++letter)
		if (counts[letter] > 0)
			ret *= nCr(bagCounts[letter], counts[letter]);

	return ret;
}

double Bag::probabilityOfDrawing(const LetterString &letters)
{
	return probabilityOfDrawingFromBag(letters, *this);
}


UVString Bag::toString() const
{
	UVString ret;

	LetterString sortedLetters = m_tiles;
	sort(sortedLetters.begin(), sortedLetters.end());

	const LetterString::const_iterator end(sortedLetters.end());
	for (LetterString::const_iterator it = sortedLetters.begin(); it != end; ++it)
		ret += QUACKLE_ALPHABET_PARAMETERS->userVisible(*it);

	return ret;
}

UVOStream &operator<<(UVOStream &o, const Bag &bag)
{
	o << "Bag (" << bag.size() << "): ";

	if (bag.empty())
		o << "[empty]";
	else
		o << bag.toString();

	return o;
}


/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef QUACKLE_COMPUTERPLAYER_H
#define QUACKLE_COMPUTERPLAYER_H

#include "sim.h"

namespace Quackle
{

class ComputerPlayer
{
public:
	enum Type { StaticComputer = 0, StrongComputer = 1, EndgameComputer = 2};

	// constructs a new computer player
	ComputerPlayer();
	virtual ~ComputerPlayer();

	// return a new computer player of specified type,
	// or 0 if we don't know how to make something of this type
	static ComputerPlayer *createComputerPlayer(int type);

	// prepare to generate move for current player
	// on this position
	void setPosition(const GamePosition &position);

	// get access to the position that we're playing from
	GamePosition &currentPosition();
	const GamePosition &currentPosition() const;

	virtual Move move() = 0;

protected:
	Simulator m_simulator;
};

inline GamePosition &ComputerPlayer::currentPosition()
{
	return m_simulator.currentPosition();
}

inline const GamePosition &ComputerPlayer::currentPosition() const
{
	return m_simulator.currentPosition();
}

class StaticPlayer : public ComputerPlayer
{
public:
	StaticPlayer();
	virtual ~StaticPlayer();

	virtual Move move();
};

}

#endif

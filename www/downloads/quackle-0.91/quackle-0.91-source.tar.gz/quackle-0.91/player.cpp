/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>
#include <sstream>

#include "player.h"

using namespace Quackle;

Player::Player()
	: m_name(MARK_UV("No Name")), m_id(-1), m_playerType(ComputerPlayer), m_computerType(0), m_score(0)  
{
}

Player::Player(const UVString &name, int playerType, int computerType, int id)
	: m_name(name), m_id(id), m_playerType(playerType), m_computerType(computerType), m_score(0)
{
}

void Player::addToScore(int addition)
{
	m_score += addition;
}

UVString Player::storeInformationToString() const
{
	UVOStringStream ss;
	ss << m_id << ';' << m_playerType << ';' << m_computerType << ';' << m_name;
	return ss.str();
}

void Player::loadInformationFromString(const UVString &info)
{
	int i = 0;
	UVString whatIsLeft(info);
	for (int semicolonIndex; i <= 2; ++i)
	{
		//UVcout << "what is left: " << whatIsLeft << endl;

		semicolonIndex = whatIsLeft.find(MARK_UV(';'));

		if (semicolonIndex == string::npos)
			break;

		UVString itemString = whatIsLeft.substr(0, semicolonIndex);
		whatIsLeft = whatIsLeft.substr(semicolonIndex + 1);

		UVStringStream ss(itemString);
		int itemInt;
		ss >> itemInt;

		switch (i)
		{
		case 0:
			m_id = itemInt;
			break;

		case 1:
			m_playerType = itemInt;
			break;

		case 2:
			m_computerType = itemInt;
			break;

		default:
			break;
		}
	}

	m_name = whatIsLeft;
}

Player Player::makePlayerFromString(const UVString &info)
{
	Player ret;
	ret.loadInformationFromString(info);
	return ret;
}

UVOStream &operator<<(UVOStream &o, const Quackle::Player &player)
{
	o << (player.type() == Quackle::Player::ComputerPlayer? MARK_UV("Computer") : MARK_UV("Human")) << " Player " << player.name() << " (id " << player.id() << ")" << " with score " << player.score() << " holding " << player.rack() << " after drawing [" << player.drawnLetters() << "]";
	return o;
}


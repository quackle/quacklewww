/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>

#include "strongplayer.h"

//#define DEBUG_COMPUTERPLAYER

using namespace Quackle;

StrongPlayer::StrongPlayer()
{
}

StrongPlayer::~StrongPlayer()
{
}

Move StrongPlayer::move()
{
	UVcout << "StrongPlayer generating move from position:" << endl;
	UVcout << m_simulator.currentPosition() << endl;

	const int initialPlayNumber = 50;
	const int zerothPrune = 13;
	const int zerothPruneMax = 20;
	const int firstIterations = 40;

	m_simulator.currentPosition().kibitz(initialPlayNumber);
	m_simulator.setIncludedMoves(m_simulator.currentPosition().moves());

	UVcout << "Statically evaluated plays:" << endl;
	UVcout << m_simulator.currentPosition().moves() << endl;

	m_simulator.pruneTo(zerothPrune, zerothPruneMax);

	UVcout << "Pruned to plays within " << zerothPrune << ":" << endl;
	UVcout << m_simulator.moves(true) << endl;

	m_simulator.setIgnoreOppos(true);
	m_simulator.simulate(2, firstIterations);

	UVcout << "after " << firstIterations << " iterations of us-only sim:" << endl;
	UVcout << m_simulator.moves(true) << endl;

	const int firstPrune = 6;
	const int firstPruneMax = 6;
	const int secondIterations = 150;

	m_simulator.pruneTo(firstPrune, firstPruneMax);

	MoveList moves(m_simulator.moves(true));
	UVcout << "Pruned to plays within " << firstPrune << ":" << endl;
	UVcout << moves << endl;

	if (moves.size() == 1)
		return moves.back();

	m_simulator.resetNumbers();
	m_simulator.setIgnoreOppos(false);
	m_simulator.simulate(2, secondIterations);

	moves = m_simulator.moves(true);

	UVcout << "after " << secondIterations << " iterations of two-ply sim:" << endl;
	UVcout << moves << endl;

	return moves[0];
}


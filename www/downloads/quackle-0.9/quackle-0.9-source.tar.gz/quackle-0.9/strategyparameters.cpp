/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>
#include <fstream>

#include "datamanager.h"
#include "strategyparameters.h"

using namespace Quackle;

StrategyParameters::StrategyParameters()
	: m_initialized(false)
{
	for (int i = 0; i < QUACKLE_MAXIMUM_ALPHABET_SIZE; ++i)
	{
		for (int j = 0; j < QUACKLE_MAXIMUM_ALPHABET_SIZE; ++j)
			m_syn2[i][j] = 0;

		m_tileWorths[i] = 0;
	}
}

void StrategyParameters::initialize(const string &directory)
{
	bool hasSyn2 = loadSyn2(DataManager::self()->findFile(directory + "/syn2"));
	bool hasWorths = loadWorths(DataManager::self()->findFile(directory + "/worths"));

	m_initialized = hasSyn2 && hasWorths;
}

string StrategyParameters::findStrategyDirectory(const string &directory)
{
	return "strategy/" + directory;
}

bool StrategyParameters::loadSyn2(const string &filename)
{
	for (int i = 0; i < QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE; ++i)
		for (int j = 0; j < QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE; ++j)
			m_syn2[i][j] = 0;

	UVIFStream file(filename.c_str());

	if (!file.is_open())
	{
		cerr << "Could not open " << filename << " to load syn2" << endl;
		return false;
	}

	while (!file.eof())
	{
		UVString letters;
		file >> letters;

		if (letters.empty())
			continue;

		LetterString letterString = QUACKLE_ALPHABET_PARAMETERS->encode(letters);
		if (letterString.length() != 2)
		{
			UVcerr << "letter string " << letterString << " is not two letters while reading syn2" << endl;
			break;
		}

		if (file.eof())
			break;

		double value;
		file >> value;

		m_syn2[letterString[0]][letterString[1]] = value;
		m_syn2[letterString[1]][letterString[0]] = value;
	}

	file.close();
	return true;
}

bool StrategyParameters::loadWorths(const string &filename)
{
	for (int i = 0; i < QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE; ++i)
		m_tileWorths[i] = 0;

	UVIFStream file(filename.c_str());

	if (!file.is_open())
	{
		cerr << "Could not open " << filename << " to load worths" << endl;
		return false;
	}

	while (!file.eof())
	{
		UVString letters;
		file >> letters;

		if (letters.empty())
			continue;

		LetterString letterString = QUACKLE_ALPHABET_PARAMETERS->encode(letters);
		if (letterString.length() != 1)
		{
			UVcerr << "letter string " << letterString << " is not one letter while reading worths" << endl;
			break;
		}

		if (file.eof())
			break;

		double value;
		file >> value;

		m_tileWorths[letterString[0]] = value;
	}

	file.close();
	return true;
}


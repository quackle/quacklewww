/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <algorithm>
#include <iostream>

#include "datamanager.h"
#include "move.h"
#include "rack.h"
#include "uv.h"

using namespace std;
using namespace Quackle;

bool Rack::unload(const LetterString &used)
{
	// UVcout << *this << ".unload(" << used << ")" << endl;

	LetterString newtiles = m_tiles;
	bool ret = true;

	LetterString::const_iterator usedEnd(used.end());
	for (LetterString::const_iterator usedIt = used.begin(); usedIt != usedEnd; ++usedIt)
	{
		bool found = false;

		LetterString::iterator newEnd(newtiles.end());
		for (LetterString::iterator newIt = newtiles.begin(); newIt != newEnd; ++newIt)
		{
			if (*newIt == *usedIt)
			{
				*newIt = QUACKLE_NULL_MARK;
				found = true;
				break;
			}
		}

		if (!found)
			ret = false;
	}

	// UVcout << "newtiles: " << newtiles << endl;

	m_tiles.clear();

	LetterString::const_iterator newEnd(newtiles.end());
	for (LetterString::const_iterator newIt = newtiles.begin(); newIt != newEnd; ++newIt)
		if (*newIt != QUACKLE_NULL_MARK)
			m_tiles += *newIt; 

	return ret;
}

bool Rack::contains(const LetterString &used) const
{
	return Rack(*this).unload(used);
}

void Rack::shuffle()
{
	random_shuffle(m_tiles.begin(), m_tiles.end());
}

int Rack::score() const
{
	int ret = 0;

	const LetterString::const_iterator end(m_tiles.end());
	for (LetterString::const_iterator it = m_tiles.begin(); it != end; ++it)
		ret += QUACKLE_ALPHABET_PARAMETERS->score(*it);

	return ret;
}

const Rack operator-(const Rack &rack, const Move &move)
{
	Rack ret(rack);
    ret.unload(move.usedTiles());
    return ret;
}

const Rack operator-(const Rack &rack1, const Rack &rack2)
{
	Rack ret(rack1);
    ret.unload(rack2.tiles());
    return ret;
}

Rack& Rack::operator-=(const Move& M)
{
    unload(M.usedTiles());
    return *this;
}

UVString Rack::xml() const
{
	return MARK_UV("<rack tiles=\"") + QUACKLE_ALPHABET_PARAMETERS->userVisible(m_tiles) + MARK_UV("\" />");
}

LetterString Rack::alphabetize(LetterString word)
{
	sort(word.begin(), word.end());
	return word;
}

UVOStream &operator<<(UVOStream &o, const Rack &rack)
{
    o << QUACKLE_ALPHABET_PARAMETERS->userVisible(rack.tiles());
    return o;
}


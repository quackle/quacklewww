/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef QUACKLE_LEXICONPARAMETERS_H
#define QUACKLE_LEXICONPARAMETERS_H

#include "alphabetparameters.h"

namespace Quackle
{

class LexiconParameters
{
public:
	LexiconParameters();
	~LexiconParameters();

	void unloadAll();

	// true if we have a dawg or a gaddag
	bool hasSomething() const;

	void loadDawg(const string &filename);
	void unloadDawg();
	bool hasDawg() const;

	void loadGaddag(const string &filename);
	void unloadGaddag();
	bool hasGaddag() const;

	// returns "lexica/" + lexicon
	static string findDictionaryFile(const string &lexicon);

	// a convenience field; this is unused by libquackle
	string lexiconName() const;
	void setLexiconName(const string &name);

	unsigned char dawgAt(int index) const;
	unsigned char gaddagAt(int index) const;
	unsigned int gaddagiAt(int index) const;

protected:
	unsigned char *m_dawg;
	unsigned char *m_gaddag;
	unsigned int *m_gaddagi;
	string m_lexiconName;
};

inline bool LexiconParameters::hasSomething() const
{
	return hasDawg() || hasGaddag();
}

inline bool LexiconParameters::hasDawg() const
{
	return m_dawg;
}

inline bool LexiconParameters::hasGaddag() const
{
	return m_gaddag;
}

inline unsigned char LexiconParameters::dawgAt(int index) const
{
	return m_dawg[index];
}

inline unsigned char LexiconParameters::gaddagAt(int index) const
{
	return m_gaddag[index];
}

inline unsigned int LexiconParameters::gaddagiAt(int index) const
{
	return m_gaddagi[index];
}

inline string LexiconParameters::lexiconName() const
{
	return m_lexiconName;
}

inline void LexiconParameters::setLexiconName(const string &name)
{
	m_lexiconName = name;
}

}
#endif

/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>
#include <string>

#include "boardparameters.h"
#include "datamanager.h"
#include "lexiconparameters.h"
#include "strategyparameters.h"
#include "strongplayer.h"
#include "game.h"
#include "sim.h"

void testAnagrammer();
void testBag(Quackle::Game &game);
void testBasic(Quackle::Game &game);
void testAdvanceToEnd(Quackle::Game &game);
void testEndgame(Quackle::Game &game);
void testSimulation(Quackle::Game &game);
void testValidator(Quackle::Game &game);

int main()
{
	Quackle::DataManager dataManager;

	dataManager.setDataDirectory("data");
	dataManager.lexiconParameters()->loadDawg(Quackle::LexiconParameters::findDictionaryFile("twl06.dawg"));
	dataManager.strategyParameters()->initialize(Quackle::StrategyParameters::findStrategyDirectory("twl06"));
	dataManager.setBoardParameters(new Quackle::RandomBoardILike());

	const bool seedRandoms = true;
	if (seedRandoms)
		dataManager.seedRandomNumbers('E' + 'm' + 'i' + 'l' + 'y' + 'K' + 'o');

	//testAnagrammer();
	
	Quackle::Game game;

	Quackle::PlayerList players;

	Quackle::Player quackle(MARK_UV("Quackle D00D"), Quackle::Player::ComputerPlayer, Quackle::ComputerPlayer::StaticComputer);
	players.push_back(quackle);
	
	players.push_back(Quackle::Player(MARK_UV("Quackle's Friend"), Quackle::Player::ComputerPlayer, Quackle::ComputerPlayer::StaticComputer));

	game.setPlayers(players);
	game.associateKnownComputerPlayers();

	game.addPosition();

	//testValidator(game);

	const bool setupRetroPosition = false;

	if (setupRetroPosition)
	{
		game.commitMove(Quackle::Move::createPlaceMove(MARK_UV("8c"), QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("AMNION"))));
		game.currentPosition().setCurrentPlayerRack(Quackle::Rack(QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("AADFHOY"))));
	}

	const int playahead = 5;

	for (int i = 0; i < playahead; ++i)
	{
		if (game.currentPosition().gameOver())
		{
			UVcout << "GAME OVER" << endl;
			break;
		}

		const Quackle::Player player(game.currentPosition().currentPlayer());
		Quackle::Move compMove(game.haveComputerPlay());
		UVcout << "with " << player.rack() << ", " << player.name() << " commits to " << compMove << endl;
	}

	UVcout << game.currentPosition() << endl;

	// insert test...() calls here
	//testSimulation(game);
	
	//UVcout << "History:" << endl << game.history() << endl;

	return 0;
}

void testBasic(Quackle::Game &game)
{
}

void testAnagrammer()
{
	UVcout << "anagrams of EFIILNT: " << QUACKLE_GENERATOR->anagramLetters(QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("EFIILNT"))) << endl;
	UVcout << "anagrams of AEPRSu: " << QUACKLE_GENERATOR->anagramLetters(QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("AEPRSu"))) << endl;
	UVcout << "anagrams of EFIILNT?: " << QUACKLE_GENERATOR->anagramLetters(QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("EFIILNT?"))) << endl;
	UVcout << "build of EFIILNT: " << QUACKLE_GENERATOR->anagramLetters(QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("EFIILNT")), Quackle::Generator::NoRequireAllLetters) << endl;
	UVcout << "free search of NUTPICK: " << QUACKLE_GENERATOR->anagramLetters(QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("NUTPICK")), Quackle::Generator::AddAnyLetters) << endl;
}

void testAdvanceToEnd(Quackle::Game &game)
{
	UVcout << "now advancing to end..." << endl;

	game.advanceToNoncomputerPlayer();

	UVcout << game.currentPosition();

	Quackle::PlayerList winners(game.currentPosition().leadingPlayers());
	for (Quackle::PlayerList::const_iterator it = winners.begin(); it != winners.end(); ++it)
		UVcout << *it << " wins!!" << endl;
}

void testBag(Quackle::Game &game)
{
	UVcout << "BAG TEST" << endl;
	UVcout << "current player rack: " << game.currentPosition().currentPlayer().rack() << endl;
	game.currentPosition().setCurrentPlayerRack(Quackle::Rack(QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("AAAAAAA"))));
	UVcout << "current player rack set to: " << game.currentPosition().currentPlayer().rack() << endl;
	UVcout << "current bag now " << game.currentPosition().bag() << endl;
	game.commitMove(Quackle::Move::createPlaceMove(MARK_UV("8d"), QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("PEAFOwL"))));
	UVcout << "current bag after PEAFOwL " << game.currentPosition().bag() << endl;
}

void testEndgame(Quackle::Game &game)
{
	// dataManager.setEvaluator(new Quackle::CatchallEvaluator());

	const int playahead = 20;
	for (int i = 0; i < playahead; ++i)
	{
		if (game.currentPosition().gameOver())
			break;
		Quackle::Move compMove(game.haveComputerPlay());
	}
}

void testSimulation(Quackle::Game &game)
{
	const int kibitzLength = 3;
	game.currentPosition().kibitz(kibitzLength);

	UVcout << game.currentPosition() << endl;
	UVcout << game.currentPosition().moves() << endl;

	Quackle::Simulator simulator;
	simulator.setLogfile("quackletest.simulation", false);
	simulator.setPosition(game.currentPosition());

	simulator.simulate(2, 50);
	UVcout << simulator.simmedMoves() << endl;
	UVcout << "after " << simulator.iterations() << " iterations pruning to those within five points" << endl;

	simulator.pruneTo(5, kibitzLength);

	int iterationStep = 1;
	int iterationsToRun = 2;

	const bool longSim = true;
	if (longSim)
	{
		iterationStep = 10;
		iterationsToRun = 50;
	}

	const int plies = 2;

	simulator.setIgnoreOppos(false);

	for (int iterations = 0; iterations < iterationsToRun; iterations += iterationStep)
	{
		simulator.simulate(plies, iterationStep);
		UVcout << "sim results after " << iterations + iterationStep << " iterations: " << endl;

		const Quackle::SimmedMoveList &moves = simulator.simmedMoves();

		for (Quackle::SimmedMoveList::const_iterator it = moves.begin(); it != moves.end(); ++it)
		{
			UVcout << *it << endl;
		}

		UVcout << endl;
	}
}

void testValidator(Quackle::Game &game)
{
	game.commitMove(Quackle::Move::createPlaceMove(MARK_UV("8d"), QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("MANIA"))));
	game.commitMove(Quackle::Move::createPlaceMove(MARK_UV("7c"), QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("RANI"))));
	game.commitMove(Quackle::Move::createPlaceMove(MARK_UV("f6"), QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("P..ION"))));
	game.commitMove(Quackle::Move::createPlaceMove(MARK_UV("10b"), QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("STAT.R"))));
	game.currentPosition().setCurrentPlayerRack(Quackle::Rack(QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("AIAIAIAI"))));

	UVcout << game.currentPosition().board().allWordsFormedBy(Quackle::Move::createPlaceMove(MARK_UV("9c"), QUACKLE_ALPHABET_PARAMETERS->encode(MARK_UV("AI"))));
}


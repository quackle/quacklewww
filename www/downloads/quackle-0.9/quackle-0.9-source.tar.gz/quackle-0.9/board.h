/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef QUACKLE_BOARD_H
#define QUACKLE_BOARD_H

#include <vector>

#include "alphabetparameters.h"
#include "bag.h"
#include "move.h"
#include "rack.h"

using namespace std;
	
#define QUACKLE_MAXIMUM_BOARD_SIZE 25
#define QUACKLE_MINIMUM_BOARD_SIZE 7

namespace Quackle
{

class Board
{
public:
	// create uninitialized board of size specified
	// by global BoardParameters
	Board();

	// create uninitialized width x height board.
	// Width and height must each be between 
	// QUACKLE_MINIMUM_BOARD_SIZE and QUACKLE_MAXIMUM_BOARD_SIZE.
	Board(int width, int height);

	// use this to start out your board for use
	void prepareEmptyBoard();

	int width() const { return m_width; }
	int height() const { return m_height; }

	Bag tilesNotOnBoard() const;

	bool isEmpty() const;

	void makeMove(const Move &move);

	// returns all words formed when play is made
	vector<LetterString> allWordsFormedBy(const Move &move) const;

	// returns whether the board is empty or tiles of move touch
	// at least one other square of the board
	bool isConnected(const Move &move) const;

	// if the board is empty, does this move not hit the center square?
	bool isUnacceptableOpeningMove(const Move &move) const;

	// return score of move suitable for score field of move
	int score(const Move &move) const;

	// Return string suitable for prettyTiles field of move.
	// If markPlayThruTiles is true, wrap tiles played thru in
	// parentheses
	LetterString prettyTilesOfMove(const Move &move, bool markPlayThruTiles = true) const;

	UVString toString() const;

	enum TileType { LetterTile = 0, BonusSquareTile, NothingTile };
	enum BonusSquareType { LetterBonus = 0, WordBonus, NoBonus };

	struct TileInformation
	{
		TileInformation()
			: letter(QUACKLE_NULL_MARK), tileType(NothingTile), isBlank(false), isStartLocation(false), bonusSquareType(NoBonus), bonusMultiplier(0)
		{
		}

		// Letter is always nonblank version! blankness is stored in isBlank.
		// If there is no letter, this is  the null mark.
		Letter letter;

		TileType tileType;
		bool isBlank;

		bool isStartLocation;

		BonusSquareType bonusSquareType;
		int bonusMultiplier;
	};

	TileInformation tileInformation(int row, int col) const;

	Letter letter(int row, int col) const;
	bool isBlank(int row, int col) const;

	int vcross(int row, int col) const;
	void setVCross(int row, int col, int vcross);

	int hcross(int row, int col) const;
	void setHCross(int row, int col, int hcross);

protected:
	int m_width;
	int m_height;
	bool m_empty;

	Letter m_letters[QUACKLE_MAXIMUM_BOARD_SIZE][QUACKLE_MAXIMUM_BOARD_SIZE];
	bool m_isBlank[QUACKLE_MAXIMUM_BOARD_SIZE][QUACKLE_MAXIMUM_BOARD_SIZE];

	int m_vcross[QUACKLE_MAXIMUM_BOARD_SIZE][QUACKLE_MAXIMUM_BOARD_SIZE];
	int m_hcross[QUACKLE_MAXIMUM_BOARD_SIZE][QUACKLE_MAXIMUM_BOARD_SIZE];

	inline bool isNonempty(int row, int column) const;
};

inline bool Board::isEmpty() const
{
	return m_empty;
}

inline Letter Board::letter(int row, int col) const
{
	return m_letters[row][col];
}

inline bool Board::isBlank(int row, int col) const
{
	return m_isBlank[row][col];
}

inline int Board::vcross(int row, int col) const
{
	return m_vcross[row][col];
}

inline void Board::setVCross(int row, int col, int vcross)
{
	m_vcross[row][col] = vcross;
}

inline int Board::hcross(int row, int col) const
{
	return m_hcross[row][col];
}

inline void Board::setHCross(int row, int col, int hcross)
{
	m_hcross[row][col] = hcross;
}

inline bool Board::isNonempty(int row, int column) const
{
	return m_letters[row][column] != QUACKLE_NULL_MARK;
}

}

UVOStream &operator<<(UVOStream &o, const Quackle::Board &board);

#endif

/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>

#include <QtGui>

#include <computerplayer.h>

#include "newgame.h"
#include "util.h"

NewGameDialog::NewGameDialog(QWidget *parent)
	: QDialog(parent)
{
	m_tabs = new QTabWidget;

	m_playerTab = new PlayerTab;
	m_tabs->addTab(m_playerTab, tr("&Players"));

	QPushButton *okButton = new QPushButton(tr("&OK"));
	QPushButton *cancelButton = new QPushButton(tr("&Cancel"));

	connect(okButton, SIGNAL(clicked()), this, SLOT(done()));
	connect(cancelButton, SIGNAL(clicked()), this, SLOT(reject()));

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch(1);
	buttonLayout->addWidget(okButton);
	buttonLayout->addWidget(cancelButton);

	QVBoxLayout *topLayout = new QVBoxLayout;
	topLayout->addWidget(m_tabs);
	topLayout->addLayout(buttonLayout);
	setLayout(topLayout);

	loadSettings();

	setWindowTitle(tr("New Game - Quackle"));
	okButton->setDefault(true);
}

Quackle::PlayerList NewGameDialog::players() const
{
	return m_playerTab->players();
}

void NewGameDialog::done()
{
	saveSettings();
	accept();
}

void NewGameDialog::saveSettings()
{
	//QSettings settings;
	//settings.writeEntry("/letterbox/lister/sowpods", m_sowpodsChecker->isOn());
	
	m_playerTab->saveSettings();
}

void NewGameDialog::loadSettings()
{
	//QSettings settings;
	//m_sowpodsChecker->setChecked(settings.readBoolEntry("/letterbox/lister/sowpods", TopLevel::self()->letterboxSettings().mode == Mode_TWL));
}

/////////////

PlayerTab::PlayerTab(QWidget *parent)
	: QWidget(parent), m_changingEditorManually(false)
{
	m_addPlayerButton = new QPushButton(tr("&Add New Player"));
	m_removePlayerButton = new QPushButton(tr("&Remove Player"));

	connect(m_addPlayerButton, SIGNAL(clicked()), this, SLOT(addPlayer()));
	connect(m_removePlayerButton, SIGNAL(clicked()), this, SLOT(removePlayer()));

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addWidget(m_addPlayerButton);
	buttonLayout->addWidget(m_removePlayerButton);

	m_playersTreeWidget = new QTreeWidget;

	// probably too confusing to be able to select multiple players at oncet?
	// all functionality for it is implemented wrt removing multiple players at oncet
	//m_playersTreeWidget->setSelectionMode(QTreeWidget::ExtendedSelection);
	
	connect(m_playersTreeWidget, SIGNAL(itemSelectionChanged()), this, SLOT(selectionChanged()));
	QStringList headers;
	headers << tr("Name") << tr("Controller");
	m_playersTreeWidget->setHeaderLabels(headers);

	m_editGroup = new QGroupBox(tr("Player &Information"));
	QHBoxLayout *editLayout = new QHBoxLayout(m_editGroup);

	m_nameEdit = new QLineEdit;
	connect(m_nameEdit, SIGNAL(textEdited(const QString &)), this, SLOT(playerEdited()));
	editLayout->addWidget(m_nameEdit);

	m_playerType = new QComboBox;
	QStringList playerTypes;
	playerTypes << tr("Human") << tr("Fast Computer") << tr("Slow Sucky Simming Computer");
	m_playerType->addItems(playerTypes);
	connect(m_playerType, SIGNAL(activated(const QString &)), this, SLOT(playerEdited()));
	editLayout->addWidget(m_playerType);

	QVBoxLayout *topLayout = new QVBoxLayout;
	topLayout->addWidget(m_playersTreeWidget);
	topLayout->addWidget(m_editGroup);
	topLayout->addStretch();
	topLayout->addLayout(buttonLayout);

	setLayout(topLayout);

	QTimer::singleShot(0, this, SLOT(populatePlayers()));
}

void PlayerTab::saveSettings()
{
	QSettings settings;

	QList<QVariant> playerIds;

	QList<Quackle::Player> playerList(m_playerMap.keys());

	for (QList<Quackle::Player>::iterator it = playerList.begin(); it != playerList.end(); ++it)
	{
		playerIds.push_back((*it).id());
		settings.setValue(QString("quackle/newgame/players/%1").arg((*it).id()), Util::uvStringToQString((*it).storeInformationToString()));
	}

	settings.setValue("quackle/newgame/playerIds", playerIds);

	// this is a workaround for one item lists getting saved oddly
	if (playerIds.size() == 1)
		settings.setValue("quackle/newgame/playerId", playerIds.front().toInt());
	else
		settings.setValue("quackle/newgame/playerId", -1);
}

void PlayerTab::populatePlayers()
{
	QSettings settings;

	// this is a workaround for one item lists getting saved oddly
	int playerId = settings.value("quackle/newgame/playerId", -1).toInt();
	
	QList<QVariant> playerIds;
	if (playerId >= 0)
		playerIds.push_back(QVariant(playerId));
	else
		playerIds  = settings.value("quackle/newgame/playerIds", QList<QVariant>()).toList();

	for (QList<QVariant>::iterator it = playerIds.begin(); it != playerIds.end(); ++it)
	{
		int id = (*it).toInt();

		QString infoString = settings.value(QString("quackle/newgame/players/%1").arg(id)).toString();
		if (infoString.isNull())
			continue;
			
		Quackle::Player player(Quackle::Player::makePlayerFromString(Util::qstringToString(infoString)));
		addPlayer(player);
	}

	if (m_playerMap.empty())
	{
		addPlayer(Quackle::Player(Util::qstringToString(tr("Quackle")), Quackle::Player::ComputerPlayer, Quackle::ComputerPlayer::StaticComputer, 0));
		addPlayer();
	}

	selectionChanged();
}

Quackle::PlayerList PlayerTab::players() const
{
	// this is all silly to do but oh well
	QList<Quackle::Player> playerList(m_playerMap.keys());
	Quackle::PlayerList ret;

	for (QList<Quackle::Player>::const_iterator it = playerList.begin(); it != playerList.end(); ++it)
	{
		ret.push_back(*it);

		if (ret.back().name().empty())
			ret.back().setName(Util::qstringToString(tr("No Name")));
	}

	return ret;
}

void PlayerTab::addPlayer(const Quackle::Player &player)
{
	QTreeWidgetItem *item = new QTreeWidgetItem(m_playersTreeWidget);
	m_playerMap.insert(player, item);
	setItem(item, player);

	m_playersTreeWidget->clearSelection();
	m_playersTreeWidget->setItemSelected(item, true);
}

void PlayerTab::setItem(QTreeWidgetItem *item, const Quackle::Player &player)
{
	item->setText(PlayerName, Util::uvStringToQString(player.name()));
	item->setText(PlayerType, stringForTypes(player.type(), player.computerType()));
}

void PlayerTab::addPlayer()
{
	QString name(tr("New Player %1"));
	QString unusedName;
	int unusedId;

	for (int i = 1; ; ++i)
	{
		unusedName = name.arg(i);
		UVString nameString = Util::qstringToString(unusedName);

		bool found = false;
		for (QMap<Quackle::Player, QTreeWidgetItem *>::iterator it = m_playerMap.begin(); it != m_playerMap.end(); ++it)
		{
			if (it.key().name() == nameString)
			{
				found = true;
				break;
			}
		}

		if (!found)
			break;
	}

	for (unusedId = 0; ; ++unusedId)
	{
		bool found = false;
		for (QMap<Quackle::Player, QTreeWidgetItem *>::iterator it = m_playerMap.begin(); it != m_playerMap.end(); ++it)
		{
			if (it.key().id() == unusedId)
			{
				found = true;
				break;
			}
		}

		if (!found)
			break;
	}

	Quackle::Player player(Util::qstringToString(unusedName), Quackle::Player::HumanPlayer, Quackle::ComputerPlayer::StaticComputer, unusedId);
	addPlayer(player);
}

void PlayerTab::removePlayer()
{
	QList<QTreeWidgetItem *> items = m_playersTreeWidget->selectedItems();
	for (QList<QTreeWidgetItem *>::iterator it = items.begin(); it != items.end(); ++it)
	{
		delete *it;

		QList<Quackle::Player> correspondingPlayers(m_playerMap.keys(*it));

		if (correspondingPlayers.size() > 0)
			m_playerMap.remove(correspondingPlayers.front());
	}

	selectionChanged();
}

void PlayerTab::playerEdited()
{
	if (m_changingEditorManually || !hasSelection())
		return;

	Quackle::Player lastPlayer(getLastPlayer());
	if (lastPlayer.id() < 0)
		return;

	lastPlayer.setName(Util::qstringToString(m_nameEdit->text()));

	int playerType;
	int computerType;

	typesForString(m_playerType->currentText(), playerType, computerType);
	lastPlayer.setType(playerType);
	lastPlayer.setComputerType(computerType);

	// please excuse the HORRIBLE use of QMap here
	QTreeWidgetItem *item = m_playerMap.value(lastPlayer);
	m_playerMap.remove(lastPlayer);
	m_playerMap.insert(lastPlayer, item);

	setItem(item, lastPlayer);
}

void PlayerTab::selectionChanged()
{
	bool hasSel = hasSelection();
	m_removePlayerButton->setEnabled(hasSel);
	m_editGroup->setEnabled(hasSel);

	if (!hasSel)
		return;

	Quackle::Player lastPlayer(getLastPlayer());

	if (lastPlayer.id() < 0)
	{
		UVcout << "last player id < 0" << endl;
		return;
	}

	m_changingEditorManually = true;

	m_nameEdit->setText(Util::uvStringToQString(lastPlayer.name()));
	m_playerType->setCurrentIndex(m_playerType->findText(stringForTypes(lastPlayer.type(), lastPlayer.computerType())));

	m_changingEditorManually = false;
}

bool PlayerTab::hasSelection()
{
	return !m_playersTreeWidget->selectedItems().empty();
}

Quackle::Player PlayerTab::getLastPlayer()
{
	QTreeWidgetItem *lastItem = m_playersTreeWidget->selectedItems().back();
	Quackle::Player lastPlayer;
	for (QMap<Quackle::Player, QTreeWidgetItem *>::iterator it = m_playerMap.begin(); it != m_playerMap.end(); ++it)
		if (it.value() == lastItem)
			return it.key();

	// urp!
	return Quackle::Player();
}

QString PlayerTab::stringForTypes(int playerType, int computerType)
{
	switch (playerType)
	{
	case Quackle::Player::HumanPlayer:
		return tr("Human");

	case Quackle::Player::ComputerPlayer:
		switch (computerType)
		{
		case Quackle::ComputerPlayer::StrongComputer:
			return tr("Slow Sucky Simming Computer");
		case Quackle::ComputerPlayer::StaticComputer:
			return tr("Fast Computer");
		}
	
	default:
		return tr("Other");
	}
}

void PlayerTab::typesForString(const QString &typeString, int &playerType, int &computerType)
{
	if (typeString == tr("Human"))
	{
		playerType = Quackle::Player::HumanPlayer;
		computerType = Quackle::ComputerPlayer::StaticComputer;
	}
	else if (typeString == tr("Slow Sucky Simming Computer"))
	{
		playerType = Quackle::Player::ComputerPlayer;
		computerType = Quackle::ComputerPlayer::StrongComputer;
	}
	else if (typeString == tr("Fast Computer"))
	{
		playerType = Quackle::Player::ComputerPlayer;
		computerType = Quackle::ComputerPlayer::StaticComputer;
	}
}


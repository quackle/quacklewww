/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>

#include "sim.h"
#include "game.h"
#include "move.h"

//#define DEBUG_SIM

using namespace Quackle;

Simulator::Simulator()
	: m_logfileIsOpen(false), m_hasHeader(false), m_iterations(0), m_ignoreOppos(false)
{
	m_originalGame.addPosition();
}

Simulator::~Simulator()
{
	closeLogfile();
}

void Simulator::setPosition(const GamePosition &position)
{
	if (hasSimulationResults())
		writeLogFooter();

	m_originalGame.setCurrentPosition(position);
	m_originalGame.setPlayers(position.players());

	m_simmedMoves.clear();
	MoveList::const_iterator end = m_originalGame.currentPosition().moves().end();
	for (MoveList::const_iterator it = m_originalGame.currentPosition().moves().begin(); it != end; ++it)
		m_simmedMoves.push_back(SimmedMove(*it));

	resetNumbers();
}

void Simulator::setLogfile(const string &logfile, bool append)
{
	if (m_logfile == logfile && isLogging())
		return;

	closeLogfile();
	m_logfile = logfile;

	if (m_logfile.empty())
	{
		closeLogfile();
		return;
	}

	const ios::openmode flags = append? (ios::out | ios::app) : ios::out;
	m_logfileStream.open(m_logfile.c_str(), flags);

	m_logfileIsOpen = m_logfileStream.is_open();
	if (!m_logfileIsOpen)
		cerr << "Could not open " << m_logfile << " to write simulation log" << endl;

	m_hasHeader = false;
}

void Simulator::logMessage(const UVString &message)
{
	if (isLogging())
		m_logfileStream << message << endl;
}

void Simulator::closeLogfile()
{
	if (isLogging())
	{
		if (m_hasHeader)
			writeLogFooter();

		m_logfileStream.close();
		m_logfileIsOpen = false;
	}
}

void Simulator::writeLogHeader()
{
	if (isLogging())
	{
		m_logfileStream << "<simulation>" << endl;
		m_xmlIndent = MARK_UV("\t");

		m_hasHeader = true;

		// TODO include position data
	}
}

void Simulator::writeLogFooter()
{
	if (isLogging())
	{
		m_xmlIndent = MARK_UV("");
		m_logfileStream << "</simulation>" << endl;

		m_hasHeader = false;
	}
}

void Simulator::setIncludedMoves(const MoveList &moves)
{
	for (SimmedMoveList::iterator simmedMoveIt = m_simmedMoves.begin(); simmedMoveIt != m_simmedMoves.end(); ++simmedMoveIt)
		(*simmedMoveIt).setIncludeInSimulation(false);

	MoveList::const_iterator end = moves.end();
	for (MoveList::const_iterator it = moves.begin(); it != end; ++it)
	{
		SimmedMoveList::iterator simmedMoveIt;
		for (simmedMoveIt = m_simmedMoves.begin(); simmedMoveIt != m_simmedMoves.end(); ++simmedMoveIt)
		{
			if ((*it) == (*simmedMoveIt).move)
			{
#ifdef DEBUG_SIM
				UVcout << "including " << (*simmedMoveIt).move << endl;
#endif

				(*simmedMoveIt).setIncludeInSimulation(true);
				break;
			}
		}

		// move wasn't found; add it
		if (simmedMoveIt == m_simmedMoves.end())
			m_simmedMoves.push_back(SimmedMove(*it));
	}
}

void Simulator::pruneTo(double equityThreshold, int maxNumberOfMoves)
{
	MoveList equityMoves(moves(/* prune unincluded */ true));
	MoveList toSetIncluded;
	const double absoluteEquityThreshold = equityMoves[0].equity - equityThreshold;

	const MoveList::const_iterator end = equityMoves.end();
	int i = 0;
	for (MoveList::const_iterator it = equityMoves.begin(); i < maxNumberOfMoves && it != end; ++it, ++i)
		if ((*it).equity >= absoluteEquityThreshold)
			toSetIncluded.push_back(*it);

	setIncludedMoves(toSetIncluded);
}

void Simulator::resetNumbers()
{
	SimmedMoveList::iterator end = m_simmedMoves.end();
	for (SimmedMoveList::iterator moveIt = m_simmedMoves.begin(); moveIt != end; ++moveIt)
		(*moveIt).clear();

	m_iterations = 0;
}

void Simulator::simulate(int plies, int iterations)
{
	for (int i = 0; i < iterations; ++i)
		simulate(plies);
}

void Simulator::simulate(int plies)
{
#ifdef DEBUG_SIM
	UVcout << "let's simulate for " << plies << " plies" << endl;
#endif

	++m_iterations;

	randomizeOppoRacks();
	randomizeDrawingOrder();

	const int startPlayerId = m_originalGame.currentPosition().currentPlayer().id();
	const int numberOfPlayers = m_originalGame.players().size();

	if (plies < 0)
		plies = 1000;

	// specified plies doesn't include candidate play
	++plies;
	
	// level one's first move is the zeroth ply (the candidate)
	const int decimalTurns = (plies % numberOfPlayers);

	// also one-indexed
	const int levels = (int)((plies - decimalTurns) / numberOfPlayers);

#ifdef DEBUG_SIM
	UVcout << "levels: " << levels << endl;
	UVcout << "decimalTurns: " << decimalTurns << endl;
#endif

	if (isLogging())
	{
		if (!m_hasHeader)
			writeLogHeader();

		m_logfileStream << m_xmlIndent << "<iteration index=\"" << m_iterations << "\">" << endl;
		m_xmlIndent += MARK_UV('\t');
	}

	SimmedMoveList::iterator moveEnd = m_simmedMoves.end();
	for (SimmedMoveList::iterator moveIt = m_simmedMoves.begin(); moveIt != moveEnd; ++moveIt)
	{
		if (!(*moveIt).includeInSimulation())
			continue;

#ifdef DEBUG_SIM
		UVcout << "simulating " << (*moveIt).move << ":" << endl;
#endif

		if (isLogging())
		{
			m_logfileStream << m_xmlIndent << "<playahead>" << endl;
			m_xmlIndent += MARK_UV('\t');
		}

		m_simulatedGame = m_originalGame;
		double residual = 0;

		(*moveIt).setNumberLevels(levels + 1);

		int levelNumber = 1;
		for (LevelList::iterator levelIt = (*moveIt).levels.begin(); levelNumber <= levels + 1 && levelIt != (*moveIt).levels.end() && !m_simulatedGame.currentPosition().gameOver(); ++levelIt, ++levelNumber)
		{
#ifdef DEBUG_SIM
			UVcout << "levelNumber: " << levelNumber << endl;
#endif

			const int decimal = levelNumber == levels + 1? decimalTurns : numberOfPlayers;
			if (decimal == 0)
				continue;

			(*levelIt).setNumberScores(decimal);

			/*
			if (isLogging())
			{
				m_logfileStream << m_xmlIndent << "<depth>" << endl;
				m_xmlIndent += MARK_UV('\t');
			}
			*/

			int playerNumber = 1;
			for (AveragedValueList::iterator scoresIt = (*levelIt).scores.begin(); scoresIt != (*levelIt).scores.end() && !m_simulatedGame.currentPosition().gameOver(); ++scoresIt, ++playerNumber)
			{
				const int playerId = m_simulatedGame.currentPosition().currentPlayer().id();

				if (isLogging())
				{
					m_logfileStream << m_xmlIndent << "<ply index=\"" << (levelNumber - 1) * numberOfPlayers + playerNumber - 1 << "\">" << endl;
					m_xmlIndent += MARK_UV('\t');
				}

				Move move = Move::createNonmove();

				if (playerId == startPlayerId && levelNumber == 1)
					move = (*moveIt).move;
				else if (m_ignoreOppos && playerId != startPlayerId)
					move = Move::createPassMove();
				else
					move = m_simulatedGame.currentPosition().staticBestMove();

#ifdef DEBUG_SIM
				UVcout << "incorporating move: " << move << endl;
#endif
				(*scoresIt).incorporateValue(move.score);

				if (isLogging())
				{
					m_logfileStream << m_xmlIndent << m_simulatedGame.currentPosition().currentPlayer().rack().xml() << endl;
					m_logfileStream << m_xmlIndent << move.xml() << endl;
				}

				// record future-looking residuals
				bool isFinalTurnForPlayerOfSimulation = false;

				if (levelNumber == levels)
					isFinalTurnForPlayerOfSimulation = playerNumber > decimalTurns;
				else if (levelNumber == levels + 1)
					isFinalTurnForPlayerOfSimulation = playerNumber <= decimalTurns;

				const bool isVeryFinalTurnOfSimulation = (decimalTurns == 0 && levelNumber == levels && playerNumber == numberOfPlayers) || (levelNumber == levels + 1 && playerNumber == decimalTurns);

				if (isFinalTurnForPlayerOfSimulation && !(m_ignoreOppos && playerId != startPlayerId))
				{
					double residualAddand = m_simulatedGame.currentPosition().calculatePlayerConsideration(move);

					if (isLogging() && residualAddand != 0)
						m_logfileStream << m_xmlIndent << "<pc value=\"" << residualAddand << "\" />" << endl;

					if (isVeryFinalTurnOfSimulation)
					{
						// experimental -- do shared resource considerations
						// matter in a plied simulation?
	
						const double sharedResidual = m_simulatedGame.currentPosition().calculateSharedConsideration(move);
						residualAddand += sharedResidual;

						if (isLogging() && sharedResidual != 0)
							m_logfileStream << m_xmlIndent << "<sc value=\"" << sharedResidual << "\" />" << endl;
					}

#ifdef DEBUG_SIM
					UVcout << "residualAddand is " << residualAddand;
#endif

					if (playerId == startPlayerId)
						residual += residualAddand;
					else
						residual -= residualAddand;
				}

				m_simulatedGame.setCandidate(move);
				m_simulatedGame.commitCandidate(!isVeryFinalTurnOfSimulation);

				if (isLogging())
				{
					m_xmlIndent = m_xmlIndent.substr(0, m_xmlIndent.length() - 1);
					m_logfileStream << m_xmlIndent << "</ply>" << endl;
				}
			}

			/*
			if (isLogging())
			{
				m_xmlIndent = m_xmlIndent.substr(0, m_xmlIndent.length() - 1);
				m_logfileStream << m_xmlIndent << "</depth>" << endl;
			}
			*/
		}

		(*moveIt).residual.incorporateValue(residual);

		const int spread = m_simulatedGame.currentPosition().spread(startPlayerId);
		(*moveIt).gameSpread.incorporateValue(spread);
		(*moveIt).wins.incorporateValue(spread > 0? 1 : spread == 0? 0.5 : 0);

		if (isLogging())
		{
			m_xmlIndent = m_xmlIndent.substr(0, m_xmlIndent.length() - 1);
			m_logfileStream << m_xmlIndent << "</playahead>" << endl;
		}
	}

	if (isLogging())
	{
		m_xmlIndent = m_xmlIndent.substr(0, m_xmlIndent.length() - 1);
		m_logfileStream << m_xmlIndent << "</iteration>" << endl;
	}
}

// TODO randomizeOppoRacks is buggy in endgame
void Simulator::randomizeOppoRacks()
{
	Bag bag(m_originalGame.currentPosition().unseenBag());

	const PlayerList::const_iterator end = m_originalGame.players().end();
	for (PlayerList::const_iterator it = m_originalGame.players().begin(); it != end; ++it)
	{
		if (!((*it) == m_originalGame.currentPosition().currentPlayer()))
		{
			// TODO -- some kind of inference engine can be inserted here
			Rack rack;
			bag.refill(rack);

			m_originalGame.currentPosition().setPlayerRack((*it).id(), rack);
		}
	}
}

void Simulator::randomizeDrawingOrder()
{
	m_originalGame.currentPosition().setDrawingOrder(m_originalGame.currentPosition().bag().shuffledTiles());
}

MoveList Simulator::moves(bool prune) const
{
	MoveList ret;

	const bool useCalculatedEquity = hasSimulationResults();

	const SimmedMoveList::const_iterator end = m_simmedMoves.end();
	for (SimmedMoveList::const_iterator it = m_simmedMoves.begin(); it != end; ++it)
	{
		if (prune && !(*it).includeInSimulation())
			continue;

		Move move((*it).move);

		if (useCalculatedEquity)
			move.equity = (*it).calculateEquity();

		ret.push_back(move);
	}

	MoveList::sort(ret, MoveList::Equity);

	return ret;
}

const SimmedMove &Simulator::simmedMoveForMove(const Move &move) const
{
	const SimmedMoveList::const_iterator end = m_simmedMoves.end();
	for (SimmedMoveList::const_iterator it = m_simmedMoves.begin(); it != end; ++it)
		if ((*it).move == move)
			return *it;
	
	return m_simmedMoves.back();
}

////////////

double AveragedValue::standardDeviation() const
{
	return m_incorporatedValues <= 1 ? 0 :
	sqrt(
	(m_incorporatedValues * m_squaredValueSum - m_valueSum * m_valueSum)
	/ (m_incorporatedValues * (m_incorporatedValues - 1))
	);
}

void AveragedValue::clear()
{
	m_valueSum = 0;
	m_squaredValueSum = 0;
	m_incorporatedValues = 0;
}

////////////

double SimmedMove::calculateEquity() const
{
	double equity = 0;

	for (LevelList::const_iterator levelIt = levels.begin(); levelIt != levels.end(); ++levelIt)
	{
		for (AveragedValueList::const_iterator scoresIt = (*levelIt).scores.begin(); scoresIt != (*levelIt).scores.end(); ++scoresIt)
		{
			if (scoresIt == (*levelIt).scores.begin())
				equity += (*scoresIt).averagedValue();
			else
				equity -= (*scoresIt).averagedValue();
		}
	}

	equity += residual.averagedValue();

	return equity;
}

void SimmedMove::setNumberLevels(int number)
{
	while (levels.size() < number)
		levels.push_back(Level());
}

void SimmedMove::clear()
{
	levels.clear();
}

////////////

void Level::setNumberScores(int number)
{
	while (scores.size() < number)
		scores.push_back(AveragedValue());
}

//////////

UVOStream& operator<<(UVOStream &o, const Quackle::AveragedValue &value)
{
	o << "[" << value.valueSum() << "/" << value.incorporatedValues() << "=" << value.averagedValue() << " sd " << value.standardDeviation() << "]";
    return o;
}

UVOStream& operator<<(UVOStream &o, const Quackle::Level &level)
{
	for (Quackle::AveragedValueList::const_iterator it = level.scores.begin(); it != level.scores.end(); ++it)
		o << *it;
    return o;
}

UVOStream& operator<<(UVOStream &o, const Quackle::SimmedMove &move)
{
	o << "Simmed move " << move.move << ":";

	int levelNumber = 1;
	for (Quackle::LevelList::const_iterator it = move.levels.begin(); it != move.levels.end(); ++it, ++levelNumber)
		o << endl << "level " << levelNumber << ": " << (*it);
	
	o << endl;
	o << "Being simmed: " << move.includeInSimulation() << endl;
	o << "Residual: " << move.residual << endl;
	o << "Spread: " << move.gameSpread << endl;
	o << "Wins: " << move.wins << endl;
    return o;
}

UVOStream& operator<<(UVOStream& o, const Quackle::SimmedMoveList& moves)
{
	const Quackle::SimmedMoveList::const_iterator end(moves.end());
	for (Quackle::SimmedMoveList::const_iterator it = moves.begin(); it != end; ++it)
		o << (*it) << endl;
    return o;
}


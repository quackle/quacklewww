/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef QUACKLE_STRATEGYPARAMETERS_H
#define QUACKLE_STRATEGYPARAMETERS_H

#include "alphabetparameters.h"

namespace Quackle
{

class StrategyParameters
{
public:
	StrategyParameters();

	// directory should contain syn2 and worths
	void initialize(const string &directory);
	bool isInitialized() const;

	// returns "strategy/" + directory
	static string findStrategyDirectory(const string &directory);

	// letters are raw letters include bottom marks
	double syn2(Letter letter1, Letter letter2) const;
	double tileWorth(Letter letter) const;

protected:
	bool loadSyn2(const string &filename);
	bool loadWorths(const string &filename);

	int mapLetter(Letter letter) const;

	double m_syn2[QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE][QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE];
	double m_tileWorths[QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE];

	bool m_initialized;
};

inline bool StrategyParameters::isInitialized() const
{
	return m_initialized;
}

inline int StrategyParameters::mapLetter(Letter letter) const
{
	// no mapping needed
	return letter;
}

inline double StrategyParameters::syn2(Letter letter1, Letter letter2) const
{
	return m_syn2[mapLetter(letter1)][mapLetter(letter2)];
}

inline double StrategyParameters::tileWorth(Letter letter) const
{
	return m_tileWorths[mapLetter(letter)];
}

}
#endif

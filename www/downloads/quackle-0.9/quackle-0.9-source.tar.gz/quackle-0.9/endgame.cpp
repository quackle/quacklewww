#include <iostream>
#include <string>

#include "board.h"
#include "bag.h"
#include "util.h"
#include "generator.h"

Generator G;

Move method1(Board B, Rack R0, Rack R1)
{
	G.setBoard(B);
	G.allcrosses();
	G.setRack(R0);
	G.setExch(false);
	G.kibitz();
	
	return G.bestMove();
}

Move method2(Board B, Rack R0, Rack R1)
{
	G.setBoard(B);
	G.allcrosses();
	G.setRack(R0);
	G.setExch(false);
	G.kibitz();

	MoveList moves = G.allPossiblePlays();

	int bestScore = -1000;
	Move best;
	
	for (int i = 0; i < moves.size(); i++)
	{
		if (moves[i].score > bestScore)
		{
			best = moves[i];
			bestScore = best.score;
		}
	}

	return best;
}


Move method2b(Board B, Rack R0, Rack R1)
{
	G.setBoard(B);
	G.allcrosses();
	G.setRack(R0);
	G.setExch(false);
	G.kibitz();

	MoveList moves = G.allPossiblePlays();

	double bestEstimate = -1000;
	Move best;
	
	for (int i = 0; i < moves.size(); i++)
	{
		double estimate = moves[i].score;

		Rack R2 = R0;

		R2 -= moves[i];

		if (R2.tiles.size() == 0)
			estimate += R1.score() * 2;

		if (estimate > bestEstimate)
		{
			best = moves[i];
			bestEstimate = estimate;
		}
	}

	return best;
}


Move method2c(Board B, Rack R0, Rack R1)
{
	G.setBoard(B);
	G.allcrosses();
	G.setRack(R0);
	G.setExch(false);
	G.kibitz();

	MoveList moves = G.allPossiblePlays();

	double bestEstimate = -1000;
	Move best;
	
	for (int i = 0; i < moves.size(); i++)
	{
		double estimate = moves[i].score;

		Rack R2 = R0;

		R2 -= moves[i];

		if (R2.tiles.size() == 0)
			estimate += R1.score() * 2;
		else 
		{
			estimate -= 8.0 + 2.61 * R2.score();
		}

		if (estimate > bestEstimate)
		{
			best = moves[i];
			bestEstimate = estimate;
		}
	}

	return best;
}


int nullmove(Board B, Rack R0, Rack R1, int first)
{
	int net = 0;
	
	int i = first;
	
	int scoreless = 0;

	while ((R0.tiles.size() > 0) && (R1.tiles.size() > 0) && (scoreless < 2))
	{
		Move M;
		if ((i % 2) == 0)
		{
			M = method2c(B, R0, R1);
			B.makemove(M);
			// cout << "    Player 1: " << M << " (" << M.score << ")" << endl;
			net += M.score;
			R0 -= M;
		}
		else
		{
			M = method2c(B, R1, R0);
			B.makemove(M);
			// cout << "    Player 2: " << M << " (-" << M.score << ")" << endl;
			net -= M.score;
			R1 -= M;
		}
			
		if (M.action == Move::Place)
			scoreless = 0;
		else
			scoreless++;
	
		i++;
	}

	if ((R0.tiles.size() > 0) && (R1.tiles.size() > 0))
	{
		net -= R0.score();
		net += R1.score();
		// cout << "    " << R1 << " (" << R1.score() << ")" << endl;
		// cout << "    " << R0 << " (-" << R0.score() << ")" << endl;
	}
	else if (R0.tiles.size() > 0)
	{
		net -= R0.score() * 2;
		// cout << "    " << R0 << " (-" << R0.score() * 2 << ")" << endl;
	}
	else if (R1.tiles.size() > 0)
	{
		net += R1.score() * 2;
		// cout << "    " << R1 << " (" << R1.score() * 2 << ")" << endl;
	}

	return net;
}


Move method3(Board B, Rack R0, Rack R1, int numMoves)
{
	G.setBoard(B);
	G.allcrosses();
	G.setRack(R0);
	G.setExch(false);
	G.setKibitzLength(numMoves);
	G.kibitz();

	MoveList moves = G.kibitzList();
	// cout << "kibitzList has " << moves.size() << " moves in it." << endl;	

	int bestSpread = -1000;
	Move best;
	
	for (int i = 0; i < moves.size(); i++)
	{
		int spread = moves[i].score;
		Board B2 = B;
		B2.makemove(moves[i]);
		Rack R2 = R0;
		R2 -= moves[i];

		// cout << "    " << moves[i] << " (" << moves[i].score << ")";	
		spread -= nullmove(B2, R1, R2, 0); 
		// cout << "    [" <<  spread << "]" << endl;

		if (spread > bestSpread)
		{
			best = moves[i];
			bestSpread = spread;
		}
	}

	return best;
}


Move method3s(Board B, Rack R0, Rack R1, int numMoves)
{
	G.setBoard(B);
	G.allcrosses();
	G.setRack(R0);
	G.setExch(false);
	G.setKibitzLength(0);
	G.kibitz();

	MoveList allmoves = G.allPossiblePlays();
	MoveList moves;

    if (allmoves.size() < numMoves)
        numMoves = allmoves.size();

    for (int i = 0; i < allmoves.size(); i++) {
        int insertpos = 0;
        bool insert = false;
        for (int j = numMoves - 1; j >= 0; j--) {
           if (j < moves.size()) {
               if (allmoves[i].score > moves[j].score) {
                   insertpos = j;
                   insert = true;
               }
           }
        }



		if (insert) {
            // cout << "want to insert " << m_moveList[i] << " before " << movelist[insertpos] << endl;
            MoveList::iterator it = moves.begin();
            for (int j = 0; j < insertpos; j++) {
                it++;
            }
            moves.insert(it, 1, allmoves[i]);
        }
        else {
            moves.push_back(allmoves[i]);
        }
    }

    MoveList topmoves;
    topmoves.clear();
    for (int i = 0; i < numMoves; i++)
        if (i < moves.size())
            topmoves.push_back(moves[i]);

	int bestSpread = -1000;
	Move best;
	
	for (int i = 0; i < topmoves.size(); i++)
	{
		int spread = topmoves[i].score;
		Board B2 = B;
		B2.makemove(topmoves[i]);
		Rack R2 = R0;
		R2 -= moves[i];

		// cout << "    " << moves[i] << " (" << moves[i].score << ")";	
		spread -= nullmove(B2, R1, R2, 0); 
		// cout << "    [" <<  spread << "]" << endl;

		if (spread > bestSpread)
		{
			best = topmoves[i];
			bestSpread = spread;
		}
	}

	return best;
}


Move method3b(Board B, Rack R0, Rack R1, int numMoves)
{
	G.setBoard(B);
	G.allcrosses();
	G.setRack(R0);
	G.setExch(false);
	G.setKibitzLength(0);
	G.kibitz();

	MoveList allmoves = G.allPossiblePlays();
	MoveList moves;

	for (int i = 0; i < allmoves.size(); i++)
	{
		int estimate = allmoves[i].score;

		Rack R2 = R0;
		R2 -= allmoves[i];
		if (R2.tiles.size() == 0)
		{
			estimate += R1.score() * 2;
			allmoves[i].outplay = true;
		}
		else allmoves[i].outplay = false;
	
		allmoves[i].endgameEquity = estimate;
	}
		
    if (allmoves.size() < numMoves)
        numMoves = allmoves.size();

    for (int i = 0; i < allmoves.size(); i++) {
        int insertpos = 0;
        bool insert = false;
        for (int j = numMoves - 1; j >= 0; j--) {
           if (j < moves.size()) {
               if (allmoves[i].endgameEquity > moves[j].endgameEquity) {
                   insertpos = j;
                   insert = true;
               }
           }
        }

		if (insert) {
            // cout << "want to insert " << m_moveList[i] << " before " << movelist[insertpos] << endl;
            MoveList::iterator it = moves.begin();
            for (int j = 0; j < insertpos; j++) {
                it++;
            }
            moves.insert(it, 1, allmoves[i]);
        }
        else {
            moves.push_back(allmoves[i]);
        }
    }

    MoveList topmoves;
    topmoves.clear();
    for (int i = 0; i < numMoves; i++)
        if (i < moves.size())
            topmoves.push_back(moves[i]);

	int bestSpread = -1000;
	Move best;
	
	for (int i = 0; i < topmoves.size(); i++)
	{
		int spread = topmoves[i].score;
		Board B2 = B;
		B2.makemove(topmoves[i]);
		Rack R2 = R0;
		R2 -= moves[i];

		// cout << "    " << moves[i] << " (" << moves[i].score << ")";	
		spread -= nullmove(B2, R1, R2, 0); 
		// cout << "    [" <<  spread << "]" << endl;
		
		if (spread > bestSpread)
		{
			best = topmoves[i];
			bestSpread = spread;
		}
	}

	return best;
}


Move method3c(Board B, Rack R0, Rack R1, int numMoves)
{
	G.setBoard(B);
	G.allcrosses();
	G.setRack(R0);
	G.setExch(false);
	G.setKibitzLength(0);
	G.kibitz();

	MoveList allmoves = G.allPossiblePlays();
	MoveList moves;

	for (int i = 0; i < allmoves.size(); i++)
	{
		double estimate = allmoves[i].score;

		Rack R2 = R0;
		R2 -= allmoves[i];
		if (R2.tiles.size() == 0)
		{
			estimate += R1.score() * 2;
			allmoves[i].outplay = true;
		}
		else 
		{
			estimate -= 8.0 + 2.61 * R2.score();
			allmoves[i].outplay = false;
		}

		allmoves[i].endgameEquity = estimate;
	}
		
    if (allmoves.size() < numMoves)
        numMoves = allmoves.size();

    for (int i = 0; i < allmoves.size(); i++) {
        int insertpos = 0;
        bool insert = false;
        for (int j = numMoves - 1; j >= 0; j--) {
           if (j < moves.size()) {
               if (allmoves[i].endgameEquity > moves[j].endgameEquity) {
                   insertpos = j;
                   insert = true;
               }
           }
        }

		if (insert) {
            // cout << "want to insert " << m_moveList[i] << " before " << movelist[insertpos] << endl;
            MoveList::iterator it = moves.begin();
            for (int j = 0; j < insertpos; j++) {
                it++;
            }
            moves.insert(it, 1, allmoves[i]);
        }
        else {
            moves.push_back(allmoves[i]);
        }
    }

    MoveList topmoves;
    topmoves.clear();
    for (int i = 0; i < numMoves; i++)
        if (i < moves.size())
            topmoves.push_back(moves[i]);

	int bestSpread = -1000;
	Move best;
	
	for (int i = 0; i < topmoves.size(); i++)
	{
		int spread = topmoves[i].score;
		Board B2 = B;
		B2.makemove(topmoves[i]);
		Rack R2 = R0;
		R2 -= moves[i];

		// cout << "    " << moves[i] << " (" << moves[i].score << ")";	
		spread -= nullmove(B2, R1, R2, 0); 
		// cout << "    [" <<  spread << "]" << endl;
		
		if (spread > bestSpread)
		{
			best = topmoves[i];
			bestSpread = spread;
		}
	}

	return best;
}


int nullmove2(Board B, Rack R0, Rack R1, int first, int numMoves)
{
	int net = 0;
	
	int i = first;
	
	int scoreless = 0;

	while ((R0.tiles.size() > 0) && (R1.tiles.size() > 0) && (scoreless < 2))
	{
		Move M;
		if ((i % 2) == 0)
		{
			if (i == 0)
				M = method3(B, R0, R1, numMoves);
			else
				M = method2(B, R0, R1);

			B.makemove(M);
			// cout << "    Player 1: " << M << " (" << M.score << ")" << endl;
			net += M.score;
			R0 -= M;
		}
		else
		{
			M = method2(B, R1, R0);
			B.makemove(M);
			// cout << "    Player 2: " << M << " (-" << M.score << ")" << endl;
			net -= M.score;
			R1 -= M;
		}
			
		if (M.action == Move::Place)
			scoreless = 0;
		else
			scoreless++;
	
		i++;
	}

	if ((R0.tiles.size() > 0) && (R1.tiles.size() > 0))
	{
		net -= R0.score();
		net += R1.score();
		// cout << "    " << R1 << " (" << R1.score() << ")" << endl;
		// cout << "    " << R0 << " (-" << R0.score() << ")" << endl;
	}
	else if (R0.tiles.size() > 0)
	{
		net -= R0.score() * 2;
		// cout << "    " << R0 << " (-" << R0.score() * 2 << ")" << endl;
	}
	else if (R1.tiles.size() > 0)
	{
		net += R1.score() * 2;
		// cout << "    " << R1 << " (" << R1.score() * 2 << ")" << endl;
	}

	return net;
}


Move method4(Board B, Rack R0, Rack R1, int numMoves, int nextMoves)
{
	G.setBoard(B);
	G.allcrosses();
	G.setRack(R0);
	G.setExch(false);
	G.setKibitzLength(numMoves);
	G.kibitz();

	MoveList moves = G.kibitzList();
	// cout << "kibitzList has " << moves.size() << " moves in it." << endl;	

	int bestSpread = -1000;
	Move best;
	
	for (int i = 0; i < moves.size(); i++)
	{
		int spread = moves[i].score;
		Board B2 = B;
		B2.makemove(moves[i]);
		Rack R2 = R0;
		R2 -= moves[i];

		// cout << "    " << moves[i] << " (" << moves[i].score << ")";	
		spread -= nullmove2(B2, R1, R2, 0, nextMoves); 
		// cout << "    [" <<  spread << "]" << endl;

		if (spread > bestSpread)
		{
			best = moves[i];
			bestSpread = spread;
		}
	}

	return best;
}


int nullmove3(Board B, Rack R0, Rack R1, int first, int numMoves)
{
	int net = 0;
	
	int i = first;
	
	int scoreless = 0;

	while ((R0.tiles.size() > 0) && (R1.tiles.size() > 0) && (scoreless < 2))
	{
		Move M;
		if ((i % 2) == 0)
		{
			M = method3c(B, R0, R1, numMoves);

			B.makemove(M);
			// cout << "    Player 1: " << M << " (" << M.score << ")" << endl;
			net += M.score;
			R0 -= M;
		}
		else
		{
			M = method3c(B, R1, R0, numMoves);
			B.makemove(M);
			// cout << "    Player 2: " << M << " (-" << M.score << ")" << endl;
			net -= M.score;
			R1 -= M;
		}
			
		if (M.action == Move::Place)
			scoreless = 0;
		else
			scoreless++;
	
		i++;
	}

	if ((R0.tiles.size() > 0) && (R1.tiles.size() > 0))
	{
		net -= R0.score();
		net += R1.score();
		// cout << "    " << R1 << " (" << R1.score() << ")" << endl;
		// cout << "    " << R0 << " (-" << R0.score() << ")" << endl;
	}
	else if (R0.tiles.size() > 0)
	{
		net -= R0.score() * 2;
		// cout << "    " << R0 << " (-" << R0.score() * 2 << ")" << endl;
	}
	else if (R1.tiles.size() > 0)
	{
		net += R1.score() * 2;
		// cout << "    " << R1 << " (" << R1.score() * 2 << ")" << endl;
	}

	return net;
}

Move method4c(Board B, Rack R0, Rack R1, int numMoves, int nextMoves)
{
	G.setBoard(B);
	G.allcrosses();
	G.setRack(R0);
	G.setExch(false);
	G.setKibitzLength(0);
	G.kibitz();

	MoveList allmoves = G.allPossiblePlays();
	MoveList moves;

	for (int i = 0; i < allmoves.size(); i++)
	{
		double estimate = allmoves[i].score;

		Rack R2 = R0;
		R2 -= allmoves[i];
		if (R2.tiles.size() == 0)
		{
			estimate += R1.score() * 2;
			allmoves[i].outplay = true;
		}
		else 
		{
			estimate -= 8.0 + 2.61 * R2.score();
			allmoves[i].outplay = false;
		}

		allmoves[i].endgameEquity = estimate;
	}
		
    if (allmoves.size() < numMoves)
        numMoves = allmoves.size();

    for (int i = 0; i < allmoves.size(); i++) {
        int insertpos = 0;
        bool insert = false;
        for (int j = numMoves - 1; j >= 0; j--) {
           if (j < moves.size()) {
               if (allmoves[i].endgameEquity > moves[j].endgameEquity) {
                   insertpos = j;
                   insert = true;
               }
           }
        }

		if (insert) {
            // cout << "want to insert " << m_moveList[i] << " before " << movelist[insertpos] << endl;
            MoveList::iterator it = moves.begin();
            for (int j = 0; j < insertpos; j++) {
                it++;
            }
            moves.insert(it, 1, allmoves[i]);
        }
        else {
            moves.push_back(allmoves[i]);
        }
    }

    MoveList topmoves;
    topmoves.clear();
    for (int i = 0; i < numMoves; i++)
        if (i < moves.size())
            topmoves.push_back(moves[i]);

	Move best;
	int bestSpread = -1000;

	for (int i = 0; i < topmoves.size(); i++)
	{
		int spread = topmoves[i].score;
		Board B2 = B;
		B2.makemove(topmoves[i]);
		Rack R2 = R0;
		R2 -= topmoves[i];

		// cout << "    " << moves[i] << " (" << moves[i].score << ")";	
		spread -= nullmove3(B2, R1, R2, 0, nextMoves); 
		// cout << "    [" <<  spread << "]" << endl;

		if (spread > bestSpread)
		{
			best = topmoves[i];
			bestSpread = spread;
		}
	}

	return best;
}


int playout(Board B, Rack R0, Rack R1, int first)
{
	int net = 0;
	
	int i = first;
	
	int scoreless = 0;

	while ((R0.tiles.size() > 0) && (R1.tiles.size() > 0) && (scoreless < 2))
	{
		Move M;
		if ((i % 2) == 0)
		{
			M = method4c(B, R0, R1, 10, 3);
			if (M.action == Move::Place)
			{
				B.makemove(M);
				R0 -= M;
				net += M.score;
			}
			cout << "Player 1: " << M << " (" << M.score << ")" << endl;
		}
		else
		{
			M = method2(B, R1, R0);
			if (M.action == Move::Place)
			{		
				B.makemove(M);
				net -= M.score;
				R1 -= M;
			}
			cout << "Player 2: " << M << " (-" << M.score << ")" << endl;
		}
			
		if (M.action == Move::Place)
			scoreless = 0;
		else
			scoreless++;
	
		i++;
	}

	if ((R0.tiles.size() > 0) && (R1.tiles.size() > 0))
	{
		net -= R0.score();
		net += R1.score();
		cout << R1 << " (" << R1.score() << ")" << endl;
		cout << R0 << " (-" << R0.score() << ")" << endl;
	}
	else if (R0.tiles.size() > 0)
	{
		net -= R0.score() * 2;
		cout << R0 << " (-" << R0.score() * 2 << ")" << endl;
	}
	else if (R1.tiles.size() > 0)
	{
		net += R1.score() * 2;
		cout << R1 << " (" << R1.score() * 2 << ")" << endl;
	}

	return net;
}			

int main()
{
	G.setLexicon(Generator::TWL06);

	for (int i = 0; i < 1000; i++)
	{
		Board B;
		B.init();
		G.setBoard(B);

		Bag S;

		Rack R[2];
		S.refill(R[0]);
		S.refill(R[1]);

		for (int j = 0; (j < 40) && (S.size() > 0); j++)
		{
			G.setRack(R[j % 2]);

			bool canexch = false;

			if (S.size() >= 7)
				canexch = true;	

			G.setExch(canexch);
			G.kibitz();
			Move M = G.bestMove();

			if (M.action == Move::Place)
			{
				B.makemove(M);
				G.makemove(M);
				R[j % 2] -= M;
				S.refill(R[j % 2]);
			}
			else if (M.action == Move::Exchange)
			{
				S.exch(M, R[j % 2]);
			}
		}

		cout << B << endl;
		cout << R[0] << " " << endl;
		cout << R[1] << " " << endl;
		cout << endl;

		int spread;

		spread = playout(B, R[0], R[1], 0);
		cout << "R0 M0 first, spread: " << spread << endl << endl;	
		
		spread = playout(B, R[1], R[0], 0);
		cout << "R1 M0 first, spread: " << spread << endl << endl;	
	
		spread = playout(B, R[1], R[0], 1);
		cout << "R0 M1 first, spread: " << -spread << endl << endl;	
		
		spread = playout(B, R[0], R[1], 1);
		cout << "R1 M1 first, spread: " << -spread << endl << endl;	
	
	}
		
	return 0;
}

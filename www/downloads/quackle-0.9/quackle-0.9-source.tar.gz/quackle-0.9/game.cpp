/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>
#include <sstream>

#include "computerplayer.h"
#include "datamanager.h"
#include "evaluator.h"
#include "gameparameters.h"
#include "game.h"

// define this to get copious bag debugging messages
//#define DEBUG_BAG

using namespace Quackle;

Game::Game()
	: m_defaultComputerPlayer(0)
{
	reset();
}

Game::~Game()
{
	cleanupComputerPlayers();
}

void Game::reset()
{
	m_positions.clear();
	cleanupComputerPlayers();

	PlayerList dummyPlayers;
	dummyPlayers.push_back(Player(MARK_UV("Dummy"), Quackle::Player::HumanPlayer));
	m_positions.setPlayers(dummyPlayers);
}

void Game::setPlayers(const PlayerList &list)
{
	PlayerList idedPlayers(list);
	const PlayerList::iterator end(idedPlayers.end());
	int i = 0;
	for (PlayerList::iterator it = idedPlayers.begin(); it != end; ++it, ++i)
		(*it).setId(i);

	m_positions.setPlayers(idedPlayers);
}

void Game::cleanupComputerPlayers()
{
	for (ComputerPlayerMap::iterator it = m_computerPlayers.begin(); it != m_computerPlayers.end(); ++it)
		delete (*it).second;
	
	m_computerPlayers.clear();
}

void Game::addPosition()
{
	addClonePosition();
	m_positions.lastPosition().incrementTurn();

	m_positions.setCurrentLocation(m_positions.lastLocation());

	// start with move list afresh
	m_positions.lastPosition().removeAllMoves();

	// don't reset if game is over as increment might
	// have set the move made to be an unused tile bonus
	if (!m_positions.lastPosition().gameOver())
		resetCandidature();
}

void Game::addClonePosition()
{
	m_positions.eraseAfter(m_positions.currentLocation());

	if (m_positions.empty())
		m_positions.push_back(GamePosition(m_positions.players()));
	else
		m_positions.push_back(m_positions.lastPosition());
}

void Game::setCurrentPosition(const GamePosition &position)
{
	currentPosition() = position;
	setCurrentPosition(position.location());
}

void Game::associateComputerPlayer(int playerId, ComputerPlayer *computerPlayer)
{
	if (m_computerPlayers.find(playerId) != m_computerPlayers.end())
		delete m_computerPlayers[playerId];

	m_computerPlayers[playerId] = computerPlayer;
}

void Game::associateKnownComputerPlayers()
{
	const PlayerList::const_iterator end(m_positions.players().end());
	for (PlayerList::const_iterator it = m_positions.players().begin(); it != end; ++it)
	{
		if ((*it).type() == Player::ComputerPlayer)
		{
			ComputerPlayer *computerPlayer = ComputerPlayer::createComputerPlayer((*it).computerType());

			if (computerPlayer)
				associateComputerPlayer((*it).id(), computerPlayer);
		}
	}
}

ComputerPlayer *Game::computerPlayer(int playerId)
{
	if (m_computerPlayers.find(playerId) == m_computerPlayers.end())
		return defaultComputerPlayer();
	
	return m_computerPlayers[playerId];
}

void Game::setDefaultComputerPlayer(ComputerPlayer *computerPlayer)
{
	if (m_defaultComputerPlayer)
		delete m_defaultComputerPlayer;
	
	m_defaultComputerPlayer = computerPlayer;
}

ComputerPlayer *Game::defaultComputerPlayer()
{
	if (m_defaultComputerPlayer)
		return m_defaultComputerPlayer;
	
	m_defaultComputerPlayer = new StaticPlayer;
	return m_defaultComputerPlayer;
}

Move Game::haveComputerPlay(ComputerPlayer *computerPlayer)
{
	if (currentPosition().gameOver())
		return Move::createNonmove();

	if (!computerPlayer)
		computerPlayer = this->computerPlayer(currentPosition().currentPlayer().id());
	
	computerPlayer->setPosition(currentPosition());

	Move move(computerPlayer->move());
	commitMove(move);
	return move;
}

void Game::advanceToNoncomputerPlayer()
{
	while (!currentPosition().gameOver() && currentPosition().currentPlayer().type() == Player::ComputerPlayer)
		haveComputerPlay();
}

void Game::commitCandidate(bool maintainBoard)
{
	if (currentPosition().gameOver())
		return;

	Move moveMade(currentPosition().moveMade());
	addPosition();

	// note this comes after addPosition --
	// ensuring exchanged tiles can't be drawn
	currentPosition().makeMove(moveMade, maintainBoard);

#ifdef DEBUG_BAG
	currentPosition().ensureProperBag();
#endif
}

void Game::commitMove(const Move &move)
{
	setCandidate(move);
	commitCandidate();
}

///////////

GamePosition::GamePosition(const PlayerList &players)
	: m_players(players), m_currentPlayer(m_players.end()), m_turnNumber(0), m_scorelessTurnsInARow(0), m_gameOver(false)
{
	setEmptyBoard();
	resetMoveMade();
	resetBag();
}

GamePosition::GamePosition(const GamePosition &position)
	: m_players(position.m_players), m_moves(position.m_moves), m_moveMade(position.m_moveMade), m_turnNumber(position.m_turnNumber), m_scorelessTurnsInARow(position.m_scorelessTurnsInARow), m_gameOver(position.m_gameOver), m_board(position.m_board), m_bag(position.m_bag), m_drawingOrder(position.m_drawingOrder)
{
	// reset iterator
	if (position.turnNumber() == 0)
		m_currentPlayer = m_players.end();
	else
		setCurrentPlayer(position.currentPlayer().id());
}

GamePosition::GamePosition()
	: m_currentPlayer(m_players.end()), m_turnNumber(0), m_gameOver(false) 
{
	setEmptyBoard();
	resetMoveMade();
	resetBag();
}

void GamePosition::kibitz(int kibitzLength)
{
	QUACKLE_GENERATOR->setPosition(*this);
	QUACKLE_GENERATOR->kibitz(kibitzLength, exchangeAllowed()? Generator::RegularKibitz : Generator::CannotExchange);

	m_moves = QUACKLE_GENERATOR->kibitzList();

	const MoveList::iterator end(m_moves.end());
	for (MoveList::iterator it = m_moves.begin(); it != end; ++it)
		ensureMovePrettiness(*it);
}

const Move &GamePosition::staticBestMove()
{
	kibitz(1);
	return m_moves.back();
}

void GamePosition::removeMove(const Quackle::Move &move)
{
	const MoveList::iterator end(m_moves.end());
	for (MoveList::iterator it = m_moves.begin(); it != end; ++it)
	{
		if ((*it) == move)
		{
			m_moves.erase(it);
			break;
		}
	}
}

void GamePosition::removeAllMoves()
{
	m_moves.clear();
}

void GamePosition::ensureMovePrettiness(Move &move)
{
	if (move.prettyTiles().empty())
		move.setPrettyTiles(m_board.prettyTilesOfMove(move));
}

void GamePosition::addMove(const Move &move)
{
	if (move.isAMove())
	{
		Move prettifiedMove(move);
		ensureMovePrettiness(prettifiedMove);
		m_moves.push_back(prettifiedMove);

		MoveList::sort(m_moves, MoveList::Equity);
	}
}

void GamePosition::addAndSetMoveMade(const Move &move)
{
	addMove(move);
	setMoveMade(move);
}

int GamePosition::validateMove(const Move &move) const
{
	int ret = ValidMove;

	switch (move.action)
	{
	case Move::Place:
	case Move::Exchange:
		if (!validateTiles(move.usedTiles()))
			ret |= InvalidTiles;

		if (move.action == Move::Place)
		{
			// Place action -- ensure the word connects to others
			if (!isConnected(move))
				ret |= InvalidPlace;

			if (m_board.isUnacceptableOpeningMove(move))
				ret |= InvalidOpeningPlace;

			// check if the word is acceptable
			if (!formsAcceptableWords(move))
				ret |= UnacceptableWord;
		}
		else
		{
			// Exchange action -- ensure there are enough tiles in bag
			if (!exchangeAllowed())
				ret |= TooLateExchange;
		}
		break;
	
	case Move::ScoreAddition:
	case Move::UnusedTilesBonus:
	case Move::TimePenalty:
		ret = InvalidAction;
		break;

	case Move::Nonmove:
		break;
	}

	return ret;
}

bool GamePosition::isConnected(const Move &move) const
{
	return m_board.isConnected(move);
}

bool GamePosition::formsAcceptableWords(const Move &move) const
{
	vector<LetterString> words = m_board.allWordsFormedBy(move);

	for (vector<LetterString>::const_iterator it = words.begin(); it != words.end(); ++it)
		if (!isAcceptableWord(*it))
			return false;
	
	return true;
}

bool GamePosition::isAcceptableWord(const LetterString &word) const
{
	return QUACKLE_GENERATOR->isAcceptableWord(word);
}

bool GamePosition::validateTiles(const LetterString &tiles) const
{
	return currentPlayer().rack().contains(tiles);
}

bool GamePosition::exchangeAllowed() const
{
	return m_bag.size() >= QUACKLE_PARAMETERS->minimumTilesForExchange();
}

void GamePosition::makeMove(const Move &move, bool maintainBoard)
{
	QUACKLE_GENERATOR->setPosition(*this);
	QUACKLE_GENERATOR->makeMove(move, maintainBoard);
	m_board = QUACKLE_GENERATOR->position().board();

	if (move.action == Move::Exchange)
		m_bag.toss(move.usedTiles());
}

Move GamePosition::scoreMove(const Move &move)
{
	Move ret(move);
	ret.score = calculateScore(ret);
	ret.equity = calculateEquity(ret);
	return ret;
}

int GamePosition::calculateScore(const Move &move)
{
	return m_board.score(move);
}

double GamePosition::calculateEquity(const Move &move)
{
	return QUACKLE_EVALUATOR->equity(*this, move);
}

double GamePosition::calculatePlayerConsideration(const Move &move)
{
	return QUACKLE_EVALUATOR->playerConsideration(*this, move);
}

double GamePosition::calculateSharedConsideration(const Move &move)
{
	return QUACKLE_EVALUATOR->sharedConsideration(*this, move);
}

Bag GamePosition::unseenBag() const
{
	// one way:
	//Bag ret(m_board.tilesNotOnBoard());
	//ret.removeLetters(currentPlayer().rack().usedTiles());

	// other way:
	Bag ret(m_bag);
	const PlayerList::const_iterator end(m_players.end());
	for (PlayerList::const_iterator it = m_players.begin(); it != end; ++it)
		if (it != m_currentPlayer)
			ret.toss((*it).rack());
	
	return ret;
}

UVString GamePosition::unseenTiles() const
{
	return unseenBag().toString();
}

void GamePosition::ensureProperBag() const
{
	Bag goodBag(m_board.tilesNotOnBoard());
#ifdef DEBUG_BAG
	UVcout << "tiles not on board: " << goodBag << endl;
#endif

	const PlayerList::const_iterator end(m_players.end());
	for (PlayerList::const_iterator it = m_players.begin(); it != end; ++it)
		goodBag.removeLetters((*it).rack().tiles());
	
#ifdef DEBUG_BAG
	UVcout << "ensureProperBag: bag was \n" << m_bag << ", good bag is \n" << goodBag << endl;
#endif
}

void GamePosition::setEmptyBoard()
{
	m_board.prepareEmptyBoard();
}

void GamePosition::replenishAndSetRack(const Rack &previousRack, Player &player)
{
#ifdef DEBUG_BAG
	UVcout << "replenishAndSetRack(" << previousRack << ", " << player << ")" << endl;
#endif
	Rack newRack(previousRack);

#ifdef DEBUG_BAG
	UVcout << "(Before refill) " << m_bag << endl;
#endif

	if (m_drawingOrder.empty())
		m_bag.refill(newRack);
	else
		m_drawingOrder = m_bag.refill(newRack, m_drawingOrder);

#ifdef DEBUG_BAG
	UVcout << "(After  refill) " << m_bag << endl;
	UVcout << "Rack refilled to " << newRack << endl;
#endif

	player.setRack(newRack);
	player.setDrawnLetters(newRack - previousRack);
}

void GamePosition::setCurrentPlayerRack(const Rack &rack, bool adjustBag)
{
	setPlayerRack(currentPlayer().id(), rack, adjustBag);
}

void GamePosition::setPlayerRack(int playerID, const Rack &rack, bool adjustBag)
{
	const PlayerList::iterator end(m_players.end());
	for (PlayerList::iterator it = m_players.begin(); it != end; ++it)
	{
		if ((*it).id() == playerID)
		{
			// restore bag
			if (adjustBag)
			{
				removeLetters((rack - (*it).rack()).tiles());
				m_bag.toss((*it).rack() - rack);
			}

			(*it).setRack(rack);
		}
	}

#ifdef DEBUG_BAG
	ensureProperBag();
#endif
}

bool GamePosition::setCurrentPlayer(int playerID)
{
	const PlayerList::iterator end(m_players.end());
	for (PlayerList::iterator it = m_players.begin(); it != end; ++it)
	{
		if ((*it).id() == playerID)
		{
			m_currentPlayer = it;
			return true;
		}
	}
	
	m_currentPlayer = m_players.begin();
	return false;
}

Board GamePosition::boardAfterMoveMade() const
{
	Board ret(m_board);
	ret.makeMove(m_moveMade);
	return ret;
}

void GamePosition::resetMoveMade()
{
	m_moveMade = Move::createNonmove();
}

void GamePosition::resetBag()
{
	m_bag.prepareFullBag();
}

bool GamePosition::incrementTurn()
{
	if (gameOver() || m_players.empty())
		return false;

	PlayerList::iterator previousCurrentPlayer(m_currentPlayer);

	bool ret = false;

	// if current player is players.end(), we haven't started game
	// and go to first player after incrementing
	if (m_currentPlayer != m_players.end())
	{
		Rack remainingRack(currentPlayer().rack() - m_moveMade);

		Rack moveTiles(m_moveMade.usedTiles());
		moveTiles.unload(currentPlayer().rack().tiles());

		// now moveTiles is the tiles that are in play but not on rack
		removeLetters(moveTiles.tiles());

		// update our current players score before possibly
		// adding endgame bonuses
		currentPlayer().addToScore(m_moveMade.score);

		// player played out
		if (m_bag.empty() && remainingRack.empty())
		{
			// magic!
			++m_turnNumber;

			if (!m_gameOver)
			{
				// we become over based on player playing out
				// with empty bag
				adjustScoresToFinishGame();

				m_gameOver = true;
			}
		}

		if ((m_moveMade.action == Move::Place && m_moveMade.score == 0) || m_moveMade.action == Move::Exchange || m_moveMade.action == Move::Pass)
			++m_scorelessTurnsInARow;
		else
			m_scorelessTurnsInARow = 0;

		if (!m_gameOver)
		{
			if (QUACKLE_PARAMETERS->numberOfScorelessTurnsThatEndsGame() >= 0 && m_scorelessTurnsInARow >= QUACKLE_PARAMETERS->numberOfScorelessTurnsThatEndsGame() && !m_board.isEmpty())
			{
				// magic!
				++m_turnNumber;

				adjustScoresToFinishPassedOutGame();

				m_gameOver = true;
			}
		}

		// refill rack of player that just played
		replenishAndSetRack(remainingRack);

		// now move onto next player
		++m_currentPlayer;
	}

	if (m_currentPlayer == m_players.end())
	{
		++m_turnNumber;
		m_currentPlayer = m_players.begin();
		ret = true;
	}

	// ensure players get a rack at the beginning of the game,
	// and that the first player draws first (even though yes
	// olaugh I realize that it doesn't matter :-)
	if (currentPlayer().rack().empty())
		replenishAndSetRack(currentPlayer().rack());

	// refill rack of any player whose rack is empty (again for
	// beginning of game)
	const PlayerList::iterator end(m_players.end());
	for (PlayerList::iterator it = m_players.begin(); it != end; ++it)
		if ((*it).rack().empty())
			replenishAndSetRack((*it).rack(), *it);

	// freeze current player as last person who played out
	if (gameOver())
		m_currentPlayer = previousCurrentPlayer;

	// kill drawing order
	m_drawingOrder = LetterString();

	return ret;
}

bool GamePosition::removeLetters(const LetterString &letters)
{
	bool ret = true;

	const LetterString::const_iterator end(letters.end());
	for (LetterString::const_iterator it = letters.begin(); it != end; ++it)
	{
#ifdef DEBUG_BAG
		UVcout << "removeLetters processing " << *it << endl;
#endif

		const bool removedFromBag = m_bag.removeLetter(*it);
		if (removedFromBag)
		{
#ifdef DEBUG_BAG
			UVcout << "removed from bag" << endl;
#endif
		}
		else
		{
			bool removedFromPlayer = false;
			const PlayerList::iterator playersEnd(m_players.end());
			for (PlayerList::iterator playerIt = m_players.begin(); playerIt != playersEnd; ++playerIt)
			{
				if (*playerIt == currentPlayer())
					continue;

				LetterString letterString;
				letterString += (*it);

				Rack newRack((*playerIt).rack());
				removedFromPlayer = newRack.unload(letterString);
				if (removedFromPlayer)
				{
					replenishAndSetRack(newRack, *playerIt);
					break;
				}
			}

			if (removedFromPlayer)
			{
#ifdef DEBUG_BAG
				UVcout << "removed from player" << endl;
#endif
			}
			else
			{
#ifdef DEBUG_BAG
				UVcout << "couldn't find any place to remove " << *it << " from!" << endl;
#endif

				ret = false;
			}
		}
	}

	return ret;
}

PlayerList GamePosition::endgameAdjustedScores() const
{
	PlayerList ret;
	const PlayerList::const_iterator end(m_players.end());
	for (PlayerList::const_iterator it = m_players.begin(); it != end; ++it)
	{
		Player adjustedPlayer(*it);

		if (gameOver() && adjustedPlayer == currentPlayer())
			adjustedPlayer.addToScore(m_moveMade.score);

		ret.push_back(adjustedPlayer);
	}

	return ret;
}

PlayerList GamePosition::leadingPlayers() const
{
	PlayerList ret;

	PlayerList players(endgameAdjustedScores());
	for (PlayerList::const_iterator it = players.begin(); it != players.end(); ++it)
	{
		if (!ret.empty() && (*it).score() > ret.back().score())
			ret.clear();

		if (ret.empty() || (*it).score() >= ret.back().score())
			ret.push_back(*it);
	}

	return ret;
}

int GamePosition::spread(int playerID) const
{
	int nextBest = 0;
	int currentPlayerScore = 0;

	PlayerList players(endgameAdjustedScores());
	for (PlayerList::const_iterator it = players.begin(); it != players.end(); ++it)
	{
		if ((*it).id() == playerID)
		{
			currentPlayerScore = (*it).score();
			continue;
		}

		if ((*it).score() > nextBest)
			nextBest = (*it).score();
	}

	return currentPlayerScore - nextBest;
}

void GamePosition::adjustScoresToFinishPassedOutGame()
{
	int addand = 0;
	LetterString clobberedTiles;

	const PlayerList::iterator end(m_players.end());
	for (PlayerList::iterator it = m_players.begin(); it != end; ++it)
	{
		if (it == m_currentPlayer)
		{
			m_moveMade = Move::createUnusedTilesBonus((*it).rack().tiles(), -(*it).rack().score());
		}
		else
		{
			(*it).addToScore(-(*it).rack().score());
		}
	}

	// this creates inconsistency in access to score - current score
	// is always currentPlayer().score() + moveMade.score
	//currentPlayer().addToScore(m_moveMade.score);
}

void GamePosition::adjustScoresToFinishGame()
{
	int addand = 0;
	LetterString clobberedTiles;

	const PlayerList::const_iterator end(m_players.end());
	for (PlayerList::const_iterator it = m_players.begin(); it != end; ++it)
	{
		if (it == m_currentPlayer)
			continue;

		addand += (*it).rack().score();
		clobberedTiles += (*it).rack().tiles();
	}

	m_moveMade = Move::createUnusedTilesBonus(clobberedTiles, 2 * addand);

	// this creates inconsistency in access to score - current score
	// is always currentPlayer().score() + moveMade.score
	//currentPlayer().addToScore(m_moveMade.score);
}

UVOStream& operator<<(UVOStream& o, const Quackle::GamePosition &position)
{
	o << "Position [turnNumber = " << position.turnNumber() << ", current player " << position.currentPlayer() << endl;
	o << position.board() << endl;
	o << "Move made is " << position.moveMade() << endl;
	o << "All Players: " << endl;
	PlayerList players(position.players());
	const PlayerList::const_iterator end(players.end());
	for (PlayerList::const_iterator it = players.begin(); it != end; ++it)
		o << *it << endl;
	o << position.bag() << endl;
	o << "------------" << endl;
    return o;
}

UVOStream& operator<<(UVOStream& o, const Quackle::PositionList &positions)
{
	const Quackle::PositionList::const_iterator end(positions.end());
	for (Quackle::PositionList::const_iterator it = positions.begin(); it != end; ++it)
		o << *it << endl;
	return o;
}

///////////////

int History::maximumTurnNumber() const
{
	if (empty())
		return 0;

	return back().turnNumber();
}

PositionList History::positionsFacedBy(int playerID) const
{
	PositionList ret;
	const PositionList::const_iterator ourEnd(end());
	for (PositionList::const_iterator it = begin(); it != ourEnd; ++it)
		if ((*it).currentPlayer().id() == playerID)
			ret.push_back(*it);

	return ret;
}

const GamePosition &History::lastPositionFacedBy(int playerID) const
{
	return positionsFacedBy(playerID).back();
}

const GamePosition &History::secondToLastPositionFacedBy(int playerID, bool &exists) const
{
	PositionList positions(positionsFacedBy(playerID));
	if (positions.size() >= 2)
	{
		exists = true;
		return *(++positions.rbegin());
	}
	else
	{
		exists = false;
		return positions.back();
	}
}

const GamePosition &History::positionAt(const HistoryLocation &location) const
{
	for (PositionList::const_reverse_iterator it = rbegin(); it != rend(); ++it)
		if ((*it).currentPlayer().id() == location.playerId() && (*it).turnNumber() == location.turnNumber())
			return *it;

	return back();
}

GamePosition &History::mutablePositionAt(const HistoryLocation &location)
{
	for (PositionList::reverse_iterator it = rbegin(); it != rend(); ++it)
		if ((*it).currentPlayer().id() == location.playerId() && (*it).turnNumber() == location.turnNumber())
			return *it;

	return back();
}

void History::eraseAfter(const HistoryLocation &location)
{
	while (true)
	{
		if (empty())
			break;

		bool isAfter;

		if (location.turnNumber() == back().turnNumber())
			isAfter = location.playerId() < back().currentPlayer().id();
		else
			isAfter = location.turnNumber() < back().turnNumber();

		if (isAfter)
			pop_back();
		else
			break;
	}
}

////////

HistoryLocation::HistoryLocation(int playerId, int turnNumber)
	: m_playerId(playerId), m_turnNumber(turnNumber)
{
}

bool operator<(const HistoryLocation &hl1, const HistoryLocation &hl2)
{
	if (hl1.turnNumber() != hl2.turnNumber())
		return hl1.turnNumber() < hl2.turnNumber();
	return hl1.playerId() < hl2.playerId();
}

bool operator==(const Quackle::HistoryLocation &hl1, const Quackle::HistoryLocation &hl2)
{
	return hl1.turnNumber() == hl2.turnNumber() && hl1.playerId() == hl2.playerId();
}

UVOStream& operator<<(UVOStream& o, const Quackle::HistoryLocation &historyLocation)
{
	o << "location turn number " << historyLocation.turnNumber() << ", player id " << historyLocation.playerId();
	return o;
}


/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef QUACKLE_BAG_H
#define QUACKLE_BAG_H

#include "alphabetparameters.h"
#include "rack.h"

using namespace std;

namespace Quackle
{

class Move;

class Bag
{
public:
	Bag();

	void clear();

	void exch(const Move &move, Rack &rack);

	// removes and returns a random letter from bag
	Letter pluck();

	// returns true if all letters were in the bag before
	// and were removed
	bool removeLetters(const LetterString &letters);

	// returns true if the letter was in the bag and was
	// removed
	bool removeLetter(Letter letter);

	// how many of a letter are in the bag
	int countOfLetter(const Letter &letter) const;

	// put letters back in the bag
	void toss(const LetterString &letters);
	void toss(const Rack &rack);

	// Fill rack up with tiles from the bag picked in random order.
	// Alphabetizes rack.
	void refill(Rack &rack);

	// Fill rack up with tiles from the bag picked in drawingOrder,
	// starting from the back of the LetterString.
	// Returns letters from drawingOrder that weren't added to the bag.
	// Alphabetizes rack.
	LetterString refill(Rack &rack, const LetterString &drawingOrder);

	// use this to start out your bag for use
	void prepareFullBag();

	// whether there are no tiles left in the bag
	bool empty() const;

	// returns number of tiles left in the bag
	int size() const;

	const LetterString &tiles() const;
	
	// returns our tiles in a random order
	LetterString shuffledTiles() const;

	static double probabilityOfDrawingFromFullBag(const LetterString &letters);
	static double probabilityOfDrawingFromBag(const LetterString &letters, const Bag &bag);
	double probabilityOfDrawing(const LetterString &letters);

	UVString toString() const;

private:
	// remove letter from the bag
	Letter erase(int pos);

	LetterString m_tiles;
};

inline void Bag::toss(const Rack &rack)
{
	toss(rack.tiles());
}

inline bool Bag::empty() const
{
    return m_tiles.empty();
}

inline int Bag::size() const
{
    return m_tiles.size();
}

inline const LetterString &Bag::tiles() const
{
	return m_tiles;
}

}

UVOStream &operator<<(UVOStream &o, const Quackle::Bag &bag);

#endif

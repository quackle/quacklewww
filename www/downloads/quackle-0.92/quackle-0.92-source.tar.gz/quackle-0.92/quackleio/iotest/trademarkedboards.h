#ifndef QUACKLE_TRADEMARKEDBOARDS_H
#define QUACKLE_TRADEMARKEDBOARDS_H

#include "boardparameters.h"

// Name: Scrabble Board
class ScrabbleBoard : public Quackle::BoardParameters
{
public:
	ScrabbleBoard();
};

// Name: Super Scrabble Board
class SuperScrabbleBoard : public Quackle::BoardParameters
{
public:
	SuperScrabbleBoard();
};

#endif

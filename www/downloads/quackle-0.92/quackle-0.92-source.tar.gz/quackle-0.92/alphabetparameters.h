/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef QUACKLE_ALPHABETPARAMETERS_H
#define QUACKLE_ALPHABETPARAMETERS_H

#include <vector>

#include "uv.h"

using namespace std;

#define QUACKLE_MAXIMUM_ALPHABET_SIZE 31
#define QUACKLE_MINIMUM_ALPHABET_SIZE 1

// Quackle's alphabet scheme includes a way to represent blanks
// in two ways: either as the blank letter or as the letter plus
// the blank offset

// we officially define null but others are only euglenids+i...
#define QUACKLE_NULL_MARK_TEXT MARK_UV(" ")
#define QUACKLE_NULL_MARK 0

#define QUACKLE_BLANK_MARK 1 // let this be '?'
#define QUACKLE_PLAYED_THRU_MARK 2 // let this be '.'
#define QUACKLE_PLAYTHRU_START_MARK 3 // let this be '('
#define QUACKLE_PLAYTHRU_END_MARK 4 // let this be ')'
#define QUACKLE_FIRST_LETTER 5

#define QUACKLE_BLANK_OFFSET QUACKLE_MAXIMUM_ALPHABET_SIZE

namespace Quackle
{

// The reason for String namespace is to allow us to use
// strings as a vector-like data structure (in case we ever switch
// to one, altho I tried and this is slow) but to get the optimization
// of the native libstdc++ string implementation. If we ever need more
// than 31 letters we can use UVChar for the basic Letter type.

#if QUACKLE_USE_WCHAR_FOR_LETTER
typedef wchar_t Letter;
typedef wstring LetterString;
#else
typedef char Letter;
typedef string LetterString;
#endif // QUACKLE_USE_WCHAR_FOR_LETTER

namespace String
{

LetterString left(const LetterString &letterString, int number);

LetterString clearBlankness(const LetterString &letterString);
LetterString setBlankness(const LetterString &letterString);

// turns string like .ANELINn into .ANELIN?
LetterString usedTiles(const LetterString &letterString);

// allocate a countsArray of size
// QUACKLE_FIRST_LETTER + QUACKLE_MAXIMUM_ALPHABET_SIZE
void counts(const LetterString &letterString, char *countsArray);

inline Letter back(const LetterString &letterString)
{
	return *(letterString.end() - 1);
}

inline void pop_back(LetterString &letterString)
{
	letterString.erase(letterString.end() - 1);
}

inline Letter front(const LetterString &letterString)
{
	return *letterString.begin();
}

inline void pop_front(LetterString &letterString)
{
	letterString.erase(letterString.begin());
}

inline LetterString allButFront(const LetterString &letterString)
{
	//LetterString ret;
	//ret.insert(ret.end(), ++letterString.begin(), letterString.end());
	//return ret;
	return letterString.substr(1, letterString.length() - 1);
}

}

class LetterParameter
{
public:
	LetterParameter();
	LetterParameter(Letter letter);
	LetterParameter(Letter letter, const UVString &text, const UVString &blankText, int score = 0, int count = 0, bool isVowel = false);

	UVString text() const;
	void setText(const UVString &text);

	UVString blankText() const;
	void setBlankText(const UVString &blankText);

	Letter letter() const;
	void setLetter(Letter letter);

	int score() const;
	void setScore(int score);

	// number of doodads in the bag
	int count() const;
	void setCount(int count);

	bool isVowel() const;
	void setVowel(bool isVowel);

private:
	Letter m_letter;
	UVString m_text;
	UVString m_blankText;
	int m_score;
	int m_count;
	bool m_isVowel;
};

inline LetterParameter::LetterParameter()
	: m_letter(QUACKLE_NULL_MARK), m_score(0), m_isVowel(false)
{
}

inline LetterParameter::LetterParameter(Letter letter)
	: m_letter(letter), m_score(0), m_isVowel(false)
{
}

inline LetterParameter::LetterParameter(Letter letter, const UVString &text, const UVString &blankText, int score, int count, bool isVowel)
	: m_letter(letter), m_text(text), m_blankText(blankText), m_score(score), m_count(count), m_isVowel(isVowel)
{
}

inline UVString LetterParameter::text() const
{
	return m_text;
}

inline void LetterParameter::setText(const UVString &text)
{
	m_text = text;
}

inline UVString LetterParameter::blankText() const
{
	return m_blankText;
}

inline void LetterParameter::setBlankText(const UVString &blankText)
{
	m_blankText = blankText;
}

inline Letter LetterParameter::letter() const
{
	return m_letter;
}

inline void LetterParameter::setLetter(Letter letter)
{
	m_letter = letter;
}

inline int LetterParameter::score() const
{
	return m_score;
}

inline void LetterParameter::setScore(int score)
{
	m_score = score;
}

inline int LetterParameter::count() const
{
	return m_count;
}

inline void LetterParameter::setCount(int count)
{
	m_count = count;
}

inline bool LetterParameter::isVowel() const
{
	return m_isVowel;
}

inline void LetterParameter::setVowel(bool isVowel)
{
	m_isVowel = isVowel;
}

typedef vector<LetterParameter> Alphabet;

class AlphabetParameters
{
public:
	AlphabetParameters();

	// Returns how many letters there are (excludes blanks and null letter).
	// Thus this return value is how many letters there are inclusively between
	// QUACKLE_FIRST_LETTER and lastLetter()
	int length() const;

	// first letter in alphabet -- same as the #define
	Letter firstLetter() const;

	// the last letter in the alphabet -- all letters after this are blanks
	Letter lastLetter() const;

	const Alphabet &alphabet() const;
	void setAlphabet(const Alphabet &alphabet);

	LetterParameter letterParameter(Letter letter) const;
	void setLetterParameter(Letter letter, const LetterParameter &letterParameter);

	// get an alphabet with blank and null values set; note
	// this empty alphabet specifies no blanks in the bag
	static Alphabet emptyAlphabet();

	// useful for setting number of blanks
	void setCount(Letter letter, int count);

	// whether letter is between firstLetter + blank_offset
	// and lastLetter + blank_offset
	bool isBlankLetter(Letter letter) const;

	// returns letter if it's not a blank, or a plain
	// (nonblank) version of letter otherwise
	Letter clearBlankness(Letter letter) const;
	LetterString clearBlankness(const LetterString &letterString) const;

	// returns letter if it's a blank, or a blank
	// version of letter otherwise
	Letter setBlankness(Letter letter) const;

	// whether letter is between first and last letter
	bool isPlainLetter(Letter letter) const;

	// whether letter is a blank or plain letter or not
	bool isSomeLetter(Letter letter) const;

	int count(Letter letter) const;
	int score(Letter letter) const;
	bool isVowel(Letter letter) const;

	// alphabet-based conversion facilities:
	// LetterString -> UVString
	UVString userVisible(const LetterString &letterString) const;
	UVString userVisible(Letter letter) const;

	// UVString -> LetterString
	LetterString encode(const UVString &word) const;

protected:
	void updateLength();

	int m_length;
	Alphabet m_alphabet;
	Alphabet::const_iterator m_firstLetterIterator;
};

inline int AlphabetParameters::length() const
{
	return m_length;
}

inline Letter AlphabetParameters::firstLetter() const
{
	return QUACKLE_FIRST_LETTER;
}

inline Letter AlphabetParameters::lastLetter() const
{
	return QUACKLE_FIRST_LETTER + m_length - 1;
}

inline const Alphabet &AlphabetParameters::alphabet() const
{
	return m_alphabet;
}

inline LetterParameter AlphabetParameters::letterParameter(Letter letter) const
{
	return m_alphabet[letter];
}

inline bool AlphabetParameters::isBlankLetter(Letter letter) const
{
	return letter > lastLetter();
}

inline Letter AlphabetParameters::clearBlankness(Letter letter) const
{
	if (isBlankLetter(letter))
		return letter - QUACKLE_BLANK_OFFSET;
	else
		return letter;
}

inline Letter AlphabetParameters::setBlankness(Letter letter) const
{
	if (!isBlankLetter(letter))
		return letter + QUACKLE_BLANK_OFFSET;
	else
		return letter;
}

inline bool AlphabetParameters::isPlainLetter(Letter letter) const
{
	return letter >= firstLetter() && letter <= lastLetter();
}

inline bool AlphabetParameters::isSomeLetter(Letter letter) const
{
	return isBlankLetter(letter) || isPlainLetter(letter);
}

inline int AlphabetParameters::count(Letter letter) const
{
	return letterParameter(letter).count();
}

inline int AlphabetParameters::score(Letter letter) const
{
	return letterParameter(letter).score();
}

inline bool AlphabetParameters::isVowel(Letter letter) const
{
	return letterParameter(letter).isVowel();
}

class EnglishAlphabetParameters : public AlphabetParameters
{
public:
	EnglishAlphabetParameters();
};

}

#ifdef QUACKLE_USE_OWN_LETTERSTRING

inline Quackle::LetterString operator+(const Quackle::LetterString &letterString1, const Quackle::LetterString &letterString2)
{
	Quackle::LetterString ret(letterString1);
	return ret += letterString2;
}

inline Quackle::LetterString operator+(const Quackle::LetterString &letterString, Quackle::Letter letter)
{
	Quackle::LetterString ret;
	ret += letterString;
	return ret += letter;
}

inline Quackle::LetterString operator+(Quackle::Letter letter, const Quackle::LetterString &letterString)
{
	Quackle::LetterString ret(letter);
	return ret += letterString;
}

#endif // QUACKLE_USE_OWN_LETTERSTRING

UVOStream &operator<<(UVOStream& o, const Quackle::LetterParameter &letterParameter);
UVOStream &operator<<(UVOStream& o, const Quackle::Alphabet &alphabet);
UVOStream &operator<<(UVOStream& o, const vector<Quackle::LetterString> &letterStrings);

#endif

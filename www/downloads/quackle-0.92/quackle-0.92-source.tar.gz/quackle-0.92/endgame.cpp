/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <algorithm>
#include <iostream>

#include "endgame.h"
#include "game.h"
#include "move.h"

// define this to get lame debugging messages
// #define DEBUG_ENDGAME

using namespace Quackle;

Endgame::Endgame()
	: m_logfileIsOpen(false), m_hasHeader(false)
{
	m_originalGame.addPosition();
}

Endgame::~Endgame()
{
	closeLogfile();
}

void Endgame::setPosition(const GamePosition &position)
{
	writeLogFooter();

	m_originalGame.setCurrentPosition(position);

	m_endgameMoves.clear();
	MoveList::const_iterator end = m_originalGame.currentPosition().moves().end();
	for (MoveList::const_iterator it = m_originalGame.currentPosition().moves().begin(); it != end; ++it)
		m_endgameMoves.push_back(EndgameMove(*it));
}

void Endgame::setLogfile(const string &logfile, bool append)
{
	if (m_logfile == logfile && isLogging())
		return;

	closeLogfile();
	m_logfile = logfile;

	if (m_logfile.empty())
	{
		closeLogfile();
		return;
	}

	const ios::openmode flags = append? (ios::out | ios::app) : ios::out;
	m_logfileStream.open(m_logfile.c_str(), flags);

	m_logfileIsOpen = m_logfileStream.is_open();
	if (!m_logfileIsOpen)
		cerr << "Could not open " << m_logfile << " to write simulation log" << endl;

	m_hasHeader = false;
}

void Endgame::logMessage(const UVString &message)
{
	if (isLogging())
		m_logfileStream << message << endl;
}

void Endgame::closeLogfile()
{
	if (isLogging())
	{
		if (m_hasHeader)
			writeLogFooter();

		m_logfileStream.close();
		m_logfileIsOpen = false;
	}
}

void Endgame::writeLogHeader()
{
	if (isLogging())
	{
		m_logfileStream << "<simulation>" << endl;
		m_xmlIndent = MARK_UV("\t");

		m_hasHeader = true;

		// TODO include position data
	}
}

void Endgame::writeLogFooter()
{
	if (isLogging())
	{
		m_xmlIndent = MARK_UV("");
		m_logfileStream << "</simulation>" << endl;

		m_hasHeader = false;
	}
}

void Endgame::setIncludedMoves(const MoveList &moves)
{
	for (MoveList::const_iterator it = moves.begin(); it != moves.end(); ++it)
	{
		EndgameMoveList::iterator endgameMoveIt;
		for (endgameMoveIt = m_endgameMoves.begin(); endgameMoveIt != m_endgameMoves.end(); ++endgameMoveIt)
		{
			if ((*it) == (*endgameMoveIt).move)
				break;
		}

		// move wasn't found; add it
		if (endgameMoveIt == m_endgameMoves.end())
			m_endgameMoves.push_back(EndgameMove(*it));
	}
}

void Endgame::pruneTo(double equityThreshold, int maxNumberOfMoves)
{
	MoveList equityMoves(moves());
	MoveList toSetIncluded;
	const double absoluteEquityThreshold = equityMoves[0].equity - equityThreshold;

	const MoveList::const_iterator end = equityMoves.end();
	int i = 0;
	for (MoveList::const_iterator it = equityMoves.begin(); i < maxNumberOfMoves && it != end; ++it, ++i)
		if ((*it).equity >= absoluteEquityThreshold)
			toSetIncluded.push_back(*it);

	setIncludedMoves(toSetIncluded);
}

double Endgame::disappoint(EndgameMove hope, double bestPessimistic)
{
#ifdef DEBUG_ENDGAME
	UVcout << "    disappoint() called" << endl;
#endif

	double newOptimistic = hope.optimistic;
	
	const int realStartPlayerId = m_originalGame.currentPosition().currentPlayer().id();
	
	double beforeSpread = m_originalGame.currentPosition().spread(realStartPlayerId);
	
	m_endgameGame = m_originalGame;
	m_endgameGame.setCandidate(hope.move);
	m_endgameGame.commitCandidate(true);
	
	const int startPlayerId = m_endgameGame.currentPosition().currentPlayer().id();
	const int numberOfPlayers = m_originalGame.currentPosition().players().size();

	const int initialPlayNumber = 120;

	m_endgameGame.currentPosition().kibitz(initialPlayNumber);
	
	MoveList moves = m_endgameGame.currentPosition().moves();
	
	MoveList::const_iterator moveIt = moves.begin();

#ifdef DEBUG_ENDGAME		
	UVcout << "    disappoint's moves has " << moves.size() << " moves." << endl;
#endif	
	while((newOptimistic > bestPessimistic) && moveIt != moves.end())
	{
#ifdef DEBUG_ENDGAME
		UVcout << "    seeing if " << *moveIt << " wrecks us." << endl;
#endif
		m_endgameGame = m_originalGame;
		m_endgameGame.setCandidate(hope.move);
		m_endgameGame.commitCandidate(true);

		int levelNumber = 1;
		int playerNumber = 1;

		while (!m_endgameGame.currentPosition().gameOver())
		{
			for (playerNumber = 1; 
				 (playerNumber <= numberOfPlayers) && 
				 !m_endgameGame.currentPosition().gameOver();
				 playerNumber++)
			{
				const int playerId = m_endgameGame.currentPosition().currentPlayer().id();

				Move move = Move::createNonmove();

				if (playerId == startPlayerId && levelNumber == 1)
					move = (*moveIt);
				else
					move = m_endgameGame.currentPosition().staticBestMove();
				
#ifdef DEBUG_ENDGAME
				UVcout << "      level:" << levelNumber << ", player: " << playerId << ", move: " << move << ", score: " << move.score << ", equity: " << move.equity << endl;
#endif
				m_endgameGame.setCandidate(move);
				m_endgameGame.commitCandidate(true);
			}

			levelNumber++;
		}

		m_endgameGame.currentPosition().adjustScoresToFinishGame();

		double afterSpread = m_endgameGame.currentPosition().spread(realStartPlayerId);
		
		double spread = afterSpread - beforeSpread;

		if (spread < newOptimistic)
			newOptimistic = spread;

		moveIt++;
	}

	return newOptimistic;
}

Move Endgame::solve()
{
#ifdef DEBUG_ENDGAME
	UVcout << "Endgame::solve() called" << endl;
#endif

	const int startPlayerId = m_originalGame.currentPosition().currentPlayer().id();
	const int numberOfPlayers = m_originalGame.currentPosition().players().size();

	double bestPessimistic = -1000;
	EndgameMove bestPessMove(Move::createNonmove());
	
	EndgameMoveList::iterator moveEnd = m_endgameMoves.end();
	for (EndgameMoveList::iterator moveIt = m_endgameMoves.begin(); moveIt != moveEnd; ++moveIt)
	{

#ifdef DEBUG_ENDGAME
		UVcout << "naively playing out " << (*moveIt).move << ":" << endl;
#endif

		m_endgameGame = m_originalGame;
		
		double beforeSpread = m_endgameGame.currentPosition().spread(startPlayerId);
		
		int levelNumber = 1;
		int playerNumber = 1;

		while (!m_endgameGame.currentPosition().gameOver())
		{
			for (playerNumber = 1; 
				 (playerNumber <= numberOfPlayers) && 
				 !m_endgameGame.currentPosition().gameOver();
				 playerNumber++)
			{
				const int playerId = m_endgameGame.currentPosition().currentPlayer().id();

				Move move = Move::createNonmove();

				if (playerId == startPlayerId && levelNumber == 1)
					move = (*moveIt).move;
				else
					move = m_endgameGame.currentPosition().staticBestMove();
				
#ifdef DEBUG_ENDGAME
				UVcout << "    level:" << levelNumber << ", player: " << playerId << ", move: " << move << ", score: " << move.score << ", equity: " << move.equity << endl;
#endif
				m_endgameGame.setCandidate(move);
				m_endgameGame.commitCandidate(true);
			}

			levelNumber++;
		}

		if ((playerNumber == 2) && (levelNumber == 2))
			(*moveIt).outplay = true;
		else
			(*moveIt).outplay = false;
			
		m_endgameGame.currentPosition().adjustScoresToFinishGame();

		double afterSpread = m_endgameGame.currentPosition().spread(startPlayerId);
		
		double spread = afterSpread - beforeSpread;
		
#ifdef DEBUG_ENDGAME
		UVcout << "    spread: " << spread << endl;
#endif
	
		(*moveIt).optimistic = spread;
		(*moveIt).estimated = spread;

		if ((*moveIt).outplay)
			(*moveIt).pessimistic = spread;
		else
			(*moveIt).pessimistic = -1000;
	
		if ((*moveIt).pessimistic >= bestPessimistic)
		{
			bestPessimistic = (*moveIt).pessimistic;
			bestPessMove = (*moveIt);
		}
	}
	
	stable_sort(m_endgameMoves.begin(), m_endgameMoves.end(), EndgameMoveList::optimisticComparator);

	for (EndgameMoveList::iterator it = m_endgameMoves.begin(); it != m_endgameMoves.end(); ++it)
	{
#ifdef DEBUG_ENDGAME
		UVcout << (*it).move << ", optimistic: " << (*it).optimistic << ", pessimistic: " << (*it).pessimistic << endl;
#endif
		if ((*it).optimistic < bestPessimistic)
			return bestPessMove.move;
		
		if (!((*it).outplay))
		{
#ifdef DEBUG_ENDGAME
			UVcout << (*it) << "  original optimism: " << (*it).optimistic << endl;
#endif
			(*it).optimistic = disappoint((*it), bestPessimistic);
	
			if ((*it).optimistic > bestPessimistic)
				(*it).pessimistic = (*it).optimistic;

#ifdef DEBUG_ENDGAME
			UVcout << (*it) << "  disappointed optimism: " << (*it).optimistic << endl;
#endif
			if ((*it).pessimistic > bestPessimistic)
			{
				bestPessMove = (*it);
				bestPessimistic = (*it).pessimistic;
			}
		}
	}
	
	return bestPessMove.move;
}

bool EndgameMoveList::optimisticComparator(const EndgameMove &move1, const EndgameMove &move2)
{
	return move1.optimistic > move2.optimistic;
}

MoveList Endgame::moves() const
{
	MoveList ret;

	const EndgameMoveList::const_iterator end = m_endgameMoves.end();
	for (EndgameMoveList::const_iterator it = m_endgameMoves.begin(); it != end; ++it)
	{
		Move move((*it).move);
		move.equity = (*it).estimated;
		ret.push_back(move);
	}

	MoveList::sort(ret, MoveList::Equity);

	return ret;
}

////////////

UVOStream& operator<<(UVOStream &o, const Quackle::EndgameMove &move)
{
	o << "Endgame move " << move.move << ":";
	o << endl;
    return o;
}

UVOStream& operator<<(UVOStream& o, const Quackle::EndgameMoveList& moves)
{
	const Quackle::EndgameMoveList::const_iterator end(moves.end());
	for (Quackle::EndgameMoveList::const_iterator it = moves.begin(); it != end; ++it)
		o << (*it) << endl;
    return o;
}


/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef QUACKLE_PLAYER_H
#define QUACKLE_PLAYER_H

#include <vector>

#include "rack.h"
#include "uv.h"

using namespace std;

namespace Quackle
{

class Player
{
public:
	enum PlayerType { ComputerPlayer = 0, HumanPlayer = 1};

	// creates a Computer player whose id is -1 and zero score
	Player();

	// creates a player with zero score
	Player(const UVString &name, int playerType = HumanPlayer, int computerType = 0, int id = -1);

	void setName(const UVString &newName) { m_name = newName; }
	const UVString &name() const { return m_name; }

	void setAbbreviatedName(const UVString &newAbbreviatedName) { m_abbreviatedName = newAbbreviatedName; }
	const UVString &abbreviatedName() const { return m_abbreviatedName; }

	void setType(int playerType) { m_playerType = playerType; }
	int type() const { return m_playerType; }

	void setComputerType(int computerType) { m_computerType = computerType; }
	int computerType() const { return m_computerType; }

	// ID of real players must be greater than zero
	int id() const { return m_id; }

	// This never needs to be called by users!
	void setId(int id) { m_id = id; }

	void setRack(const Rack &newRack) { m_rack = newRack; }
	void setRack(const LetterString &rack) { m_rack = Rack(rack); }
	const Rack &rack() const { return m_rack; }

	void setScore(int score) { m_score = score; }
	int score() const { return m_score; }

	// addition = negative -> subtract from score
	void addToScore(int addition);

	void setDrawnLetters(const Rack &drawnLetters) { m_drawnLetters = drawnLetters; }
	const Rack &drawnLetters() const { return m_drawnLetters; }

	UVString storeInformationToString() const;

	// these do no error checking!!! careful!
	void loadInformationFromString(const UVString &info);
	static Player makePlayerFromString(const UVString &info);

private:
	UVString m_name;
	UVString m_abbreviatedName;
	int m_id;
	int m_playerType;
	int m_computerType;

	Rack m_rack;
	int m_score;

	// what was drawn to get TO this rack
	Rack m_drawnLetters;
};

typedef vector<Player> PlayerList;

}

// comparison based on player ID
inline bool operator<(const Quackle::Player &player1, const Quackle::Player &player2)
{
	return player1.id() < player2.id();
}

inline bool operator==(const Quackle::Player &player1, const Quackle::Player &player2)
{
	return player1.id() == player2.id();
}

UVOStream &operator<<(UVOStream &o, const Quackle::Player &player);

#endif

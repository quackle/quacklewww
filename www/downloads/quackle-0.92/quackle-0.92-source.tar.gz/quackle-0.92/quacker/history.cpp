/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>

#include <QtGui>

#include <game.h>
#include <quackleio/util.h>

#include "history.h"

History::History(QWidget *parent)
	: HistoryView(parent)
{
	m_vlayout = new QVBoxLayout(this);
	m_tableWidget = new QTableWidget(this);
	connect(m_tableWidget, SIGNAL(itemActivated(QTableWidgetItem *)), this, SLOT(itemActivated(QTableWidgetItem *)));

	setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);

	m_vlayout->addWidget(m_tableWidget);
}

void History::historyChanged(const Quackle::History &history)
{
	m_tableWidget->clear();
	const Quackle::PlayerList players(history.players());

	QStringList columnLabels;
	QStringList rowLabels;

	for (int i = 1; i <= history.maximumTurnNumber(); ++i)
		rowLabels.push_back(QString::number(i));
	
	const Quackle::GamePosition lastPosition(history.lastPosition());
	const bool gameOver = lastPosition.gameOver();
	if (gameOver)
		rowLabels.push_back(tr("Final"));

	m_tableWidget->setRowCount(rowLabels.size());
	m_tableWidget->setColumnCount(players.size());

	Quackle::PlayerList currentScores(lastPosition.endgameAdjustedScores());

	int playerCountFromZero = 0;
	Quackle::PlayerList::const_iterator currentScoresIt = currentScores.begin();
	for (Quackle::PlayerList::const_iterator it = players.begin(); it != players.end(); ++it, ++currentScoresIt, ++playerCountFromZero)
	{
		columnLabels.push_back(QuackleIO::Util::uvStringToQString((*it).name()));

		const Quackle::PositionList positions(history.positionsFacedBy((*it).id()));
		for (Quackle::PositionList::const_iterator pit = positions.begin(); pit != positions.end(); ++pit)
		{
			QTableWidgetItem *item = createItem(*pit, history.lastPlayer().id());

			const int row = /* make zero indexed */ (*pit).turnNumber() - 1;
			const int column = playerCountFromZero;
			m_tableWidget->setItem(row, column, item);

			Quackle::HistoryLocation location((*it).id(), (*pit).turnNumber());
			m_locationMap.insert(location, item);

			if (location == history.currentLocation())
				m_tableWidget->setCurrentItem(m_tableWidget->item(row, column));
		}

		if (gameOver)
		{
			QString scoreString(QString::number((*currentScoresIt).score()));

			QTableWidgetItem *item = createPlainItem(scoreString);
			m_tableWidget->setItem(rowLabels.size() - 1, playerCountFromZero, item);
		}

		if (!positions.empty())
			m_tableWidget->resizeColumnToContents(playerCountFromZero);
	}

	m_tableWidget->setHorizontalHeaderLabels(columnLabels);
	m_tableWidget->setVerticalHeaderLabels(rowLabels);

// this doesn't actually seem to be necessary -- it scrolls
// to the bottom anyway
#if QT_VERSION >=  0x040100
	m_tableWidget->scrollToBottom();
#endif
}

QTableWidgetItem *History::createItem(const Quackle::GamePosition &position, int currentPlayer)
{
	const Quackle::Move moveMade(position.moveMade());
	QString contentString;

	if (moveMade.action == Quackle::Move::Nonmove)
		contentString = tr("*TO PLAY*");
	else
	{
		const QString moveString = (position.currentPlayer().id() == currentPlayer?  QuackleIO::Util::moveToDetailedString(moveMade) : QuackleIO::Util::moveToSensitiveString(moveMade));

		const int score = position.currentPlayer().score() + moveMade.effectiveScore();

		contentString = QString("%1 \t+%2/%3").arg(moveString).arg(moveMade.effectiveScore()).arg(score);
	}

	return createPlainItem(contentString);
}

QTableWidgetItem *History::createPlainItem(const QString &contentString)
{
	QTableWidgetItem *ret = new QTableWidgetItem(contentString);
	ret->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);

	// make scores line up with each other
	ret->setTextAlignment(Qt::AlignRight);

	return ret;
}

void History::itemActivated(QTableWidgetItem *item)
{
	for (QMap<Quackle::HistoryLocation, QTableWidgetItem *>::iterator it = m_locationMap.begin(); it != m_locationMap.end(); ++it)
	{
		if (it.value() == item)
		{
			emit goToHistoryLocation(it.key());
			break;
		}
	}
}


/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <QtGui>

#include <board.h>
#include <game.h>
#include <quackleio/util.h>

#include "boarddisplay.h"

BoardWithQuickEntry::BoardWithQuickEntry(QWidget *parent)
	: View(parent)
{
	m_vlayout = new QVBoxLayout(this);

	m_lineEdit = new QLineEdit;
	connect(m_lineEdit, SIGNAL(returnPressed()), this, SLOT(quickEditReturnPressed()));

	QLabel *placeLabel = new QLabel(tr("M&ove: '<position> <word>' or 'exchange <tiles>' or 'pass'"));
	placeLabel->setBuddy(m_lineEdit);
	m_vlayout->addWidget(placeLabel);

	QHBoxLayout *placeEditLayout = new QHBoxLayout;
	m_vlayout->addLayout(placeEditLayout);
	placeEditLayout->addWidget(m_lineEdit);

	QPushButton *placeButton = new QPushButton(tr("Enter move"));
	connect(placeButton, SIGNAL(clicked()), this, SLOT(quickEditReturnPressed()));
	placeEditLayout->addWidget(placeButton);

	m_commitButton = new QPushButton(tr("&Commit"));
	connect(m_commitButton, SIGNAL(clicked()), this, SLOT(performCommit()));
	placeEditLayout->addWidget(m_commitButton);

	QPushButton *resetButton = new QPushButton(tr("Rese&t"));
	connect(resetButton, SIGNAL(clicked()), this, SLOT(reset()));
	//placeEditLayout->addWidget(resetButton);
}

BoardWithQuickEntry::~BoardWithQuickEntry()
{
}

void BoardWithQuickEntry::positionChanged(const Quackle::GamePosition &position)
{
	View::positionChanged(position);
	setLocalCandidate(position.moveMade());
}

void BoardWithQuickEntry::setLocalCandidate(const Quackle::Move &candidate)
{
	m_localCandidateMove = candidate;

	if (candidate.isAMove())
	{
		m_lineEdit->setText(QuackleIO::Util::moveToDetailedString(candidate));
		m_commitButton->setEnabled(true);
		m_commitButton->setText(tr("&Commit %1").arg(QuackleIO::Util::moveToDetailedString(candidate)));
	}
	else
	{
		m_lineEdit->clear();
		m_commitButton->setText(tr("&Commit"));
		m_commitButton->setEnabled(false);
	}
}

void BoardWithQuickEntry::quickEditReturnPressed()
{
	processCommand(m_lineEdit->text());

	m_lineEdit->clear();
}

void BoardWithQuickEntry::performCommit()
{
	emit setCandidateMove(m_localCandidateMove);
	emit commit();
}

void BoardWithQuickEntry::reset()
{
	emit setCandidateMove(Quackle::Move::createNonmove());
}

void BoardWithQuickEntry::provideHelp()
{
	QMessageBox::information(this, tr("Entering Moves - Quackle"), QString("<html>") + tr("To enter a move, click on the board once or twice and start typing. Hold down the Shift key for blanks. To exchange, type something like \"exchange QWUV\" or \"pass\" into the move editor, then press the Enter key or click \"Enter move\".") + "</html>");
}

void BoardWithQuickEntry::processCommand(const QString &command)
{
	QStringList items(command.split(" ", QString::SkipEmptyParts));
	Quackle::Move move(Quackle::Move::createNonmove());

	if (items.size() <= 0)
	{
		provideHelp();
		return;
	}

	const QString verb(items.first().toLower());

	if (verb.startsWith("pass"))
		move = Quackle::Move::createPassMove();
	else
	{
		if (items.size() != 2)
		{
			provideHelp();
			return;
		}

		if (verb.startsWith(tr("ex")))
		{
			move = Quackle::Move::createExchangeMove(QuackleIO::Util::nonBlankEncode(items.at(1)));
		}
		else
		{
			QString prettyLetters(items.at(1));
			QString letters;

			bool replace = false;
			for (int i = 0; i < prettyLetters.length(); ++i)
			{
				QChar character = prettyLetters.at(i);
				if (character == '(')
					replace = true;
				else if (character == ')')
					replace = false;
				else if (replace)
					letters += ".";
				else
					letters += character;
			}
			move = Quackle::Move::createPlaceMove(QuackleIO::Util::qstringToString(items.first()), QuackleIO::Util::encode(letters));
		}
	}

	if (move.isAMove())
		emit setCandidateMove(move);
}

///////////

TextBoard::TextBoard(QWidget *parent)
	: BoardWithQuickEntry(parent)
{
	m_textEdit = new QTextEdit;
	m_textEdit->setFontPointSize(16);
	m_textEdit->setFontFamily("Courier");
	m_vlayout->addWidget(m_textEdit);

	m_textEdit->setReadOnly(true);
}

void TextBoard::positionChanged(const Quackle::GamePosition &position)
{
	BoardWithQuickEntry::positionChanged(position);
	//m_textEdit->setHtml(QString("<html><font size=\"+4\"><pre>%1</pre></font></html>").arg(QuackleIO::Util::uvStringToQString(position.boardAfterMoveMade().toString())));
	m_textEdit->setPlainText(QString("%1").arg(QuackleIO::Util::uvStringToQString(position.boardAfterMoveMade().toString())));
}

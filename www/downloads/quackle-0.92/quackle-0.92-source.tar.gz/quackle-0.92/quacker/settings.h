/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef QUACKER_SETTINGS_H
#define QUACKER_SETTINGS_H

#include <string>

#include <QWidget>
#include <QSettings>

class QComboBox;
class QCheckBox;
class QPushButton;

using namespace std;

class CustomQSettings : public QSettings
{
Q_OBJECT

public:
	CustomQSettings() :
#if defined(Q_WS_WIN)
		QSettings((QSysInfo::WindowsVersion & QSysInfo::WV_DOS_based) ? IniFormat : NativeFormat,
			UserScope, tr("Quackle"))
#else
		QSettings()
#endif
	{}
};

class Settings : public QWidget
{
Q_OBJECT

public:
	Settings(QWidget *parent = 0);

	static Settings *self();

	bool vowelFirst() const;
	bool verboseLabels() const;
	bool scoreLabels() const;

signals:
	void refreshViews();

public slots:
	// called to set up libquackle data structures and our internal
	// data structures based on stored user settings
	void initialize();

	// called to set widgets to display current settings based
	// on libquackle data structures and our internal data structures
	void load();

	// must be called after initialize
	void createGUI();

protected slots:
	void lexiconChanged(const QString &lexiconName);
	void boardChanged(const QString &boardName);
	void vowelFirstChanged(bool vowelFirst);
	void verboseLabelsChanged(bool verboseLabels);
	void scoreLabelsChanged(bool scoreLabels);

	void addBoard();
	void editBoard();
	void deleteBoard();
	
	void setQuackleToUseLexiconName(const string &lexiconName);
	void setQuackleToUseBoardName(const QString &lexiconName);

protected:
	QComboBox *m_lexiconNameCombo;
	QComboBox *m_boardNameCombo;
	QCheckBox *m_vowelFirstCheck;
	QCheckBox *m_verboseLabelsCheck;
	QCheckBox *m_scoreLabelsCheck;
	QPushButton *m_addBoard;
	QPushButton *m_editBoard;
	QPushButton *m_deleteBoard;

	bool m_vowelFirst;
	bool m_verboseLabels;
	bool m_scoreLabels;

private:
	// populate the popup based on what's in QSettings
	void loadBoardNameCombo();
	
	static Settings *m_self;
};

inline bool Settings::vowelFirst() const
{
	return m_vowelFirst;
}

inline bool Settings::verboseLabels() const
{
	return m_verboseLabels;
}

inline bool Settings::scoreLabels() const
{
	return m_scoreLabels;
}

#endif

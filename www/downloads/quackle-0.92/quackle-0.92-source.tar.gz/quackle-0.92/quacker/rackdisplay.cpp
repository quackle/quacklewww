/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <iostream>

#include <QtGui>

#include <game.h>
#include <quackleio/util.h>

#include "quacker.h"
#include "rackdisplay.h"

QuickEntryRack::QuickEntryRack(QWidget *parent)
	: View(parent)
{
	QHBoxLayout *layout = new QHBoxLayout(this);

	m_lineEdit = new QLineEdit(this);
	connect(m_lineEdit, SIGNAL(returnPressed()), this, SLOT(quickEditReturnPressed()));

	QPushButton *setButton = new QPushButton(tr("Set rack"));
	connect(setButton, SIGNAL(clicked()), this, SLOT(quickEditReturnPressed()));

	QPushButton *shuffleButton = new QPushButton(tr("Shu&ffle"));
	connect(shuffleButton, SIGNAL(clicked()), this, SLOT(shuffle()));

	m_label = new QLabel(tr("&Rack"), this);
	m_label->setBuddy(m_lineEdit);
	layout->addWidget(m_label);
	layout->addWidget(m_lineEdit);
	layout->addWidget(setButton);
	layout->addWidget(shuffleButton);
}

QuickEntryRack::~QuickEntryRack()
{
}

void QuickEntryRack::positionChanged(const Quackle::GamePosition &position)
{
	m_lineEdit->setText(convertText(QuackleIO::Util::letterStringToQString(position.currentPlayer().rack().tiles())));
	m_label->setText(QString("%1's &rack:").arg(QuackleIO::Util::uvStringToQString(position.currentPlayer().name())));
}

void QuickEntryRack::grabFocus()
{
	m_lineEdit->setFocus();

	// this should sometimes get called, gotta figure out when
	//m_lineEdit->selectAll();
}

void QuickEntryRack::tileFontChanged(const QFont &font)
{
	m_lineEdit->setFont(font);
}

QString QuickEntryRack::convertText(const QString &original)
{
	return original.toUpper().replace('.', "?");
}

void QuickEntryRack::quickEditReturnPressed()
{
	QString text(m_lineEdit->text());
	m_lineEdit->clear();
	processRack(text);
}

void QuickEntryRack::processRack(const QString &rack)
{
	if (rack.isEmpty())
	{
		emit statusMessage(tr("Useless rack."));
		return;
	}
	
	emit setRack(Quackle::Rack(QuackleIO::Util::encode(convertText(rack))));
}

void QuickEntryRack::shuffle()
{
	Quackle::Rack rack(QuackleIO::Util::encode(convertText(m_lineEdit->text())));
	rack.shuffle();

	emit setRack(rack);
}


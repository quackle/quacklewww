/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <algorithm>
#include <iostream>

using namespace std;

#include <QtGui>

#include <game.h>
#include <boardparameters.h>
#include <strategyparameters.h>
#include <strongplayer.h>
#include <gameparameters.h>
#include <quackleio/util.h>
#include <quackleio/logania.h>
#include <quackleio/queenie.h>

#include "brb.h"
#include "dashboard.h"
#include "history.h"
#include "lister.h"
#include "lexiconparameters.h"
#include "movebox.h"
#include "newgame.h"
#include "quacker.h"
#include "settings.h"
#include "simviewer.h"
#include "widgetfactory.h"
#include "view.h"

TopLevel::TopLevel(QWidget *parent)
	: QMainWindow(parent), m_listerDialog(0), m_simViewer(0), m_plies(2), m_logania(0), m_modified(false)
{
	QCoreApplication::setOrganizationName("Quackle.org");
	QCoreApplication::setOrganizationDomain("quackle.org");
	QCoreApplication::setApplicationName("Quackle");

	setAttribute(Qt::WA_DeleteOnClose);

	m_settings = new Settings;
	m_settings->initialize();
	connect(m_settings, SIGNAL(refreshViews()), this, SLOT(updateAllViews()));
	
	m_game = new Quackle::Game;
	m_simulator = new Quackle::Simulator;

	createWidgets();
	createMenu();

	loadSettings();

	statusMessage(tr("Initializing..."));
	setCaption(tr("Welcome"));

	QTimer::singleShot(0, this, SLOT(finishInitialization()));
}

TopLevel::~TopLevel()
{
	saveSettings();
	QuackleIO::Queenie::cleanUp();
	delete m_game;
	delete m_simulator;
}

void TopLevel::closeEvent(QCloseEvent *closeEvent)
{
	pause(true);

	if (m_modified)
	{
		switch (askToSave())
		{
		case 0:
			qApp->processEvents();
			save();

			// fall through

		case 1:
			closeEvent->accept();
			break;

		case 2:
			closeEvent->ignore();
		}
	}
	else
		closeEvent->accept();
}

void TopLevel::finishInitialization()
{
	// make sure we have generator prepared
	m_dataManager.generator();

	m_timer = new QTimer(this);
	connect(m_timer, SIGNAL(timeout()), this, SLOT(timeout()));
	m_simulationTimer = new QTimer(this);
	connect(m_simulationTimer, SIGNAL(timeout()), this, SLOT(incrementSimulation()));
	
	// shall we initialize game when we load the application?
	// we should but I don't know a good way
	//initializeGame();

	statusMessage(tr("Enjoy your quackling. Choose \"New game...\" from the Game menu to begin."));

	if (!CustomQSettings().contains("quackle/hasBeenRun"))
		firstTimeRun();
}

void TopLevel::commit()
{
	if (!m_game->hasPositions())
		return;

	if (m_game->candidate().isAMove())
	{
		// stop simulation if it's going
		simulate(false);

		m_game->commitCandidate();

		advanceGame();
	}
	else
	{
		statusMessage(tr("No move specified."));
	}
}

void TopLevel::statusMessage(const QString &message)
{
	statusBar()->showMessage(message);
}

bool TopLevel::askToCarryOn(const QString &text)
{
	return QMessageBox::question(this, tr("Verify Play - Quackle"), text, QMessageBox::Yes, QMessageBox::No) == QMessageBox::Yes;
}

void TopLevel::setCandidateMove(const Quackle::Move &move)
{
	if (!m_game->hasPositions() || (move.action == Quackle::Move::Place && move.tiles().empty()))
		return;

	Quackle::Move prettiedMove(move);
	m_game->currentPosition().ensureMoveTilesDoNotIncludePlayThru(prettiedMove);
	m_game->currentPosition().ensureMovePrettiness(prettiedMove);

	if (m_game->currentPosition().moves().contains(prettiedMove))
		m_game->setCandidate(m_game->currentPosition().scoreMove(prettiedMove));
	else
	{
		int validityFlags = m_game->currentPosition().validateMove(prettiedMove);
		bool carryOn = true;

		while (carryOn && validityFlags != Quackle::GamePosition::ValidMove)
		{
			if (validityFlags & Quackle::GamePosition::TooLateExchange)
			{
				carryOn = askToCarryOn(tr("Bag must contain at least %1 tiles for an exchange.").arg(Quackle::DataManager::self()->parameters()->minimumTilesForExchange()));
				validityFlags ^= Quackle::GamePosition::TooLateExchange;
				continue;
			}

			if (validityFlags & Quackle::GamePosition::InvalidTiles)
			{
				carryOn = askToCarryOn(tr("%1's rack does not include all tiles in %2; make play anyway?").arg(QuackleIO::Util::uvStringToQString(m_game->currentPosition().currentPlayer().name())).arg(QuackleIO::Util::moveToDetailedString(prettiedMove)));
				validityFlags ^= Quackle::GamePosition::InvalidTiles;
				continue;
			}

			if (validityFlags & Quackle::GamePosition::InvalidPlace)
			{
				carryOn = askToCarryOn(tr("%1 does not connect to other plays on board; make play anyway?").arg(QuackleIO::Util::moveToDetailedString(prettiedMove)));
				validityFlags ^= Quackle::GamePosition::InvalidPlace;
				continue;
			}

			if (validityFlags & Quackle::GamePosition::InvalidOpeningPlace)
			{
				carryOn = askToCarryOn(tr("Opening play %1 does not cover the star; make play anyway?").arg(QuackleIO::Util::moveToDetailedString(prettiedMove)));
				validityFlags ^= Quackle::GamePosition::InvalidOpeningPlace;
				continue;
			}

			if (validityFlags & Quackle::GamePosition::UnacceptableWord)
			{
				carryOn = askToCarryOn(tr("%1 forms an unacceptable word; make play anyway?").arg(QuackleIO::Util::moveToDetailedString(prettiedMove)));

				if (carryOn)
				{
					if (QMessageBox::question(this, tr("Challenge Decision - Quackle"), tr("If committed, should %1 be challenged off the board?").arg(QuackleIO::Util::moveToDetailedString(prettiedMove)), QMessageBox::Yes, QMessageBox::No) == QMessageBox::Yes)
					{
						prettiedMove.setIsChallengedPhoney(true);
					}
				}

				validityFlags ^= Quackle::GamePosition::UnacceptableWord;
				continue;
			}

			if (validityFlags & Quackle::GamePosition::InvalidAction)
			{
				statusMessage(tr("Urps."));
				carryOn = false;
				continue;
			}
		}

		if (!carryOn)
			return;

		m_game->currentPosition().addAndSetMoveMade(m_game->currentPosition().scoreMove(prettiedMove));
		switchToTab(ChoicesTabIndex);
		ensureUpToDateSimulatorMoveList();
	}

	updatePositionViews();

	// this duplicates the job of updateMoveViews as it also does
	// a check if we have simulation results -- but we don't want to send out
	// a moves changed signal if we don't have results because
	// we just sent out a position changed signal
	if (m_simulator->hasSimulationResults())
		updateMoveViews();
}

void TopLevel::removeCandidateMoves(const Quackle::MoveList &moves)
{
	if (!m_game->hasPositions())
		return;

	const Quackle::MoveList::const_iterator end(moves.end());
	for (Quackle::MoveList::const_iterator it = moves.begin(); it != end; ++it)
		m_game->currentPosition().removeMove(*it);

	ensureUpToDateSimulatorMoveList();
	updateMoveViews();
}

void TopLevel::setRack(const Quackle::Rack &rack)
{
	if (!m_game->hasPositions())
		return;
	
	Quackle::Rack rackToSet = rack;

	if (m_game->currentPosition().currentPlayer().rack().tiles() == rack.tiles())
	{
		QMessageBox::information(this, tr("Setting the Rack - Quackle"), QString("<html>") + tr("The current player's rack is already %1. To change the current player's rack, type the letters into the rack editor, then press the Enter key or click \"Set rack\".").arg(QuackleIO::Util::letterStringToQString(rack.tiles())) + "</html>");
	}

	if (!m_game->currentPosition().canSetCurrentPlayerRackWithoutBagExpansion(rack))
	{
		if (!askToCarryOn(tr("The rack %1 contains letters that are not available without modifying the tile distribution; do you wish to expand the bag to allow this?").arg(QuackleIO::Util::letterStringToQString(rack.tiles()))))
		{
			rackToSet = m_game->currentPosition().currentPlayer().rack();
		}
	}

	m_game->currentPosition().setCurrentPlayerRack(rackToSet);
	m_simulator->currentPosition().setCurrentPlayerRack(rackToSet);
	updatePositionViews();

	statusMessage(tr("%1's rack set to %2").arg(QuackleIO::Util::uvStringToQString(m_game->currentPosition().currentPlayer().name())).arg(QuackleIO::Util::letterStringToQString(rackToSet.tiles())));
}

void TopLevel::goToHistoryLocation(const Quackle::HistoryLocation &location)
{
	if (!m_game->hasPositions())
		return;

	// stop simulation if it's going
	simulate(false);

	m_game->setCurrentPosition(location);
	itIsNowHumanTurn();
}

void TopLevel::updateAllViews()
{
	if (!m_game->hasPositions())
		return;

	updateHistoryViews();
	updatePositionViews();
	updateSimViews();

	m_game->currentPosition().ensureBoardIsPreparedForAnalysis();
}

void TopLevel::updatePositionViews()
{
	emit positionChanged(m_game->currentPosition());

	m_simulateAction->setEnabled(!m_game->currentPosition().moves().empty());
	m_simulateDetailsAction->setEnabled(!m_game->currentPosition().moves().empty());
	m_simulateClearAction->setEnabled(!m_game->currentPosition().moves().empty());
	m_kibitzAction->setEnabled(!m_game->currentPosition().gameOver());
	m_kibitzFiftyAction->setEnabled(!m_game->currentPosition().gameOver());
	m_kibitzAllAction->setEnabled(!m_game->currentPosition().gameOver());
	m_commitTopChoiceAction->setEnabled(!m_game->currentPosition().gameOver());

	const bool isAMove = m_game->currentPosition().moveMade().isAMove();
	m_commitAction->setEnabled(!m_game->currentPosition().gameOver() && isAMove);

	const QString assistiveText = tr("Click once or twice on the board, type, then press the Enter key.");

	if (isAMove)
		statusMessage(tr("Press a Commit button to play %1.").arg(QuackleIO::Util::moveToDetailedString(m_game->currentPosition().moveMade())));
	else if (m_game->currentPosition().currentPlayer().drawnLetters().empty())
		statusMessage(tr("%1 to play. %2").arg(QuackleIO::Util::uvStringToQString(m_game->currentPosition().currentPlayer().name())).arg(assistiveText));
	else
		statusMessage(tr("%1 to play after drawing %2. %3").arg(QuackleIO::Util::uvStringToQString(m_game->currentPosition().currentPlayer().name())).arg(QuackleIO::Util::letterStringToQString(m_game->currentPosition().currentPlayer().drawnLetters().tiles())).arg(assistiveText));

	updateListerDialogWithRack();
}

void TopLevel::updateMoveViews()
{
	if (m_simulator->hasSimulationResults())
		emit movesChanged(m_simulator->moves(/* prune */ true));
	else
		emit movesChanged(m_game->currentPosition().moves());

	m_simulateAction->setEnabled(!m_game->currentPosition().moves().empty());
	m_simulateDetailsAction->setEnabled(!m_game->currentPosition().moves().empty());
	m_simulateClearAction->setEnabled(!m_game->currentPosition().moves().empty());
}

void TopLevel::updateHistoryViews()
{
	emit historyChanged(m_game->history());
}

void TopLevel::initializeGame(const Quackle::PlayerList &players)
{
	m_game->reset();
	m_filename = QString();
	m_logania = 0;

	if (players.empty())
		return;

	Quackle::PlayerList newPlayers(players);

	// shuffle so same person doesn't go first twice in a row,
	// if there are multiple players in the game
	if (newPlayers.size() > 1)
	{
		UVString prevFirst = m_firstPlayerName;
		while (m_firstPlayerName == prevFirst || m_firstPlayerName.empty())
		{
			random_shuffle(newPlayers.begin(), newPlayers.end());
			m_firstPlayerName = newPlayers.front().name();
		}
	}

	m_game->setPlayers(newPlayers);
	m_game->associateKnownComputerPlayers();

	m_game->addPosition();
	
	advanceGame();

	setCaption(gameTitle());

	const bool debugEndgame = false;
	if (debugEndgame)
	{
		for (int i = 0; i < 20; ++i)
			m_game->haveComputerPlay();
		advanceGame();
	}
}

void TopLevel::open()
{
	pause(true);

	if (m_modified)
	{
		switch (askToSave())
		{
		case 0:
			save();

		case 1:
			break;

		case 2:
			return;
		}
	}
	
	// QString getOpenFileName ( QWidget * parent = 0, const QString & caption = QString(), const QString & dir = QString(), const QString & filter = QString(), QString * selectedFilter = 0, Options options = 0 )
	QString filename = QFileDialog::getOpenFileName(this, tr("Choose game file to open"), QString(), tr("Game files (%1)").arg(QuackleIO::Queenie::self()->filters().join(" ")));

	if (!filename.isEmpty())
	{
		m_filename = filename;
		loadFile(m_filename);
		saveSettings();
	}
}

void TopLevel::newGame()
{
	if (!setupCheck())
		return;
	
	pause(true);

	if (m_modified)
	{
		switch (askToSave())
		{
		case 0:
			save();

		case 1:
			break;

		case 2:
			return;
		}
	}
	
	NewGameDialog newGameDialog(this);
	switch (newGameDialog.exec())
	{
	case QDialog::Accepted:
		initializeGame(newGameDialog.players());
		break;

	case QDialog::Rejected:
		break;
	}
}

void TopLevel::setCaption(const QString &text)
{
	if (!text.isNull())
		m_ourCaption = text;

	setWindowTitle(QString("%1[*] - Quackle").arg(m_ourCaption));
}

void TopLevel::setModified(bool modified)
{
	m_modified = modified;
	setWindowModified(m_modified);
}

bool TopLevel::setupCheck()
{
	bool okay = QUACKLE_DATAMANAGER->isGood();

	if (!okay)
	{
		QMessageBox::warning(this, tr("Not Ready - Quackle"), tr("Quackle cannot load its data files, including lexica. You'll need more mojo."));
	}

	return okay;
}

void TopLevel::plugIntoBaseMatrix(BaseView *view)
{
	connect(view, SIGNAL(statusMessage(const QString &)), this, SLOT(statusMessage(const QString &)));
}

void TopLevel::plugIntoMatrix(View *view)
{
	plugIntoBaseMatrix(view);

	connect(view, SIGNAL(setCandidateMove(const Quackle::Move &)), this, SLOT(setCandidateMove(const Quackle::Move &)));
	connect(view, SIGNAL(removeCandidateMoves(const Quackle::MoveList &)), this, SLOT(removeCandidateMoves(const Quackle::MoveList &)));
	connect(view, SIGNAL(commit()), this, SLOT(commit()));
	connect(view, SIGNAL(setRack(const Quackle::Rack &)), this, SLOT(setRack(const Quackle::Rack &)));
}

void TopLevel::plugIntoPositionMatrix(View *view)
{
	connect(this, SIGNAL(positionChanged(const Quackle::GamePosition &)), view, SLOT(positionChanged(const Quackle::GamePosition &)));
}

void TopLevel::plugIntoMoveMatrix(View *view)
{
	connect(this, SIGNAL(movesChanged(const Quackle::MoveList &)), view, SLOT(movesChanged(const Quackle::MoveList &)));
}

void TopLevel::plugIntoHistoryMatrix(HistoryView *view)
{
	plugIntoBaseMatrix(view);

	connect(view, SIGNAL(goToHistoryLocation(const Quackle::HistoryLocation &)), this, SLOT(goToHistoryLocation(const Quackle::HistoryLocation &)));

	connect(this, SIGNAL(historyChanged(const Quackle::History &)), view, SLOT(historyChanged(const Quackle::History &)));
}

int TopLevel::askToSave()
{
	return QMessageBox::warning(this, tr("Unsaved Results - Quackle"), tr("There are unsaved results in the current game. Save them?"), tr("&Save"), tr("&Discard"), tr("&Cancel"), 0, 2);
}

void TopLevel::generateList()
{
	if (!setupCheck())
		return;
	
	pause(true);

	if (m_listerDialog)
	{
		m_listerDialog->show();
		m_listerDialog->raise();
	}
	else
	{
		m_listerDialog = new ListerDialog(this, &m_querier, "quackle", tr("Quackle"), ListerDialog::IgnoreBritishness | ListerDialog::ProbabilityInsteadOfPlayability | ListerDialog::NothingToReturn);
		m_listerDialog->show();
	}

	updateListerDialogWithRack();
}

void TopLevel::updateListerDialogWithRack()
{
	if (m_listerDialog && m_game->hasPositions())
		m_listerDialog->setQuery(QuackleIO::Util::letterStringToQString(m_game->currentPosition().currentPlayer().rack().tiles()));
}

void TopLevel::kibitz()
{
	if (!m_game->hasPositions())
		return;

	const int extraPlaysToKibitz = 10;

	const bool confuseUser = false;

	if (confuseUser)
	{
		const int currentlyKibitzed = m_game->currentPosition().moves().size();
		kibitz(currentlyKibitzed < extraPlaysToKibitz? extraPlaysToKibitz : currentlyKibitzed + extraPlaysToKibitz);
	}
	else
	{
		kibitz(extraPlaysToKibitz);
	}
}

void TopLevel::kibitz(int numberOfPlays)
{
	if (!m_game->hasPositions())
		return;

	m_game->currentPosition().kibitz(numberOfPlays);

	updatePositionViews();
	ensureUpToDateSimulatorMoveList();

	switchToTab(ChoicesTabIndex);
}

void TopLevel::kibitzFifty()
{
	kibitz(50);
}

void TopLevel::kibitzAll()
{
	kibitz(INT_MAX);
}

void TopLevel::commitTopChoice()
{
	if (!m_game->hasPositions())
		return;

	m_game->currentPosition().kibitz(1);
	m_game->setCandidate(m_game->currentPosition().moves().back());
	commit();
}

void TopLevel::ensureUpToDateSimulatorMoveList()
{
	m_simulator->setIncludedMoves(m_game->currentPosition().moves());
}

void TopLevel::simulate(bool startSimulation)
{
	m_simulateAction->setChecked(startSimulation);

	// it's not so useful to have sim control show/hide
	// like this
	//m_simulatorWidget->setVisible(startSimulation);

	if (startSimulation)
	{
		logfileChanged();
		incrementSimulation();
	}
	else
		m_simulationTimer->stop();
}

void TopLevel::simulateToggled(bool startSimulation)
{
	if (!m_game->hasPositions())
		return;

	simulate(startSimulation);

	if (startSimulation)
	{
		switchToTab(ChoicesTabIndex);
		statusMessage(tr("Starting simulation. To stop the simulation, uncheck the \"Simulate\" menu entry in the Move menu."));
	}
}

void TopLevel::clearSimulationResults()
{
	if (!m_game->hasPositions())
		return;

	m_simulator->resetNumbers();

	updateMoveViews();
	updateSimViews();
}

void TopLevel::timeout()
{
	UVcout << "toplevel::timeout" << endl;
}

void TopLevel::pliesSet(const QString &plyString)
{
	if (plyString == tr("Many"))
		m_plies = -1;
	else
		m_plies = plyString.toInt();
}

void TopLevel::ignoreOpposChanged()
{
	m_simulator->setIgnoreOppos(m_ignoreOpposCheck->isChecked());
}

void TopLevel::updatePliesCombo()
{
	int index;

	if (m_plies == -1)
		index = m_pliesToOffer;
	else
		index = m_plies - 1;

	m_pliesCombo->setCurrentIndex(index);
}

void TopLevel::logfileEnabled(bool on)
{
	setLogfileEnabled(on);
}

void TopLevel::setLogfileEnabled(bool /* enabled */)
{
	// not needed with QGroupBox
	//m_logfileChooser->setEnabled(enabled);
	//m_logfileEdit->setEnabled(enabled);

	logfileChanged();
}

bool TopLevel::isLogfileEnabled() const
{
	return m_logfileEnable->isChecked();
}

QString TopLevel::userSpecifiedLogfile() const
{
	return m_logfileEdit->text();
}

QString TopLevel::logfile() const
{
	return isLogfileEnabled()? userSpecifiedLogfile() : QString("");
}

void TopLevel::logfileChanged()
{
	m_simulator->setLogfile(QuackleIO::Util::qstringToStdString(logfile()), /* append */ true);
}

void TopLevel::chooseLogfile()
{
	QString filename;

	QFileDialog *fileDialog = new QFileDialog(this, tr("Choose log file"));

	fileDialog->setDirectory(userSpecifiedLogfile().isEmpty()? QDir::currentPath() : QFileInfo(userSpecifiedLogfile()).absolutePath());
	fileDialog->setFileMode(QFileDialog::AnyFile);
	fileDialog->setConfirmOverwrite(false);

	if (fileDialog->exec())
	{
		QStringList files(fileDialog->selectedFiles());
		if (!files.empty())
			filename = files.back();
	}

	if (filename.isEmpty())
		return;

	m_logfileEdit->setText(filename);
	logfileChanged();
}

void TopLevel::showSimulationDetails()
{
	if (!m_simViewer)
		m_simViewer = new SimViewer(this);

	m_simViewer->setSimulator(*m_simulator);
	m_simViewer->show();

	updateSimViews();
}

void TopLevel::incrementSimulation()
{
	if (m_simulateAction->isChecked())
	{
		m_simulator->simulate(m_plies);
		m_simulationTimer->start(0);

		if (m_simulator->iterations() % 10 == 0)
			updateMoveViews();

		updateSimViews();
	}
}

void TopLevel::updateSimViews()
{
	m_simulatorWidget->setTitle(m_simulator->hasSimulationResults()? tr("Simulation: %2 iterations").arg(m_simulator->iterations()) : tr("Simulation"));

	if (m_simViewer && m_simViewer->isVisible())
		m_simViewer->setSimulator(*m_simulator);
}

void TopLevel::loadFile(const QString &filename)
{
	if (filename.isEmpty())
		return;

	QString strippedFilename(filename.right(filename.length() - filename.lastIndexOf("/") - 1));
	statusMessage(tr("Loading %1...").arg(strippedFilename));
	qApp->processEvents();

	QFile file(filename);
	if (!file.exists())
	{
		QMessageBox::critical(this, tr("Error Loading Game File - Quackle"), tr("Filename %1 does not exist.").arg(filename));
		return;
	}

	if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
	{
		QMessageBox::critical(this, tr("Error Loading Game File - Quackle"), tr("%1 cannot be opened.").arg(filename));
		return;
	}

	QuackleIO::Logania *logania = QuackleIO::Queenie::self()->loganiaForFile(filename);
	if (logania == 0)
	{
		QMessageBox::critical(this, tr("Error Loading Game File - Quackle"), tr("Sorry, %1 is in a format Quackle cannot read.").arg(filename));
		file.close();
		return;
	}

	QTextStream stream(&file);
	m_game = logania->read(stream, QuackleIO::Logania::MaintainBoardPreparation);

	file.close();

	m_logania = logania;

	setModified(false);
	statusMessage(tr("Loaded game from `%1'.").arg(filename));

	itIsNowHumanTurn();
}

void TopLevel::save()
{
	if (m_filename.isEmpty())
	{
		saveAs();
		return;
	}

	writeFile(m_filename);
}

void TopLevel::saveAs()
{
	QString filename = QFileDialog::getSaveFileName(this, tr("Choose file to save game to"), m_filename);

	if (!filename.isEmpty())
	{
		m_filename = filename;
		writeFile(m_filename);
		saveSettings();
	}
}

void TopLevel::writeFile(const QString &filename)
{
	if (!m_game->hasPositions())
		return;
	
	QFile file(filename);
	 
	if (!file.open(QIODevice::WriteOnly | QIODevice::Text))    
	{        
		QMessageBox::critical(0, tr("Error Writing File - Quacker"), tr("Could not open %1 for writing.").arg(filename));        
		return;    
	}    

	QTextStream stream(&file);

	QuackleIO::Logania *logania = m_logania? m_logania : QuackleIO::Queenie::self()->defaultLogania();

	if (logania == 0)
	{
		file.close();
		return;
	}

	logania->write(*m_game, stream);

	file.close();

	setModified(false);
	statusMessage(tr("Saved game to `%1'.").arg(filename));
}

void TopLevel::pause(bool paused)
{
	timerControl(paused);

	if (m_pauseAction->isChecked() != paused)
		m_pauseAction->setChecked(paused);

	if (!paused)
	{
		// set focus to widget that should have focus
		m_brb->grabFocus();
	}

/*
	if (paused)
		statusMessage(tr("Paused."));
	else
		statusMessage(tr("Resuming..."));
		*/
}

void TopLevel::advanceGame()
{
	if (m_game->currentPosition().currentPlayer().type() == Quackle::Player::ComputerPlayer)
		m_game->haveComputerPlay();

	itIsNowHumanTurn();

	if (!m_game->currentPosition().gameOver() && m_game->currentPosition().currentPlayer().type() == Quackle::Player::ComputerPlayer)
	{
		QTimer::singleShot(0, this, SLOT(advanceGame()));
		return;
	}
}

void TopLevel::itIsNowHumanTurn()
{
	Quackle::Rack rack(m_game->currentPosition().currentPlayer().rack());
	rack.setTiles(QuackleIO::Util::encode(QuackleIO::Util::arrangeLettersForUser(rack, Settings::self()->vowelFirst())));
	m_game->currentPosition().setCurrentPlayerRack(rack);

	m_simulator->setPosition(m_game->currentPosition());

	updateHistoryViews();
	updatePositionViews();

	ensureUpToDateSimulatorMoveList();
	updateSimViews();

	if (m_game->currentPosition().gameOver())
	{
		pause(true);

		statusMessage(tr("Game over. Double-click an entry in the History table to perform postmortem."));
	}
	else
	{
		pause(false);
	}

	m_showAsciiAction->setEnabled(true);
	m_saveAction->setEnabled(true);
	m_saveAsAction->setEnabled(true);

	switchToTab(HistoryTabIndex);
	m_brb->grabFocus();

	// DEBUG RACKS AND BAG
	//UVcout << m_game->currentPosition();
}

void TopLevel::timerControl(bool paused)
{
	if (paused)
		m_timer->stop();
	else
	{
		// start timer
		// eg m_timer->start(timerLength(), /* single shot */ true);
		// except we'll want a non-single-shot job
	}
}

QString TopLevel::gameTitle()
{
	QString ret;
	const Quackle::PlayerList &players(m_game->players());

	if (players.size() == 0)
		ret = tr("No Game");
	else if (players.size() == 1)
		ret = tr("%1's solo game").arg(QuackleIO::Util::uvStringToQString(players.front().name()));
	else if (players.size() == 2)
		ret = tr("%1 versus %2").arg(QuackleIO::Util::uvStringToQString(players.front().name())).arg(QuackleIO::Util::uvStringToQString(players.at(1).name()));
	else if (players.size() > 2)
		ret = tr("Game between %1 and friends").arg(QuackleIO::Util::uvStringToQString(players.front().name()));

	return ret;
}

void TopLevel::createMenu()
{
	const bool enableCommitAction = true;
	const bool putCommitActionOnToolbar = false;

	//// Game menu
	
	QAction *newAction = new QAction(tr("&New game..."), this);
	newAction->setShortcut(tr("Ctrl+N"));
	connect(newAction, SIGNAL(triggered()), this, SLOT(newGame()));

	QAction *openAction = new QAction(tr("&Open..."), this);
	openAction->setShortcut(tr("Ctrl+O"));
	connect(openAction, SIGNAL(triggered()), this, SLOT(open()));

	m_saveAction = new QAction(tr("&Save"), this);
	m_saveAction->setEnabled(false);
	m_saveAction->setShortcut(tr("Ctrl+S"));
	connect(m_saveAction, SIGNAL(triggered()), this, SLOT(save()));

	m_saveAsAction = new QAction(tr("Save &as..."), this);
	m_saveAsAction->setEnabled(false);
	connect(m_saveAsAction, SIGNAL(triggered()), this, SLOT(saveAs()));

	QAction *generateAction = new QAction(tr("Generate word &list..."), this);
	generateAction->setShortcut(tr("Ctrl+L"));
	connect(generateAction, SIGNAL(triggered()), this, SLOT(generateList()));

	QAction *printAction = new QAction(tr("&Print..."), this);
	connect(printAction, SIGNAL(triggered()), this, SLOT(print()));

	m_showAsciiAction = new QAction(tr("&Show plaintext board"), this);
	m_showAsciiAction->setEnabled(false);
	connect(m_showAsciiAction, SIGNAL(triggered()), this, SLOT(showAscii()));

	m_pauseAction = new QAction(tr("Pa&use"), this);
	m_pauseAction->setShortcut(tr("Ctrl+P"));
	m_pauseAction->setCheckable(true);
	connect(m_pauseAction, SIGNAL(toggled(bool)), this, SLOT(pause(bool)));

	QAction *quitAction = new QAction(tr("&Quit"), this);
	quitAction->setShortcut(tr("Ctrl+Q"));
	connect(quitAction, SIGNAL(triggered()), this, SLOT(close()));

	//// Move

	m_kibitzAction = new QAction(tr("&Generate choices"), this);
	m_kibitzAction->setShortcut(tr("Ctrl+G"));
	m_kibitzAction->setEnabled(false);
	connect(m_kibitzAction, SIGNAL(triggered()), this, SLOT(kibitz()));

	m_commitAction = new QAction(tr("Comm&it"), this);
	m_commitAction->setShortcut(tr("Ctrl+I"));
	m_commitAction->setEnabled(false);
	connect(m_commitAction, SIGNAL(triggered()), this, SLOT(commit()));

	m_commitTopChoiceAction = new QAction(tr("&Commit top statically-evaluated choice"), this);
	m_commitTopChoiceAction->setShortcut(tr("Ctrl+T"));
	m_commitTopChoiceAction->setEnabled(false);
	connect(m_commitTopChoiceAction, SIGNAL(triggered()), this, SLOT(commitTopChoice()));

	m_kibitzFiftyAction = new QAction(tr("Generate 50 choices"), this);
	m_kibitzFiftyAction->setEnabled(false);
	connect(m_kibitzFiftyAction, SIGNAL(triggered()), this, SLOT(kibitzFifty()));

	m_kibitzAllAction = new QAction(tr("Generate &all choices"), this);
	m_kibitzAllAction->setEnabled(false);
	connect(m_kibitzAllAction, SIGNAL(triggered()), this, SLOT(kibitzAll()));

	m_simulateAction = new QAction(tr("Start/Stop &Simulation"), this);
	m_simulateAction->setShortcut(tr("Ctrl+A"));
	m_simulateAction->setCheckable(true);
	m_simulateAction->setEnabled(false);
	connect(m_simulateAction, SIGNAL(toggled(bool)), this, SLOT(simulateToggled(bool)));

	m_simulateDetailsAction = new QAction(tr("Show simulation &details"), this);
	m_simulateDetailsAction->setEnabled(false);
	connect(m_simulateDetailsAction, SIGNAL(triggered()), this, SLOT(showSimulationDetails()));

	m_simulateClearAction = new QAction(tr("Clear simulation results"), this);
	m_simulateClearAction->setEnabled(false);
	connect(m_simulateClearAction, SIGNAL(triggered()), this, SLOT(clearSimulationResults()));

	//// Help

	QAction *hintsAction = new QAction(tr("&Helpful Hints"), this);
	connect(hintsAction, SIGNAL(triggered()), this, SLOT(hints()));

	QAction *aboutAction = new QAction(tr("&About Quackle"), this);
	connect(aboutAction, SIGNAL(triggered()), this, SLOT(about()));

	QAction *aboutQtAction = new QAction(tr("About &Qt"), this);
	connect(aboutQtAction, SIGNAL(triggered()), qApp, SLOT(aboutQt()));

	////

	QMenu *game = menuBar()->addMenu(tr("&Game"));

	game->addAction(newAction);
	game->addAction(openAction);
	game->addSeparator();
	game->addAction(m_saveAction);
	game->addAction(m_saveAsAction);
	game->addSeparator();
	game->addAction(generateAction);
	//game->addAction(m_pauseAction);
	//game->addSeparator();
	game->addAction(m_showAsciiAction);
	//game->addAction(printAction);
	game->addSeparator();
	game->addAction(quitAction);

	QMenu *move = menuBar()->addMenu(tr("&Move"));

	move->addAction(m_kibitzAction);
	move->addAction(m_kibitzFiftyAction);
	move->addAction(m_kibitzAllAction);

	move->addSeparator();
	if (enableCommitAction)
		move->addAction(m_commitAction);
	move->addAction(m_commitTopChoiceAction);
	move->addSeparator();

	move->addAction(m_simulateAction);
	move->addAction(m_simulateDetailsAction);
	move->addAction(m_simulateClearAction);

	//QMenu *settings = menuBar()->addMenu(tr("&Settings"));

	menuBar()->addSeparator();

	QMenu *help = menuBar()->addMenu(tr("&Help"));
	help->addAction(hintsAction);
	help->addAction(aboutAction);
	help->addAction(aboutQtAction);

	// file toolbar
	QToolBar *fileBar = addToolBar(tr("File"));
	fileBar->addAction(newAction);
	fileBar->addAction(generateAction);

	// move toolbar
	QToolBar *moveBar = addToolBar(tr("Move"));

	if (enableCommitAction && putCommitActionOnToolbar)
	{
		moveBar->addAction(m_commitAction);
		moveBar->addSeparator();
	}

	moveBar->addAction(m_kibitzAction);
	moveBar->addAction(m_simulateAction);
}

void TopLevel::createWidgets()
{
	m_splitter = new QSplitter(Qt::Horizontal, this);

	setCentralWidget(m_splitter);

	QWidget *leftSide = new QWidget;
	QVBoxLayout *leftSideLayout = new QVBoxLayout(leftSide);

	m_dashboard = new Dashboard;
	plugIntoHistoryMatrix(m_dashboard);

	m_choicesWidget = new QWidget;
	QVBoxLayout *choicesLayout = new QVBoxLayout(m_choicesWidget);

	m_simulatorWidget = new QGroupBox(tr("Simulation"));
	QVBoxLayout *simulatorLayout = new QVBoxLayout(m_simulatorWidget);

	QHBoxLayout *plyLayout = new QHBoxLayout;

	m_pliesCombo = new QComboBox;
	QStringList plyOptions;

	for (int i = 1; i <= m_pliesToOffer; ++i)
		plyOptions.push_back(QString::number(i));

	plyOptions.push_back(tr("Many"));

	m_pliesCombo->addItems(plyOptions);
	connect(m_pliesCombo, SIGNAL(activated(const QString &)), this, SLOT(pliesSet(const QString &)));

	QLabel *plyLabel = new QLabel(tr("p&lies"));
	plyLabel->setBuddy(m_pliesCombo);

	m_ignoreOpposCheck = new QCheckBox(tr("oppos pass"));
	connect(m_ignoreOpposCheck, SIGNAL(stateChanged(int)), this, SLOT(ignoreOpposChanged()));

	m_showDetailsButton = new QPushButton(tr("&Details"));
	connect(m_showDetailsButton, SIGNAL(clicked()), this, SLOT(showSimulationDetails()));

	plyLayout->addWidget(m_pliesCombo);
	plyLayout->addWidget(plyLabel);
	plyLayout->addWidget(m_ignoreOpposCheck);
	plyLayout->addStretch();
	plyLayout->addWidget(m_showDetailsButton);
	simulatorLayout->addLayout(plyLayout);

	m_logfileEnable = new QGroupBox(tr("&Log to file"));
	m_logfileEnable->setCheckable(true);
	m_logfileEnable->setFlat(true);
	connect(m_logfileEnable, SIGNAL(toggled(bool)), this, SLOT(logfileEnabled(bool)));

	QHBoxLayout *logfileLayout = new QHBoxLayout(m_logfileEnable);
	logfileLayout->setMargin(0);

	m_logfileEdit = new QLineEdit;
	connect(m_logfileEdit, SIGNAL(returnPressed()), this, SLOT(logfileChanged()));

	m_logfileChooser = new QPushButton(tr("Browse..."));
	connect(m_logfileChooser, SIGNAL(clicked()), this, SLOT(chooseLogfile()));

	logfileLayout->addWidget(m_logfileEdit);
	logfileLayout->addWidget(m_logfileChooser);
	simulatorLayout->addWidget(m_logfileEnable);

	m_moveBox = new MoveBox;
	plugIntoMatrix(m_moveBox);
	plugIntoPositionMatrix(m_moveBox);
	plugIntoMoveMatrix(m_moveBox);

	choicesLayout->addWidget(m_moveBox);
	choicesLayout->addWidget(m_simulatorWidget);

	m_history = new History;
	plugIntoHistoryMatrix(m_history);

	m_settings->createGUI();

	m_tabWidget = new QTabWidget;
	m_tabWidget->addTab(m_history, tr("Histor&y"));
	m_tabWidget->addTab(m_choicesWidget, tr("Ch&oices"));
	m_tabWidget->addTab(m_settings, tr("&Settings"));

	GraphicalFactory factory;
	m_brb = new BRB(&factory);
	plugIntoMatrix(m_brb);
	plugIntoPositionMatrix(m_brb);

	leftSideLayout->addWidget(m_dashboard);
	leftSideLayout->addWidget(m_tabWidget);

	m_splitter->addWidget(leftSide);
	m_splitter->addWidget(m_brb);

	m_splitter->setStretchFactor(1, 4);
}

void TopLevel::switchToTab(TabIndex index)
{
	m_tabWidget->setCurrentIndex(index);
}

void TopLevel::unimplemented()
{
	QMessageBox::information(this, tr("Sorry - Quackle"), tr("This feature is not implemented. Please bug us about it."));
}

QString TopLevel::playerString() const
{
	QString ret;

	if (!m_game->hasPositions())
		return tr("No game");

	Quackle::PlayerList players = m_game->currentPosition().endgameAdjustedScores();
	if (players.empty())
		return tr("No game");

	bool begin = true;
	int i = 0;
	const int maximumIndex = players.size() - 1;
	const Quackle::PlayerList::const_iterator end(players.end());
	for (Quackle::PlayerList::const_iterator it = players.begin(); it != end; ++it, ++i)
	{
		if (!begin)
			ret += tr(", ");

		if (!begin && i == maximumIndex && i >= 2)
			ret += tr("and ");

		ret += tr("%1 (score %2)").arg(QuackleIO::Util::uvStringToQString((*it).name())).arg((*it).score());
		begin = false;
	}

	return ret;
}

void TopLevel::showAscii()
{
	if (!m_game->hasPositions())
		return;

	QString text;

	text += tr("Players: %1").arg(playerString()) + "\n\n";
	text += QuackleIO::Util::uvStringToQString(m_game->currentPosition().board().toString()) + "\n\n";
	const UVString &unseenTiles = m_game->currentPosition().unseenTiles();
	text += tr("Unseen: %1 (%2)").arg(QuackleIO::Util::arrangeLettersForUser(QuackleIO::Util::uvStringToQString(unseenTiles), Settings::self()->vowelFirst())).arg(m_game->currentPosition().unseenBag().size()) + "\n\n";

	if (m_game->currentPosition().gameOver())
		text += tr("Game over.") + "\n";
	else
		text += tr("%1 to play with %2").arg(QuackleIO::Util::uvStringToQString(m_game->currentPosition().currentPlayer().name())).arg(QuackleIO::Util::letterStringToQString(m_game->currentPosition().currentPlayer().rack().tiles())) + "\n";

	int result = QMessageBox::question(this, tr("Plaintext board - Quackle"), QString("<pre>%1</pre>").arg(text), tr("&Write to file"), tr("Copy to clip&board"), tr("&OK"), 1);

	switch (result)
	{
	case 0:
		writeAsciiToFile(text);
		break;

	case 1:
		copyToClipboard(text);
		break;

	case 2:
		break;
	}
}

void TopLevel::copyToClipboard(const QString &text)
{
	QApplication::clipboard()->setText(text, QClipboard::Clipboard);
	QApplication::clipboard()->setText(text, QClipboard::Selection);

	statusMessage(tr("Copied to clipboard."));
}

void TopLevel::writeAsciiToFile(const QString &text)
{
	QString filename = QFileDialog::getSaveFileName(this, tr("Choose file to print plaintext board to - Quackle"));

	if (filename.isEmpty())
		return;

	QFile file(filename);
	 
	if (!file.open(QIODevice::WriteOnly | QIODevice::Text))    
	{        
		QMessageBox::critical(0, tr("Error Writing File - Quackle"), tr("Could not open %1 for writing.").arg(file.fileName()));        
		return;    
	}

	QTextStream stream(&file);
	stream << text << "\n";

	file.close();

	statusMessage(tr("`%1' written.").arg(filename));
}

void TopLevel::print()
{
	return unimplemented();
	pause(true);

	QString filename = QFileDialog::getSaveFileName(this, tr("Choose file to print to - Quackle"), m_filename + ".html");

	if (filename.isEmpty())
		return;

	QFile file(filename);
	 
	if (!file.open(QIODevice::WriteOnly | QIODevice::Text))    
	{        
		QMessageBox::critical(0, tr("Error Writing File - Quackle"), tr("Could not open %1 for writing.").arg(file.fileName()));        
		return;    
	}

	QTextStream stream(&file);
	//stream << printer.html() << "\n";

	file.close();

	statusMessage(tr("`%1' written.").arg(filename));
}

void TopLevel::firstTimeRun()
{
	switchToTab(SettingsTabIndex);
	QMessageBox::information(this, tr("Welcome - Quackle"), tr("<p>Welcome to Quackle! To get started, configure a board by clicking Add Board in the Settings tab, add some bonus squares, and then start a new game. Also check out the Helpful Hints from the Help menu, and keep your eye out for the aidant messages in the status bar at the bottom of the window.</p>"));
}

void TopLevel::about()
{
	QMessageBox::about(this, tr("About Quackle 0.92"), "<p><b>Quackle</b> 0.92 is a crossword game playing, analysis, and study tool. Visit the Quackle homepage at <tt>http://quackle.org</tt> for more information.</p><p>Quackle was written by Jason Katz-Brown and John O'Laughlin. We'd like to thank the anonymous donor who made this software free, and John Fultz for Windows(tm) and board setup awesomeness.</p><p>Copyright 2005-2006 by<ul><li>Jason Katz-Brown &lt;jasonkb@mit.edu&gt;</li><li>John O'Laughlin &lt;olaughlin@gmail.com&gt;</li></ul><p>Quackle is free, open-source software licensed under the terms of the revised BSD license. See</p><p><tt>http://quackle.org/LICENSE</tt></p>");
}

void TopLevel::hints()
{
	QMessageBox::information(this, tr("Helpful Hints - Quackle"), tr("<ul><li>Press Control-Enter after typing your word on the board to enter and commit your move quickly.</li><li>Double-click at any time during a game on any item in the History table to analyze that position. If you then commit a play, you will restart the game from that point and future plays will be lost.</li><li>To analyze a real-life game, start a two-player game with two human-controlled players. For one player, for each turn set the rack to the rack you had in the game and then analyze the position and commit the play that you made in real life. For the other player, commit your oppo's real-life plays and ignore the warnings about rack contents Quackle gives.</li><li>Stop simulations by unchecking \"Simulate\" in the Move menu. Sims can be stopped and restarted without losing their state, and sims of different plies can be combined. Check out the sim details during a simulation by choosing \"Show simulation details\" from the Move menu!</li></ul><p>Have fun using Quackle. We'd love your help developing it, especially if you can code, but we like suggestions too! Please join the Quackle Yahoo! group at</p><p><tt>http://games.groups.yahoo.com/group/quackle/</tt></p>"));
}

void TopLevel::saveSettings()
{
	CustomQSettings settings;

	settings.setValue("quackle/window-size", size());
	settings.setValue("quackle/splitter-sizes", m_splitter->saveState());
	settings.setValue("quackle/plies", m_plies);
	settings.setValue("quackle/ignoreoppos", m_ignoreOpposCheck->isChecked());
	settings.setValue("quackle/logfileEnabled", isLogfileEnabled());
	settings.setValue("quackle/logfile", userSpecifiedLogfile());

	settings.setValue("quackle/hasBeenRun", true);
}

void TopLevel::loadSettings()
{
	CustomQSettings settings;

	resize(settings.value("quackle/window-size", QSize(800, 600)).toSize());

	if (settings.contains("quackle/splitter-sizes"))
		m_splitter->restoreState(settings.value("quackle/splitter-sizes").toByteArray());

	m_plies = settings.value("quackle/plies", 2).toInt();
	updatePliesCombo();

	m_ignoreOpposCheck->setChecked(settings.value("quackle/ignoreoppos", false).toBool());

	m_logfileEdit->setText(settings.value("quackle/logfile", QString("")).toString());
	const bool logfileEnabled = settings.value("quackle/logfileEnabled", false).toBool();
	m_logfileEnable->setChecked(logfileEnabled);
	setLogfileEnabled(logfileEnabled);
}


/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <vector>
#include <map>

#include "dict.h"

using namespace std;
using namespace Dict;

Extension::Extension()
	: playability(0), probability(0), british(false)
{
}

Word::Word()
	: playability(0), probability(0), british(false)
{
}

//////////////

WordList::SortType WordList::sortType = Playability;

WordList::WordList()
{
}

WordList::~WordList()
{
}

void WordList::setSortBy(SortType _sortType)
{
	sortType = _sortType;
}

bool operator<(const Dict::Word &word1, const Dict::Word &word2)
{
	switch (Dict::WordList::sortType)
	{
	case Dict::WordList::Playability:
		if (word1.playability != word2.playability)
			return word1.playability > word2.playability;
	
		if (word1.word.length() != word2.word.length())
			return word1.word.length() < word2.word.length();

		// fall through
		
	case Dict::WordList::Probability:
		return word1.probability > word2.probability;
	
	case Dict::WordList::Length:
	case Dict::WordList::LengthLongestFirst:
	{
		bool ret;
		if (word1.word.length() != word2.word.length())
			ret = word1.word.length() < word2.word.length();
		else
			ret = word1.word < word2.word;

		if (Dict::WordList::sortType == Dict::WordList::LengthLongestFirst)
			return !ret;
		return ret;
	}
	}

	return false;
}

/////////////

ExtensionList Word::extensionsByLength(int length, const ExtensionList &list)
{
	ExtensionList ret;

	for (ExtensionList::ConstIterator it = list.begin(); it != list.end(); ++it)
		if ((*it).word.length() == length)
			ret.append(*it);

	return ret;
}

QString Querier::alphagram(const QString &letters)
{
	return arrangeLetters(letters, "ABCDEFGHIJKLMNOPQRSTUVWXYZ?");
}


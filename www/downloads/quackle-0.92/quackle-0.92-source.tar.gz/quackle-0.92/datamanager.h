/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef QUACKLE_DATAMANAGER_H
#define QUACKLE_DATAMANAGER_H

#include <string>

using namespace std;

#define QUACKLE_DATAMANAGER Quackle::DataManager::self()
#define QUACKLE_EVALUATOR Quackle::DataManager::self()->evaluator()
#define QUACKLE_GENERATOR Quackle::DataManager::self()->generator()
#define QUACKLE_PARAMETERS Quackle::DataManager::self()->parameters()
#define QUACKLE_ALPHABET_PARAMETERS Quackle::DataManager::self()->alphabetParameters()
#define QUACKLE_BOARD_PARAMETERS Quackle::DataManager::self()->boardParameters()
#define QUACKLE_LEXICON_PARAMETERS Quackle::DataManager::self()->lexiconParameters()
#define QUACKLE_STRATEGY_PARAMETERS Quackle::DataManager::self()->strategyParameters()

namespace Quackle
{

// General singleton type that will be around whenever
// you use libquackle.
// It provides access to lexica (todo), random numbers,
// and all parameters for a game

class AlphabetParameters;
class BoardParameters;
class Evaluator;
class GameParameters;
class Generator;
class LexiconParameters;
class StrategyParameters;

class DataManager
{
public:
	// sets up singleton, seeds random number generator,
	// and creates default parameter instances
	DataManager();

	~DataManager();

	static DataManager *self();
	static bool exists();

	// Are we in shape to run a game?
	// Makes sure there's a lexicon at least.
	bool isGood() const;

	// for now, always has one generator available
	Evaluator *evaluator();
	void setEvaluator(Evaluator *evaluator);

	// for now, always has one generator available
	Generator *generator();
	void setGenerator(Generator *generator);

	// game and board parameter objects are owned and deleted by
	// this data manager
	GameParameters *parameters();
	void setParameters(GameParameters *parameters);

	AlphabetParameters *alphabetParameters();
	void setAlphabetParameters(AlphabetParameters *alphabetParameters);

	BoardParameters *boardParameters();
	void setBoardParameters(BoardParameters *boardParameters);

	LexiconParameters *lexiconParameters();
	void setLexiconParameters(LexiconParameters *lexiconParameters);

	StrategyParameters *strategyParameters();
	void setStrategyParameters(StrategyParameters *strategyParameters);

	string findFile(string file);

	void setDataDirectory(string directory) { m_dataDirectory = directory; };
	string dataDirectory() { return m_dataDirectory; };

	void seedRandomNumbers(unsigned int seed);
	int randomNumber();

private:
	static DataManager *m_self;
	string m_dataDirectory;

	Evaluator *m_evaluator;
	Generator *m_generator;
	GameParameters *m_parameters;
	AlphabetParameters *m_alphabetParameters;
	BoardParameters *m_boardParameters;
	LexiconParameters *m_lexiconParameters;
	StrategyParameters *m_strategyParameters;
};

inline DataManager *DataManager::self()
{
	return m_self;
}

inline bool DataManager::exists()
{
	return m_self == 0;
}

inline Evaluator *DataManager::evaluator()
{
	return m_evaluator;
}

inline GameParameters *DataManager::parameters()
{
	return m_parameters;
}

inline AlphabetParameters *DataManager::alphabetParameters()
{
	return m_alphabetParameters;
}

inline BoardParameters *DataManager::boardParameters()
{
	return m_boardParameters;
}

inline LexiconParameters *DataManager::lexiconParameters()
{
	return m_lexiconParameters;
}

inline StrategyParameters *DataManager::strategyParameters()
{
	return m_strategyParameters;
}

}

#endif

/*
 * Copyright (c) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The names of the authors may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "board.h"
#include "datamanager.h"
#include "strategyparameters.h"
#include "catchall.h"

using namespace Quackle;

double CatchallEvaluator::equity(const GamePosition &position, const Move &move) const
{
	//UVcout << "tiles in unseenBag(): " << position.bag().size() << endl;
	if (position.board().isEmpty())
	{
		double adjustment = 0;
	
		if (move.action == Move::Place)
		{
			int start = move.startcol;
			if (move.startrow < start)
				start = move.startrow;
		
			LetterString wordTiles = move.wordTiles();
		
			int length = wordTiles.length();
	
			int consbits = 0;
			for (signed int i = wordTiles.length() - 1; i >= 0; i--)
			{
				consbits <<= 1;
                if (QUACKLE_ALPHABET_PARAMETERS->isVowel(wordTiles[i]))
					consbits |= 1;
			}

			adjustment = QUACKLE_STRATEGY_PARAMETERS->vcPlace(start, length, consbits);
		}

		return ScorePlusLeaveEvaluator::equity(position, move) + adjustment;
	}
	
	else if (position.bag().size() > 0)
	{
		return ScorePlusLeaveEvaluator::equity(position, move);
	}
	else
	{
		return endgameResult(position, move) + move.score;
	}
}

double CatchallEvaluator::endgameResult(const GamePosition &position, const Move &move) const
{
	Rack leave = position.currentPlayer().rack() - move;

	if (leave.empty())
	{
		double deadwood = 0;
		for (PlayerList::const_iterator it = position.players().begin(); 
		     it != position.players().end(); ++it)
		{
			if (!(*it == position.currentPlayer()))
			{
				deadwood += it->rack().score();
			}
		}

		return deadwood * 2;
	}
	else
	{
		return -8.00 - 2.61 * leave.score();
	}

	return 0;
}


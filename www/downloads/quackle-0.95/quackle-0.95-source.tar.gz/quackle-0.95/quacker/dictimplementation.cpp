/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#include <alphabetparameters.h>
#include <datamanager.h>
#include <generator.h>
#include <lexiconparameters.h>
#include <quackleio/util.h>

#include "dictimplementation.h"

DictImplementation::DictImplementation()
{
}

DictImplementation::~DictImplementation()
{
}

Dict::WordList DictImplementation::query(const QString &query, int flags)
{
	QString modifiedQuery = query;
	modifiedQuery.replace(".", "?");

	int anagramFlags = Quackle::Generator::ClearBlanknesses;

	if (flags & Dict::Querier::NoRequireAllLetters)
		anagramFlags |= Quackle::Generator::NoRequireAllLetters;

	QRegExp wildcardRegexp("[\\*/]");
	if (wildcardRegexp.indexIn(modifiedQuery) >= 0)
	{
		if (!(flags & Dict::Querier::NoRequireAllLetters))
			anagramFlags |= Quackle::Generator::AddAnyLetters;

		modifiedQuery.replace(wildcardRegexp, QString());
	}

	vector<Quackle::LetterString> words(m_generator.anagramLetters(QuackleIO::Util::encode(modifiedQuery), anagramFlags));
	Dict::WordList ret;

	vector<Quackle::LetterString>::const_iterator end = words.end();
	for (vector<Quackle::LetterString>::const_iterator it = words.begin(); it != end; ++it)
	{
		Dict::Word dictWord;
		dictWord.word = QuackleIO::Util::letterStringToQString(*it);
		dictWord.probability = Quackle::Bag::probabilityOfDrawingFromFullBag(*it);
		ret.push_back(dictWord);
	}

	if (flags & NoRequireAllLetters)
	{
		ret.setSortBy(Dict::WordList::LengthLongestFirst);
	}
	else
	{
		ret.setSortBy(Dict::WordList::Alphabetical);
	}

	qSort(ret);

	return ret;
}

QString DictImplementation::alphagram(const QString &letters) const
{
	return QuackleIO::Util::letterStringToQString(QuackleIO::Util::alphagram(QuackleIO::Util::encode(letters)));
}

bool DictImplementation::isLoaded() const
{
	return QUACKLE_LEXICON_PARAMETERS->hasSomething();
}


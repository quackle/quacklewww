
#include <QCoreApplication>
#include <QStringList>

#include <game.h>
#include <quackleio/util.h>

#include "testharness.h"
#include "trademarkedboards.h"

int main(int argc, char **argv)
{
	QCoreApplication a(argc, argv);

	TestHarness harness;
	harness.executeFromArguments();

	return 0;
}


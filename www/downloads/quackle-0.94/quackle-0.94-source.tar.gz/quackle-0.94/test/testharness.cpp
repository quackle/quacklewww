/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#include <QtCore>

#include <iostream>

#include <bogowinplayer.h>
#include <computerplayercollection.h>
#include <resolvent.h>
#include <datamanager.h>
#include <endgameplayer.h>
#include <game.h>
#include <gameparameters.h>
#include <lexiconparameters.h>
#include <strategyparameters.h>
#include <enumerator.h>
#include <reporter.h>

#include <quackleio/froggetopt.h>
#include <quackleio/gcgio.h>
#include <quackleio/util.h>

#include "trademarkedboards.h"
#include "testharness.h"

using namespace Quackle;

TestHarness::TestHarness()
	: m_computerPlayerToTest(0)
{
	m_gamesDir = "games";
	m_dataManager.setComputerPlayers(Quackle::ComputerPlayerCollection::fullCollection());
}

TestHarness::~TestHarness()
{
}

const char *usage =
"Required arguments:\n"
"--computer='Toronto Player'; sets the computer player.\n"
"Optional arguments:\n"
"--mode=[all, selfplay, enumerate, staticleaves, randomracks, leavecalc]\n" 
"       'positions' (default) runs computer player all positions.\n"
"       'report' asks computer player for report on all positions.\n"
"       'selfplay' runs 1000 selfplay games.\n"
"       'enumerate' lists all racks.\n"
"       'staticleaves' output static leave values.\n"
"       'randomracks' spit out random racks (forever?)\n"
"       'leavecalc' spit out roughish leave values\n"
"--position=game.gcg; this option can be repeated to specify positions\n"
"                     to test.\n"
"--lexicon='sowpods'; sets the lexicon.";

void TestHarness::executeFromArguments()
{
	GetOpt opts;

	QString mode;
	QString computer;
	bool help;

	opts.addOption('c', "computer", &computer);
	opts.addOption('l', "lexicon", &m_lexicon);
	opts.addOption('m', "mode", &mode);
	opts.addRepeatableOption("position", &m_positions);
	
	opts.addSwitch("help", &help);

	if (!opts.parse())
		return;

	if (help)
	{
		UVcout << usage << endl;
		return;
	}

	if (mode.isNull())
		mode = "positions";
	if (computer.isNull())
		computer = "Toronto Player";
	if (m_lexicon.isNull())
		m_lexicon = "twl06";

	bool playerFound = false;
	const Quackle::Player &player = QUACKLE_COMPUTER_PLAYERS.playerForName(QuackleIO::Util::qstringToString(computer), playerFound);
	if (playerFound)
	{
		m_computerPlayerToTest = player.computerPlayer();
	}
	else
	{
		UVcout << "Computer " << QuackleIO::Util::qstringToString(computer) << " not found!" << endl;
		return;
	}

	startUp();

	if (mode == "positions")
		testPositions();
	if (mode == "report")
		testReport();
	if (mode == "enumerate")
		enumerateAll();
	if (mode == "staticleaves")
		staticLeaves(QString("racks"));
	if (mode == "randomracks")
		randomRacks();
	if (mode == "leavecalc")
		leaveCalc(QString("leaves"));
	else if (mode == "selfplay")
		selfPlayGames();
}

void TestHarness::startUp()
{
	UVcout << "Starting up.";

	m_dataManager.setBackupLexicon("twl06");
	m_dataManager.setBoardParameters(new ScrabbleBoard());
	m_dataManager.setDataDirectory("../data");
	m_dataManager.lexiconParameters()->loadDawg(Quackle::LexiconParameters::findDictionaryFile(QuackleIO::Util::qstringToStdString(m_lexicon + ".dawg")));
	UVcout << ".";

   	m_dataManager.lexiconParameters()->loadGaddag(Quackle::LexiconParameters::findDictionaryFile(QuackleIO::Util::qstringToStdString(m_lexicon + ".gaddag")));
	UVcout << ".";

	m_dataManager.strategyParameters()->initialize(QuackleIO::Util::qstringToStdString(m_lexicon));
	UVcout << ".";

	UVcout << endl;

	m_gamesDir = QString("games_PLAYERNAME_%1").arg(QDateTime::currentDateTime().toString("dd.MM_hh.mm.ss"));
}

void TestHarness::testFromFile(const QString &file)
{
	UVcout << "Testing game from " << QuackleIO::Util::qstringToString(file) << endl;
	Quackle::Game *game = createNewGame(file);
	if (game)
	{
		testPosition(game->currentPosition(), computerPlayerToTest());
	}

	delete game;
}

double TestHarness::leaveSim(const Rack &R, int iterations)
{
	double sum = 0.0;

	UVcout << R << endl;
	Bag B;
	B.removeLetters(R.tiles());

	int tilesToLeave = 14 + rand() % (93 - 14);

	for (int i = 0; i < iterations; i++) 
	{
		Quackle::Game game;

		Quackle::PlayerList players;

		Quackle::Player compyA(m_computerPlayerToTest->name() + MARK_UV(" A"), Quackle::Player::ComputerPlayerType, 0);
		compyA.setAbbreviatedName(MARK_UV("A"));
		compyA.setComputerPlayer(new Quackle::StaticPlayer());
		players.push_back(compyA);

		Quackle::Player compyB(m_computerPlayerToTest->name() + MARK_UV(" B"), Quackle::Player::ComputerPlayerType, 1);
		compyB.setAbbreviatedName(MARK_UV("B"));
		compyB.setComputerPlayer(new Quackle::StaticPlayer());
		players.push_back(compyB);

		game.setPlayers(players);
		game.associateKnownComputerPlayers();

		game.addPosition();

		game.currentPosition().setCurrentPlayerRack(Rack(""), true);
		game.currentPosition().setOppRack(Rack(""), true);
	
		Bag startBag = B;
		game.currentPosition().setBag(startBag);

		game.addPosition();

		UVcout << "NEW GAME" << endl;

		while (game.currentPosition().bag().size() > tilesToLeave)
		{
			if (game.currentPosition().gameOver())
			{
				UVcout << "GAME OVER" << endl;
				break;
			}
			
			const Quackle::Player player(game.currentPosition().currentPlayer());
			Quackle::Move compMove(game.haveComputerPlay());
			UVcout << "with " << player.rack() << ", " << player.name() << " commits to " << compMove << endl;
		}

		game.currentPosition().setCurrentPlayerRack(R, true);
		Quackle::Move compMove(game.haveComputerPlay());
		sum += compMove.equity;	
	}

	return sum / iterations;
}

void TestHarness::leaveCalc(const QString &filename)
{
	QuackleIO::GCGIO io;
	QFile file(filename);

	if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
	{
		UVcout << "Could not open file " << QuackleIO::Util::qstringToString(filename) << endl;
		return;
	}

	QTextStream in(&file);
	
	const int iterations = 10;

	while (!in.atEnd())
	{
		QString line = in.readLine();
		Rack rack(QuackleIO::Util::encode(line));
		double value = leaveSim(rack, iterations);
		UVcout << "leavecalc: " << rack << " " << value << endl; 
	}

	file.close();

}

void TestHarness::randomRacks()
{
	for (;;)
	{
		Game game;

		Quackle::PlayerList players;
	
		Player compyA(m_computerPlayerToTest->name() + MARK_UV(" A"), Quackle::Player::ComputerPlayerType, 0);
		compyA.setAbbreviatedName(MARK_UV("A"));
		compyA.setComputerPlayer(m_computerPlayerToTest);
		players.push_back(compyA);

		game.setPlayers(players);

		game.addPosition();

		UVcout << game.currentPosition().currentPlayer().rack() << endl;
	}
}

void TestHarness::staticLeaves(const QString &filename)
{
	QuackleIO::GCGIO io;
	QFile file(filename);

	if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
	{
		UVcout << "Could not open file " << QuackleIO::Util::qstringToString(filename) << endl;
		return;
	}

	QTextStream in(&file);
	
	Quackle::Game game;

	Quackle::PlayerList players;

	Quackle::Player compyA(m_computerPlayerToTest->name() + MARK_UV(" A"), Quackle::Player::ComputerPlayerType, 0);
	compyA.setAbbreviatedName(MARK_UV("A"));
	compyA.setComputerPlayer(m_computerPlayerToTest);
	players.push_back(compyA);

	Quackle::Player compyB(m_computerPlayerToTest->name() + MARK_UV(" B"), Quackle::Player::ComputerPlayerType, 1);
	compyB.setAbbreviatedName(MARK_UV("B"));
	compyB.setComputerPlayer(m_computerPlayerToTest);
	players.push_back(compyB);

	game.setPlayers(players);
	game.associateKnownComputerPlayers();

	game.addPosition();

	Move exchZero = Move::createExchangeMove(QuackleIO::Util::encode(""));

	while (!in.atEnd())
	{
		QString line = in.readLine();
		Rack rack(QuackleIO::Util::encode(line));
		game.currentPosition().setCurrentPlayerRack(rack);
		Move move = game.currentPosition().staticBestMove();
		//Move scoredExch = game.currentPosition().scoreMove(exchZero);
		//UVcout << rack << " " << scoredExch << endl;			
		UVcout << rack << " " << move << endl;
	}

	file.close();
}

void TestHarness::enumerateAll()
{
	Quackle::Bag B;
	Enumerator E(B);
	ProbableRackList racks;
	E.enumerate(&racks);
	for (ProbableRackList::iterator it = racks.begin(); it != racks.end(); ++it)
		UVcout << (*it).rack << " " << (*it).probability << endl;
}

void TestHarness::testPosition(const Quackle::GamePosition &position, Quackle::ComputerPlayer *player)
{
	player->setPosition(position);

	ProbableRackList racks;
	Quackle::Bag unseenBag = position.unseenBag();

	if (unseenBag.size() <= QUACKLE_PARAMETERS->rackSize() + 3)
	{
		Enumerator enumerator(unseenBag);
		enumerator.enumerate(&racks);
		UVcout << racks.size() << " enumerations: " << endl;
		for (ProbableRackList::iterator it = racks.begin(); it != racks.end(); ++it)
			UVcout << (*it).rack << " " << (*it).probability << endl;
	}

	const int movesToShow = 10;
	UVcout << "Testing " << computerPlayerToTest()->name() << " on:" << endl;
	UVcout << position << endl;
	UVcout << "Generating moves..." << endl;

	MoveList moves = computerPlayerToTest()->moves(movesToShow);

	for (Quackle::MoveList::const_iterator it = moves.begin(); it != moves.end(); ++it)
	{
		UVcout << *it << endl;
	}
}

Quackle::Game *TestHarness::createNewGame(const QString &filename)
{
	QuackleIO::GCGIO io;
	QFile file(filename);

	if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
	{
		UVcout << "Could not open gcg " << QuackleIO::Util::qstringToString(filename) << endl;
		return 0;
	}

	QTextStream in(&file);
	Quackle::Game *game = io.read(in, QuackleIO::Logania::MaintainBoardPreparation);
	file.close();

	return game;
}

void TestHarness::testPositions()
{
	UVcout << "Testing " << m_positions.size() << " positions with " << m_computerPlayerToTest->name() << "." << endl;
	for (QStringList::iterator it = m_positions.begin(); it != m_positions.end(); ++it)
		testFromFile(*it);
}

void TestHarness::testReport()
{
	UVcout << "Reporting on " << m_positions.size() << " positions with " << m_computerPlayerToTest->name() << "." << endl;
	for (QStringList::iterator it = m_positions.begin(); it != m_positions.end(); ++it)
	{
		Quackle::Game *game = createNewGame(*it);
		if (game)
		{
			UVString report;
			Quackle::Reporter::reportGame(*game, m_computerPlayerToTest, &report);
			UVcout << report << endl;
		}

		delete game;
	}
}

void TestHarness::selfPlayGames()
{
	const int numGames = 1000;
	for (int i = 0; i < numGames; i++)
		selfPlayGame(i);
}

void TestHarness::selfPlayGame(int gameNumber)
{
	Quackle::Game game;

	Quackle::PlayerList players;

	Quackle::Player compyA(m_computerPlayerToTest->name() + MARK_UV(" A"), Quackle::Player::ComputerPlayerType, 0);
	compyA.setAbbreviatedName(MARK_UV("A"));
	compyA.setComputerPlayer(m_computerPlayerToTest);
	players.push_back(compyA);

	Quackle::Player compyB(m_computerPlayerToTest->name() + MARK_UV(" B"), Quackle::Player::ComputerPlayerType, 1);
	compyB.setAbbreviatedName(MARK_UV("B"));
	compyB.setComputerPlayer(m_computerPlayerToTest);
	players.push_back(compyB);

	game.setPlayers(players);
	game.associateKnownComputerPlayers();

	game.addPosition();

	UVcout << "NEW GAME" << endl;

	QTime time;
	time.start();

	const int playahead = 50;
	for (int i = 0; i < playahead; ++i)
	{
		if (game.currentPosition().gameOver())
		{
			UVcout << "GAME OVER" << endl;
			break;
		}

		const Quackle::Player player(game.currentPosition().currentPlayer());
		Quackle::Move compMove(game.haveComputerPlay());
		UVcout << "with " << player.rack() << ", " << player.name() << " commits to " << compMove << endl;
	}

	int secondsElapsed = static_cast<int>(time.elapsed() / 1000);
	UVcout << "Game played in " << secondsElapsed << " seconds." << endl;

	Quackle::EndgamePlayer playah;
	UVString report;
	Quackle::Reporter::reportGame(game, &playah, &report);
	UVcout << report << endl;

	QString gamesDir = m_gamesDir;
	gamesDir.replace("PLAYERNAME", QuackleIO::Util::uvStringToQString(m_computerPlayerToTest->name()));
	gamesDir.replace(" ", "_");
	QDir::current().mkdir(gamesDir);

	QString joinedCompyName = QuackleIO::Util::uvStringToQString(m_computerPlayerToTest->name());
	joinedCompyName.replace(" ", "_");
	QFile outFile(QString("%1/%2-game-%3.gcg").arg(gamesDir).arg(joinedCompyName).arg(gameNumber));

	if (!outFile.open(QIODevice::WriteOnly | QIODevice::Text))
	{
		UVcout << "Could not open gcg output file" << endl;
		return;
	}

	QuackleIO::GCGIO io;
	QTextStream out(&outFile);
	io.write(game, out);
	
	QFile outFileReport(QString("%1/%2-game-%3.report").arg(gamesDir).arg(joinedCompyName).arg(gameNumber));

	if (!outFileReport.open(QIODevice::WriteOnly | QIODevice::Text))
	{
		UVcout << "Could not open report output file" << endl;
		return;
	}
	QTextStream outReport(&outFileReport);
	outReport << QuackleIO::Util::uvStringToQString(report);
	outReport << "Game played in " << secondsElapsed << " seconds." << endl;

	outFile.close();
	outFileReport.close();
}


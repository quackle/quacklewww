/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#ifndef QUACKER_GRAPHICAL_REPORTER_H
#define QUACKER_GRAPHICAL_REPORTER_H

#include <QFile>
#include <QTextStream>

namespace Quackle
{
	class ComputerPlayer;
	class GamePosition;
	class Game;
}

class GraphicalReporter
{
public:
	GraphicalReporter(const QString &outputDirectory);

	// makes header and report for all positions
	void reportGame(const Quackle::Game &game, Quackle::ComputerPlayer *computerPlayer);

	// makes header and puts into the index file
	void reportHeader(const Quackle::Game &game);

	// makes graphical displays of top n plays of position, dumps to images 
	// and puts links to them in the index file.
	void reportPosition(const Quackle::GamePosition &position, Quackle::ComputerPlayer *computerPlayer);

protected:
	QString m_outputDirectory;
	QFile m_indexFile;
	QTextStream m_indexStream;

	QString makeFilename(const QString &filename) const;

	// opens the index file (m_outputDirectory/index.html)
	// if it is not already open
	void openIndex();
};

#endif

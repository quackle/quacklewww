/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#ifndef QUACKLE_DICT_H
#define QUACKLE_DICT_H

#include <QStringList>

namespace Dict
{

class Extension
{
public:
	Extension();

	QString word;
	int playability;
	double probability;
	bool british;
};

typedef QList<Extension> ExtensionList;

class Word
{
public:
	Word();

	QString word;
	int playability;
	double probability;
	bool british;

	ExtensionList frontExtensions;
	ExtensionList backExtensions;

	static ExtensionList extensionsByLength(int length, const ExtensionList &list);

	static void sortWordListByPlayability(QList<Word> &list)
	{
		qSort(list);
	}
};

class WordList : public QList<Word>
{
public:
	WordList();
	~WordList();

	enum SortType { Playability, Length, LengthLongestFirst, Probability };

	void setSortBy(SortType sortType);
	static SortType sortType;
};

class ThingToGetUpdatedDuringQueries
{
public:
	virtual ~ThingToGetUpdatedDuringQueries() {};

	virtual void updateDuringQuery() = 0;
};

class Querier
{
public:
	virtual ~Querier() {};

	enum QueryFlags { None = 0x0000, WithExtensions = 0x0001, CallUpdate = 0x0002, NoRequireAllLetters = 0x0004 };

	virtual void setThingToGetUpdatedDuringQueries(ThingToGetUpdatedDuringQueries * /* thing */) {};
	virtual WordList query(const QString &query, int flags = None) = 0;
	virtual QString arrangeLetters(const QString &letters, const QString &order) = 0;
	virtual QString alphagram(const QString &letters);
	virtual bool isLoaded() = 0;
};

}

// Returns true if word1 is less playable than word2;
// otherwise returns false.
bool operator<(const Dict::Word &word1, const Dict::Word &word2);

#endif

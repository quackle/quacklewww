/*
 *  Quackle -- Crossword game artificial intelligence and analysis tool
 *  Copyright (C) 2005-2006 Jason Katz-Brown and John O'Laughlin.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
 *  02110-1301  USA
 */

#include <QtCore>

#include <move.h>
#include <rack.h>

#include "util.h"

using namespace QuackleIO;

QString Util::moveToDetailedString(const Quackle::Move &move, QString prettyTiles)
{
	if (prettyTiles.isNull())
		prettyTiles = letterStringToQString(move.prettyTiles());

	QString ret;

	switch (move.action)
	{
	case Quackle::Move::Pass:
		ret = QObject::tr("Pass");
		break;
	
	case Quackle::Move::Exchange:
		ret = QObject::tr("Exch. %1").arg(prettyTiles);
		break;
	
	case Quackle::Move::UnusedTilesBonus:
		ret = QObject::tr("2*(%1)").arg(Util::alphagram(letterStringToQString(move.usedTiles())));
		break;
	
	case Quackle::Move::TimePenalty:
		ret = QObject::tr("%1 point time penalty").arg(move.effectiveScore());
		break;
	
	case Quackle::Move::Nonmove:
		ret = QObject::tr("None");
		break;
	
	case Quackle::Move::Place:
		ret = uvStringToQString(move.positionString()) + " ";
		ret += prettyTiles;

		if (move.isChallengedPhoney())
			ret = QObject::tr("%1 [Challenged Off]").arg(ret);

		break;
	}

	if (move.scoreAddition() != 0)
		ret = QString("%1 [and %2%3]").arg(ret).arg(move.scoreAddition() > 0? QObject::tr("+") : QString()).arg(move.scoreAddition());

	return ret;
}

QString Util::moveToSensitiveString(const Quackle::Move &move)
{
	QString ret;

	if (move.action == Quackle::Move::Exchange)
		ret = QObject::tr("Exch. %1").arg(move.prettyTiles().length());
	else
		ret = moveToDetailedString(move);

	return ret;
}

QString Util::arrangeLetters(const QString &word, const QString &sortOrder)
{
	unsigned int counts[27];
	
	for (unsigned int i = 0; i < 27; i++)
		counts[i] = 0;

	for (int i = 0; i < word.length(); i++)
	{
		char c = word.at(i).toLatin1();
		if ((c >= 'A') && (c <= 'Z'))
			counts[c - 'A']++;
		else if (c == '?')
			counts[26]++;
	}

	QString ret;

	for (int i = 0; i < sortOrder.length(); i++)
	{
		char c = sortOrder.at(i).toLatin1();
		unsigned int n;

		if ((c >= 'A') && (c <= 'Z'))
			n = counts[c - 'A'];
		else 
			n = counts[26];

		for (unsigned int j = 0; j < n; j++)
			ret += c;
	}
 
    return ret;
}

QString Util::alphagram(const QString &word) 
{
	return arrangeLetters(word, "ABCDEFGHIJKLMNOPQRSTUVWXYZ?");
}

QString Util::arrangeLettersForUser(const QString &word, bool vowelFirst) 
{
	return Util::arrangeLetters(word, vowelFirst? "AEIOUBCDFGHJKLMNPQRSTVWXYZ?" : "ABCDEFGHIJKLMNOPQRSTUVWXYZ?");
}

QString Util::arrangeLettersForUser(const Quackle::Rack &rack, bool vowelFirst)
{
	return arrangeLettersForUser(letterStringToQString(rack.tiles()), vowelFirst);
}

